import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'path';
import {defineConfig, type Plugin} from 'vite';

// As variantes modernas do Tesseract (incluindo relaxed SIMD) são escolhidas
// pelo próprio motor de acordo com o navegador. Disponibilizá-las localmente
// impede falhas de OCR e evita pedidos a CDNs externos.
const missingCoreAssets = [
  'tesseract-core-lstm.wasm.js',
  'tesseract-core-lstm.wasm',
  'tesseract-core-simd.wasm.js',
  'tesseract-core-simd.wasm',
  'tesseract-core-relaxedsimd-lstm.wasm.js',
  'tesseract-core-relaxedsimd-lstm.wasm',
  'tesseract-core-relaxedsimd.wasm.js',
  'tesseract-core-relaxedsimd.wasm',
];

function localTesseractCore(): Plugin {
  const assets = new Set(missingCoreAssets);
  const coreDirectory = path.resolve(__dirname, 'node_modules/tesseract.js-core');

  return {
    name: 'local-tesseract-core-assets',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const pathname = new URL(req.url || '/', 'http://localhost').pathname;
        const assetName = pathname.match(/\/tesseract\/([^/]+)$/)?.[1];
        if (!assetName || !assets.has(assetName)) return next();

        const filename = path.join(coreDirectory, assetName);
        if (!fs.existsSync(filename)) return next();

        res.setHeader('Content-Type', assetName.endsWith('.js') ? 'application/javascript' : 'application/wasm');
        fs.createReadStream(filename).pipe(res);
      });
    },
    generateBundle() {
      for (const assetName of assets) {
        const filename = path.join(coreDirectory, assetName);
        if (!fs.existsSync(filename)) {
          this.error(`Falta um recurso local necessário ao OCR: ${assetName}`);
        }
        this.emitFile({
          type: 'asset',
          fileName: `tesseract/${assetName}`,
          source: fs.readFileSync(filename),
        });
      }
    },
  };
}

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss(), localTesseractCore()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
