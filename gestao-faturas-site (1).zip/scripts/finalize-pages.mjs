import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const dist = path.resolve('dist');
if (!fs.existsSync(path.join(dist, 'index.html'))) throw new Error('Falta dist/index.html');
const bundles=[];
function scan(directory) {
  for (const entry of fs.readdirSync(directory, {withFileTypes:true})) {
    const abs=path.join(directory,entry.name);
    if(entry.isDirectory()) scan(abs);
    else bundles.push('./'+path.relative(dist,abs).split(path.sep).join('/'));
  }
}
scan(path.join(dist,'assets'));
if (!bundles.length) throw new Error('Faltam assets compilados do Vite');
let worker=fs.readFileSync(path.join(dist,'sw.js'),'utf8');
const marker='  // __ADD_COMPILED_ASSETS__';
if (!worker.includes(marker)) throw new Error('Marcador de pré-cache não encontrado');
const lines=bundles.map(x=>`  ,${JSON.stringify(x)}`).join('\n');
worker=worker.replace(marker,lines);
const fingerprint=crypto.createHash('sha256').update(bundles.join('|')).digest('hex').slice(0,10);
worker=worker.replace('gestao-faturas-v5', 'gestao-faturas-v5-'+fingerprint);
fs.writeFileSync(path.join(dist,'sw.js'),worker);
const html=fs.readFileSync(path.join(dist,'index.html'),'utf8');
if (!html.includes('./assets/')) throw new Error('Base do Vite não é relativo; GitHub Pages pode falhar');
for(const expected of ['manifest.webmanifest','pdf.worker.mjs','tesseract/por.traineddata.gz']) {
 if(!fs.existsSync(path.join(dist,expected))) throw new Error('Recurso offline em falta: '+expected);
}
console.log('Publicação preparada: '+bundles.length+' assets JS/CSS, base relativo, OCR offline presente.');
