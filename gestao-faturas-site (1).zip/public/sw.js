// Service Worker para Gestão de Faturas | Controlo de Assinaturas
const CACHE_NAME = "gestao-faturas-v5";

// Recursos essenciais para funcionamento 100% offline
const PRECACHE_ASSETS = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./icon.svg",
  "./pwa-192x192.png",
  "./pwa-512x512.png",
  "./pwa-maskable-512x512.png",
  "./apple-touch-icon.png",
  "./favicon.ico",
  "./pdf.worker.mjs",
  "./tesseract/worker.min.js",
  "./tesseract/tesseract-core.wasm.js",
  "./tesseract/tesseract-core.wasm",
  "./tesseract/tesseract-core-simd-lstm.wasm.js",
  "./tesseract/tesseract-core-simd-lstm.wasm",
  "./tesseract/tesseract-core-lstm.wasm.js",
  "./tesseract/tesseract-core-lstm.wasm",
  "./tesseract/tesseract-core-simd.wasm.js",
  "./tesseract/tesseract-core-simd.wasm",
  "./tesseract/tesseract-core-relaxedsimd-lstm.wasm.js",
  "./tesseract/tesseract-core-relaxedsimd-lstm.wasm",
  "./tesseract/tesseract-core-relaxedsimd.wasm.js",
  "./tesseract/tesseract-core-relaxedsimd.wasm",
  "./tesseract/por.traineddata",
  "./tesseract/por.traineddata.gz"
  // __ADD_COMPILED_ASSETS__
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // Tentar armazenar todos os ficheiros essenciais
      return Promise.allSettled(
        PRECACHE_ASSETS.map((asset) =>
          cache.add(asset).catch((err) => {
            console.warn("Aviso ao precachear asset:", asset, err);
          })
        )
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          // Apenas limpa caches antigas do Service Worker, NUNCA afeta IndexedDB
          if (key !== CACHE_NAME && key.startsWith("gestao-faturas-")) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  // Não colocar em cache recursos externos nem aceitar métodos não GET.
  if (event.request.method !== "GET") return;
  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;

  // Para navegação HTML: NetworkFirst com fallback seguro para cache
  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          if (response && response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => {
          return caches.match("./index.html").then((cached) => cached || caches.match(event.request));
        })
    );
    return;
  }

  // Para assets estáticos: CacheFirst com atualização em segundo plano se houver rede
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Se estiver online, tenta atualizar a cache em background sem bloquear
        fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkResponse));
            }
          })
          .catch(() => {});
        return cachedResponse;
      }

      return fetch(event.request)
        .then((networkResponse) => {
          if (!networkResponse || networkResponse.status !== 200) {
            return networkResponse;
          }
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          return networkResponse;
        })
        .catch(() => {
          // Fallback offline
          return caches.match(event.request);
        });
    })
  );
});
