/**
 * Reconstrói nomes societários partidos por linhas e colunas em PDFs digitais.
 * Apenas promove associações documentais confirmadas pelo NIF do emitente.
 * Nenhum serviço externo, lista fixa de fornecedores ou acesso à rede.
 */
export interface PositionedToken { str: string; x: number; y: number; width: number; height: number }
export interface PositionedLine { y: number; tokens: PositionedToken[]; text: string }
export interface LayoutSupplierCandidate {
  name: string;
  issuerAnchored: boolean;
  sourceLineIndex: number;
  score: number;
  reasons: string[];
}
const suffixAtEnd = /\b(?:L\.?\s*D\.?\s*A\.?|S\.?\s*A\.?|Unipessoal(?:\s*,?\s*Lda\.?)?|Sociedade\s+(?:An[oó]nima|por\s+Quotas)|C\.?\s*R\.?\s*L\.?)\s*[.,]?$/i;
const prohibited = /\b(?:IBAN|SWIFT|ATCUD|fatura|factura|nota\s+de|refer[eê]ncia|contribuinte|NIF|cliente|adquirente|emitido\s+por|total|capital\s+social|pagar|vencimento|pagamento|software|processado)\b|www\.|http|@/i;
const addressStart = /^(?:rua|estrada|av\.?|avenida|parque\s+industrial|apartado|edif[ií]cio|lote|n[º°]|[0-9]{4}-[0-9]{3})\b/i;
const clean = (s: string) => s.replace(/\s+/g, ' ').replace(/^[\s,:;|–—-]+|[\s,:;|–—-]+$/g, '').trim();
function isBusinessPiece(input: string): boolean {
  const s = clean(input);
  return s.length >= 3 && s.length <= 150 && /[\p{L}]{2}/u.test(s) && !prohibited.test(s)
    && !addressStart.test(s) && !/\d{5,}/.test(s) && !/^[\d\s.,€%]+$/.test(s);
}
export function reconstructMultilineSupplier(
  lines: PositionedLine[], issuerNif?: string, buyerNif?: string,
): LayoutSupplierCandidate[] {
  if (!issuerNif) return [];
  const all = lines.flatMap(line => line.tokens || []);
  const anchor = all.find(token => token.str.replace(/\D/g, '').includes(issuerNif));
  if (!anchor) return [];
  const buyer = buyerNif ? all.find(token => token.str.replace(/\D/g, '').includes(buyerNif)) : undefined;
  const issuerX = anchor.x, buyerX = buyer?.x;
  type Segment = { text: string; x: number; y: number; height: number; lineIdx: number; column: 'issuer' | 'buyer' };
  const segments: Segment[] = [];
  lines.forEach((line, lineIdx) => {
    const tokens = [...(line.tokens || [])].filter(t => t.str?.trim()).sort((a, b) => a.x - b.x);
    let group: PositionedToken[] = [];
    const emit = () => {
      if (!group.length) return;
      const first = group[0], text = clean(group.map(t => t.str).join(' '));
      const issuerDx = Math.abs(first.x - issuerX);
      const buyerDx = buyerX === undefined ? Infinity : Math.abs(first.x - buyerX);
      segments.push({
        text, x: first.x, y: line.y,
        height: Math.max(9, ...group.map(t => Math.abs(t.height || 0))),
        lineIdx, column: buyerDx < issuerDx ? 'buyer' : 'issuer',
      });
      group = [];
    };
    for (const token of tokens) {
      const prev = group[group.length - 1];
      const gap = prev ? token.x - prev.x - Math.max(prev.width || 0, 0) : 0;
      const crossesBuyerStart = buyerX !== undefined && group.length > 0
        && group[0].x < buyerX - 65 && token.x >= buyerX - 65;
      if (prev && (gap > 26 || crossesBuyerStart)) emit();
      group.push(token);
    }
    emit();
  });
  const names = segments.filter(s => s.column === 'issuer' && isBusinessPiece(s.text))
    .sort((a, b) => b.y - a.y);
  const found: LayoutSupplierCandidate[] = [];
  for (let i = 0; i < names.length; i++) {
    const first = names[i];
    if (suffixAtEnd.test(first.text)) continue;
    for (let j = i + 1; j < Math.min(i + 4, names.length); j++) {
      const second = names[j], gapY = first.y - second.y;
      if (gapY <= 0) continue;
      if (gapY > Math.max(25, Math.max(first.height, second.height) * 2.6)) break;
      if (Math.abs(first.x - second.x) > 46 || !suffixAtEnd.test(second.text)) continue;
      if (!/^(?:e\b|de\b|da\b|do\b|dos\b|das\b|&|l\.?d\.?a\.?\b|unipessoal\b|s\.?a\.?\b|sociedade\b)/i.test(second.text)) continue;
      const name = clean(first.text + ' ' + second.text);
      if (!isBusinessPiece(name)) continue;
      const issuerDx = Math.abs(first.x - issuerX);
      const buyerDx = buyerX === undefined ? Infinity : Math.abs(first.x - buyerX);
      if (issuerDx >= buyerDx) continue;
      found.push({
        name, issuerAnchored: true, sourceLineIndex: first.lineIdx, score: 320,
        reasons: [
          'Nome completo reconstruído de linhas contíguas no mesmo bloco visual',
          'Posição no PDF associada ao NIF do emitente ' + issuerNif,
        ],
      });
      break;
    }
  }
  return [...new Map(found.map(c => [c.name.toLocaleLowerCase('pt-PT'), c])).values()];
}
