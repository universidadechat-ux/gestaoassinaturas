/** Sugestão de denominação vista no cabeçalho (não constitui confirmação automática). */
export function suggestIssuerFromHeaderOcr(ocrText: string): string | undefined {
  const lines = ocrText.split(/\r?\n/).map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const excluded = /(?:^rua\b|^av(?:enida)?\.?\b|^estrada\b|^n\.?i\.?f\.?\b|contribuinte|^\d{4}\s*[-–]\s*\d{3}|^telefone|^email|^original|^fatura|^factura|^exm[oa]|^iban|^conta|^total|^www\.|@)/i;
  const plausible = (s: string) => s.length >= 4 && s.length < 95 && /[A-Za-zÀ-ÿ]{3}/.test(s)
    && !excluded.test(s) && (s.match(/\d/g) || []).length < 3;
  const start = lines.findIndex(s => /\b(?:associa[cç][aã]o|funda[cç][aã]o|instituto|universidade|cooperativa|federa[cç][aã]o|c[aâ]mara|ordem\s+d[oea]|munic[ií]pio)\b/i.test(s));
  if (start >= 0) {
    const parts: string[] = [];
    for (let i = start; i < Math.min(start + 5, lines.length); i++) {
      if (!plausible(lines[i])) break;
      parts.push(lines[i]);
      if (parts.join(' ').length > 130) break;
    }
    const joined = parts.join(' ').replace(/\s+/g, ' ').trim();
    if (joined.length >= 24 && joined.split(' ').length >= 4) return joined;
  }
  // Siglas vistas num logótipo são sugestões, nunca prova de denominação legal.
  return lines.slice(0, 7).map(s => s.replace(/[^A-Z]/g, ''))
    .find(s => /^[A-Z]{4,10}$/.test(s));
}
