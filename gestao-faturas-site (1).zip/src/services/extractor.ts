import {
  ConfirmedSupplier,
  ExtractedInvoiceData,
  ExtractionDiagnostic,
  ExtractionSituation,
  FieldExtractionDetail,
  PortugueseQrFiscalData,
  SupplierCandidateInfo,
} from '../types';
import * as pdfjsLib from 'pdfjs-dist';
import { createWorker } from 'tesseract.js';
import { isValidPortugueseNif, scanQrFromCanvasRobust, scanQrFromImageBlob } from './qrScanner';
import { storage } from './storage';
import { selectInvoiceTotal } from './invoiceTotal';
import { suggestIssuerFromHeaderOcr } from './issuerHeader';
import { reconstructMultilineSupplier } from './layoutAnalysis';

// Configurar worker do PDF.js para ambiente browser totalmente local
try {
  if (typeof window !== 'undefined') {
    pdfjsLib.GlobalWorkerOptions.workerSrc = './pdf.worker.mjs';
  }
} catch {
  // Tratado com fallback seguro
}

// Evitar presumir fornecedores a partir de uma lista arbitrária.
// Apenas entidades já confirmadas pelo utilizador entram no catálogo local.
export const KNOWN_PT_SUPPLIERS: string[] = [];

export interface TextToken {
  str: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ReconstructedLine {
  y: number;
  tokens: TextToken[];
  text: string;
}

export interface EvaluatedSystemResult {
  supplier?: string;
  tradeName?: string;
  supplierNif?: string;
  documentDate?: string;
  documentNumber?: string;
  amount?: number;
  confidence: {
    date: boolean;
    number: boolean;
    supplier: boolean;
    amount: boolean;
  };
  fieldDetails: {
    supplier: FieldExtractionDetail;
    date: FieldExtractionDetail;
    number: FieldExtractionDetail;
    amount: FieldExtractionDetail;
  };
  warnings: string[];
  qrFiscalData?: PortugueseQrFiscalData;
  issuerNif?: string;
  buyerNif?: string;
  supplierIdentificationSource?: 'QR Fiscal AT' | 'Catálogo Local' | 'Análise Textual Contextual' | 'Manual';
  supplierCandidates?: SupplierCandidateInfo[];
  isSupplierAmbiguous?: boolean;
}

/**
 * Validação rigorosa para impedir que códigos fiscais, referências bancárias,
 * números de documentos, identificações de software ou endereços preencham o campo "Fornecedor".
 */
export function isDisqualifiedAsSupplierName(str: string | undefined | null): boolean {
  if (!str || typeof str !== "string") return true;
  const clean = str.trim();
  if (clean.length < 3 || clean.length > 150) return true;
  // Nunca tratar o resto de um nome partido ("e Ind., Lda.") como empresa completa.
  if (clean.length < 24 && /^(?:e|de|da|do|dos|das)\b/i.test(clean) && /(?:Lda\.?|S\.?A\.?)\s*$/i.test(clean)) return true;

  // 1. ATCUD
  if (/^atcud\b|^atcud\s*:|atcud:[a-z0-9_\-]+|\b[a-z0-9]{4,10}-[0-9]{1,10}\b/i.test(clean)) {
    return true;
  }

  // 2. Números e séries de documentos fiscais
  if (/^(?:fatura|factura|recibo|nota de crédito|nota de débito|v\/ ?factura|doc\.?|documento)\b/i.test(clean)) {
    return true;
  }
  if (/^(?:FT|FR|FS|NC|ND|FA|NE|RC|OR|GT|GR)\s+[A-Za-z0-9_\-\.\/]+/i.test(clean)) {
    return true;
  }
  if (/^\b[A-Za-z0-9]+(?:\/[0-9]+)+\b$/.test(clean)) {
    return true;
  }

  // 3. Totais, valores e dados contabilísticos
  if (/^(?:total|total a pagar|subtotal|montante|valor total|valor a pagar|líquido|ilíquido)\b/i.test(clean)) {
    return true;
  }
  if (/^(?:capital social|cap\.?\s*soc(?:ial)?)\b/i.test(clean)) {
    return true;
  }
  if (/^(?:c\.?r\.?c\.?|conservat[oó]ria|matr[ií]cula)\b/i.test(clean)) {
    return true;
  }
  if (/^(?:sede|morada|estrada|rua|avenida|travessa|alameda|largo|praça|apartado|edif[ií]cio|andar)\b/i.test(clean)) {
    return true;
  }

  // 4. IBAN / Dados bancários e referências de pagamento
  if (/\bPT\d{2}|\b(?:IBAN|SWIFT|BIC|BANCO|CONTA|NIB)\b/i.test(clean)) {
    return true;
  }
  if (/\b(?:entidade|refer[eê]ncia|sub-entidade|mb way|multibanco|terminal)\b/i.test(clean)) {
    return true;
  }

  // 5. Software certificado e sistema informático
  if (/(?:processado por programa|software certificado|certificado n[º°.]?|phc|primavera|sage|moloni|invoicexpress|toconline|keyinvoice)/i.test(clean)) {
    return true;
  }

  // 6. Termos fiscais genéricos e cabeçalhos de tabela
  if (/^(?:original|duplicado|triplicado|c[oó]pia|quadruplicado|via|quadro resumo de iva|taxa|incid[eê]ncia|isento|isen[cç][aã]o|artigo)\b/i.test(clean)) {
    return true;
  }

  // 7. Apenas números, pontuação ou NIF isolado
  if (/^[\d\s.,:\-\/\\#()]+$/.test(clean)) {
    return true;
  }
  if (/^(?:nif|nipc|contribuinte)\s*[:.]?\s*\d{9}/i.test(clean)) {
    return true;
  }
  // Contactos e valores numéricos não são denominações sociais.
  if (/(?:@|www\.|https?:\/\/|\b(?:telefone|telem[oó]vel|tel\.?|fax|contactos?)\s*[:.]?\s*[\d+(])/i.test(clean)) return true;
  if ((clean.match(/\d/g) || []).length >= 7) return true;

  // 8. Cabeçalhos de cliente / adquirente
  if (/^(?:exmo|exma|exmos|exmas|cliente|adquirente|destinat[aá]rio|v\/ nif|v\/ c[oó]digo)\b/i.test(clean)) {
    return true;
  }

  // 9. Datas isoladas
  if (/^\d{1,4}[\/\-.]\d{1,2}[\/\-.]\d{1,4}/.test(clean)) {
    return true;
  }

  return false;
}

/**
 * Converte qualquer representação de valor monetário (portuguesa ou internacional)
 * num número decimal seguro em euros.
 * Ex: "1.234,56 €" -> 1234.56 (nunca 1.234)
 * Ex: "1 234,56" -> 1234.56
 * Ex: "450,00" -> 450
 */
export function parsePtCurrency(val: string | number | undefined | null): number {
  if (val === undefined || val === null) return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  let str = String(val).trim();
  if (!str) return 0;

  // Remove símbolos monetários, letras e espaços
  str = str.replace(/[€\s\u00A0a-zA-Z]/g, '');

  if (str.includes(',') && str.includes('.')) {
    const commaPos = str.lastIndexOf(',');
    const dotPos = str.lastIndexOf('.');
    if (commaPos > dotPos) {
      // Formato português/europeu: 1.234.567,89
      str = str.replace(/\./g, '').replace(',', '.');
    } else {
      // Formato anglo-saxónico: 1,234,567.89
      str = str.replace(/,/g, '');
    }
  } else if (str.includes(',')) {
    const parts = str.split(',');
    if (parts.length > 2) {
      const last = parts.pop();
      str = parts.join('') + '.' + last;
    } else {
      str = str.replace(',', '.');
    }
  } else if (str.includes('.')) {
    const parts = str.split('.');
    if (parts.length > 2) {
      str = parts.join('');
    }
  }

  const parsed = parseFloat(str);
  return isNaN(parsed) ? 0 : parsed;
}

export function formatEuro(amount?: number | null): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '0,00 €';
  return new Intl.NumberFormat('pt-PT', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatPtDate(isoDate?: string | null): string {
  if (!isoDate) return '—';
  const parts = isoDate.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return isoDate;
}

export function buildDiagnostic(
  documentType: ExtractionDiagnostic['documentType'],
  method: ExtractionDiagnostic['method'],
  pagesAnalyzed: number,
  hasDigitalText: boolean,
  charactersExtracted: number,
  ocrStatus: ExtractionDiagnostic['ocrStatus'],
  evaluated: EvaluatedSystemResult
): ExtractionDiagnostic {
  let situation: ExtractionSituation;
  let situationMessage: string;

  const countIdentified =
    (evaluated.supplier ? 1 : 0) +
    (evaluated.documentDate ? 1 : 0) +
    (evaluated.documentNumber ? 1 : 0) +
    (evaluated.amount !== undefined ? 1 : 0);

  const allConfident =
    evaluated.confidence.supplier &&
    evaluated.confidence.date &&
    evaluated.confidence.number &&
    evaluated.confidence.amount;

  if (charactersExtracted < 15) {
    situation = 'SITUACAO_A_FALHA_LEITURA';
    situationMessage =
      'Situação A — Falha de leitura: O documento não possui camada de texto digital legível ou a conversão falhou.';
  } else if (countIdentified === 4 && allConfident) {
    situation = 'SUCESSO_TOTAL';
    situationMessage =
      'Leitura concluída com sucesso: Todos os quatro campos principais foram identificados com forte evidência documental.';
  } else if (countIdentified > 0) {
    situation = 'SITUACAO_C_LEITURA_PARCIAL';
    situationMessage = `Situação C — Leitura parcial: ${countIdentified} de 4 campos identificados. Por favor confirme os campos assinalados.`;
  } else {
    situation = 'SITUACAO_B_FALHA_INTERPRETACAO';
    situationMessage =
      'Situação B — Falha de interpretação: O texto foi extraído, mas os campos principais não atingiram evidência documental suficiente.';
  }

  return {
    documentType,
    method,
    pagesAnalyzed,
    hasDigitalText,
    charactersExtracted,
    ocrStatus,
    situation,
    situationMessage,
    fields: evaluated.fieldDetails,
    warnings: evaluated.warnings,
    qrFiscalData: evaluated.qrFiscalData,
    issuerNif: evaluated.issuerNif,
    buyerNif: evaluated.buyerNif,
    supplierIdentificationSource: evaluated.supplierIdentificationSource,
    supplierCandidates: evaluated.supplierCandidates,
    isSupplierAmbiguous: evaluated.isSupplierAmbiguous,
  };
}

const LEGAL_SUFFIX_REGEX = /\b(?:S\.?\s*A\.?|Lda\.?|Unipessoal(?:,?\s*Lda\.?)?|S\.?\s*G\.?\s*P\.?\s*S\.?|E\.?\s*P\.?\s*E\.?|C\.?\s*R\.?\s*L\.?|Sociedade An[oó]nima|Sociedade por Quotas)(?=\s|[,;.]|$)/i;

function removeOcrNoiseAfterLegalSuffix(name: string): string {
  // Na digitalização, rabiscos junto a "Lda." podem ser confundidos com
  // algarismos e aspas. Remover só ruído curto sem letras após o sufixo legal.
  const matches = [...name.matchAll(new RegExp(LEGAL_SUFFIX_REGEX.source, 'gi'))];
  const last = matches.at(-1);
  if (!last || last.index === undefined) return name;
  const suffixEnd = last.index + last[0].length;
  const trailing = name.slice(suffixEnd);
  if (/^[\s\d"'`´“”‘’.,;:º°-]{0,12}$/u.test(trailing)) {
    return name.slice(0, suffixEnd).trim();
  }
  return name;
}

/**
 * Motor contextual determinístico para identificação de empresas e discriminação estrita
 * entre Emitente (Fornecedor) e Adquirente (Cliente).
 */
export function evaluateCandidateSystem(
  rawText: string,
  lines: ReconstructedLine[],
  clientCompanyName?: string,
  qrFiscalData?: PortugueseQrFiscalData | null,
  confirmedSuppliers: ConfirmedSupplier[] = []
): EvaluatedSystemResult {
  const warnings: string[] = [];
  const fullText = rawText || lines.map((l) => l.text).join('\n');

  // Determinar NIF do emitente e NIF do adquirente
  let targetIssuerNif: string | undefined = qrFiscalData && qrFiscalData.isValid ? qrFiscalData.issuerNif : undefined;
  const targetBuyerNif: string | undefined = qrFiscalData && qrFiscalData.isValid && qrFiscalData.buyerNif !== '999999990'
    ? qrFiscalData.buyerNif
    : undefined;

  // Indício documental forte quando o QR não é descodificado: N.I.F.
  // isolado no cabeçalho do emitente. Não usar campos "V/Nr. Contribuinte"
  // nem simplesmente o primeiro número de nove dígitos do PDF.
  if (!targetIssuerNif) {
    const labeledNifs = (lines.length ? lines.map(line => line.text) : fullText.split('\n'))
      .slice(0, 18)
      .flatMap(line => [...line.matchAll(/\bN\s*\.?\s*I\s*\.?\s*F\s*\.?\s*[:.\s]*\s*(?:PT)?\s*(\d{9})\b/gi)].map(match => match[1]))
      .filter(nif => isValidPortugueseNif(nif));
    const distinctNifs = [...new Set(labeledNifs)];
    if (distinctNifs.length === 1) {
      targetIssuerNif = distinctNifs[0];
      warnings.push('NIF do emitente sugerido a partir do cabeçalho; confirmar por ausência de QR fiscal.');
    }
  }

  // Sem QR fiscal não assumir que o primeiro NIF pertence ao fornecedor:
  // frequentemente é o NIF do cliente, exibido no cabeçalho.

  const clientNameLower = clientCompanyName ? clientCompanyName.toLowerCase().trim() : '';

  // --- 1. IDENTIFICAÇÃO DO FORNECEDOR / EMITENTE ---
  let chosenSupplier: string | undefined = undefined;
  let chosenTradeName: string | undefined = undefined;
  let chosenNif: string | undefined = targetIssuerNif;
  let supplierConfidence = false;
  let supplierReason = '';
  let supplierSource: EvaluatedSystemResult['supplierIdentificationSource'] = 'Análise Textual Contextual';
  const supplierCandidates: SupplierCandidateInfo[] = [];

  // A) PRIORIDADE 1: Catálogo Local Confirmado (Apenas se o nome for válido e não for código fiscal)
  if (targetIssuerNif) {
    const catalogMatch = confirmedSuppliers.find((s) => s.nif === targetIssuerNif);
    if (catalogMatch && !isDisqualifiedAsSupplierName(catalogMatch.name)) {
      chosenSupplier = catalogMatch.name;
      chosenTradeName = catalogMatch.tradeName;
      supplierConfidence = true;
      supplierSource = 'Catálogo Local';
      supplierReason = `Emitente identificado via NIF ${targetIssuerNif} e confirmado no catálogo local como "${catalogMatch.name}".`;
    }
  }

  // B) PRIORIDADE 2: Análise Contextual Detalhada do Documento (Cabeçalho, Corpo e Rodapé Legal)
  if (!chosenSupplier) {
    const lineArray = lines && lines.length > 0 ? lines.map((l) => l.text) : fullText.split('\n');
    const totalLines = lineArray.length;
    const issuerLines = targetIssuerNif
      ? lineArray.flatMap((text, idx) => text.includes(targetIssuerNif) ? [idx] : [])
      : [];
    const buyerLines = targetBuyerNif
      ? lineArray.flatMap((text, idx) => text.includes(targetBuyerNif) ? [idx] : [])
      : [];
    const distanceTo = (idx: number, positions: number[]) => positions.length
      ? Math.min(...positions.map((position) => Math.abs(idx - position)))
      : Infinity;

    // Num PDF digital, a ordem linear do texto pode intercalar colunas.
    // Associar a denominação ao NIF pela posição real dos elementos no PDF
    // permite distinguir emitente e adquirente independentemente do layout.
    const tokens = lines.flatMap((line) => line.tokens || []);
    const issuerTokens = targetIssuerNif
      ? tokens.filter((token) => token.str.includes(targetIssuerNif))
      : [];
    const buyerTokens = targetBuyerNif
      ? tokens.filter((token) => token.str.includes(targetBuyerNif))
      : [];
    const normalizeTokenText = (text: string) => text.normalize('NFKC').replace(/\s+/g, ' ').trim().toLowerCase();
    const spatialDistance = (token: TextToken, anchors: TextToken[]) => anchors.length
      ? Math.min(...anchors.map((anchor) => Math.hypot(
          (token.x - anchor.x) * 1.6,
          token.y - anchor.y
        )))
      : Infinity;

    let inBuyerBlock = false;
    let buyerBlockCountdown = 0;

    const scoredCandidates: {
      name: string;
      tradeName?: string;
      score: number;
      yRatio: number;
      issuerAnchored: boolean;
      hasSpatialEvidence: boolean;
      reasons: string[];
    }[] = [];

    lineArray.forEach((lineText, idx) => {
      const cleanLine = lineText.trim();
      if (!cleanLine) return;
      const yRatio = totalLines > 1 ? idx / (totalLines - 1) : 0.5;

      // Gestão da zona do adquirente (cliente)
      if (/total|a pagar|subtotal|iva\b|processado por|capital social|c\.?r\.?c\.?|sede/i.test(cleanLine) || yRatio >= 0.6) {
        inBuyerBlock = false;
        buyerBlockCountdown = 0;
      } else if (
        /exmo|exma|cliente:|adquirente:|destinat[aá]rio:/i.test(cleanLine) ||
        (targetBuyerNif && cleanLine.includes(targetBuyerNif))
      ) {
        inBuyerBlock = true;
        buyerBlockCountdown = 3;
      } else if (buyerBlockCountdown > 0) {
        buyerBlockCountdown--;
        if (buyerBlockCountdown === 0) inBuyerBlock = false;
      }

      // Segmentar linhas que possam conter dados concatenados com | ou •
      const rawSegments = cleanLine.split(/[|;•]+/).map((s) => s.trim()).filter(Boolean);
      if (!rawSegments.includes(cleanLine) && cleanLine.length <= 120) {
        rawSegments.push(cleanLine);
      }
      // Uma linha reconstruída pode conter texto de duas colunas. Cada
      // token mantém as suas coordenadas, mesmo quando a linha as mistura.
      for (const token of lines[idx]?.tokens || []) {
        const value = token.str.trim();
        if (value && !rawSegments.includes(value)) rawSegments.push(value);
      }

      rawSegments.forEach((seg) => {
        const cleanCand = removeOcrNoiseAfterLegalSuffix(
          seg.replace(/^[\s*#–—:]+|[\s*#–—:]+$/g, '').trim()
        );

        // Eliminar candidatos inválidos ou proibidos
        if (isDisqualifiedAsSupplierName(cleanCand)) return;
        if (clientNameLower && cleanCand.toLowerCase().includes(clientNameLower)) return;
        if (targetBuyerNif && cleanCand.includes(targetBuyerNif)) return;

        let score = 0;
        const reasons: string[] = [];

        // 1. Sufixo legal societário (S.A., Lda, Unipessoal, etc.)
        if (LEGAL_SUFFIX_REGEX.test(cleanCand)) {
          score += 50;
          reasons.push('Sufixo societário oficial (S.A./Lda)');
        }

        // 2. Proximidade direta com o NIF do Emitente
        const neighborhood = lineArray.slice(Math.max(0, idx - 5), Math.min(totalLines, idx + 6)).join(' ');
        let issuerAnchored = false;
        let hasSpatialEvidence = false;
        const currentLineTokens = lines[idx]?.tokens || [];
        const matchingToken = currentLineTokens.find((token) =>
          normalizeTokenText(removeOcrNoiseAfterLegalSuffix(token.str)) === normalizeTokenText(cleanCand)
        );

        if (matchingToken && (issuerTokens.length || buyerTokens.length)) {
          hasSpatialEvidence = true;
          const issuerDistance = spatialDistance(matchingToken, issuerTokens);
          const buyerDistance = spatialDistance(matchingToken, buyerTokens);
          if (buyerDistance < 250 && buyerDistance < issuerDistance * 0.8) {
            score -= 130;
            reasons.push('Posição no PDF associada ao NIF do adquirente (penalizado)');
          } else if (issuerDistance < 250 && issuerDistance < buyerDistance * 0.8) {
            score += 115;
            issuerAnchored = true;
            reasons.push('Posição no PDF associada ao NIF do emitente');
          }
        } else {
          // Fallback para OCR de digitalizações, que não preserva coordenadas.
          const issuerDistance = distanceTo(idx, issuerLines);
          const buyerDistance = distanceTo(idx, buyerLines);
          if (buyerDistance <= 5 && buyerDistance <= issuerDistance) {
            score -= 110;
            reasons.push('Mais próximo do NIF do adquirente (penalizado)');
          } else if (issuerDistance <= 5) {
            score += 65;
            issuerAnchored = true;
            reasons.push('Associado textualmente ao NIF do emitente');
          }
        }

        // 3. Menção de dados legais da sociedade (Capital Social, CRC, Sede, Matrícula)
        if (/capital social|cap\.?\s*soc|conservat[oó]ria|c\.?r\.?c\.?|matr[ií]cula|sede/i.test(neighborhood)) {
          score += 40;
          reasons.push('Contexto legal com matrícula/capital/sede');
        }

        // Não dar pontos por palavras setoriais: não há layout nem
        // vocabulário empresarial universal.

        // 5. Localização no documento
        if (yRatio >= 0.65) {
          score += 25;
          reasons.push('Rodapé de dados legais');
        } else if (yRatio <= 0.25) {
          score += 20;
          reasons.push('Cabeçalho');
        }

        // 6. Penalização se estiver na zona do adquirente
        if (inBuyerBlock && !issuerAnchored) {
          score -= 150;
          reasons.push('Zona do adquirente (penalizado)');
        }

        if (score > 0 && /[A-Za-zÀ-ÿ]{3}/.test(cleanCand)) {
          scoredCandidates.push({
            name: cleanCand,
            score,
            yRatio,
            issuerAnchored,
            hasSpatialEvidence,
            reasons,
          });
        }
      });
    });

    // PDFs com colunas e denominações partidas: reconstruir primeiro o nome
    // completo no bloco do NIF fiscal do emitente, sem inventar sufixos.
    reconstructMultilineSupplier(lines, targetIssuerNif, targetBuyerNif).forEach((entity) => {
      if (!isDisqualifiedAsSupplierName(entity.name)) {
        scoredCandidates.push({
          name: entity.name, score: entity.score,
          yRatio: totalLines > 1 ? entity.sourceLineIndex / (totalLines - 1) : 0.5,
          issuerAnchored: true, hasSpatialEvidence: true, reasons: entity.reasons,
        });
      }
    });

    scoredCandidates.sort((a, b) => b.score - a.score);

    // Identificar eventual nome comercial / marca no cabeçalho
    // Não promover automaticamente palavras de localização (ex.: Portugal)
    // a marcas. Sem rótulo explícito ou catálogo, a marca é opcional.
    const explicitTradeLine = lineArray.find((line) => /^(?:marca|nome comercial|designa[cç][aã]o comercial)\s*[:–-]/i.test(line.trim()));
    const explicitTradeName = explicitTradeLine?.replace(/^(?:marca|nome comercial|designa[cç][aã]o comercial)\s*[:–-]\s*/i, '').trim();
    if (explicitTradeName && !isDisqualifiedAsSupplierName(explicitTradeName)) {
      chosenTradeName = explicitTradeName;
    } else {
      // Marcas sem rótulo explícito: aceitar apenas um nome curto isolado na
      // primeira linha, habitual em cabeçalhos com logótipo textual. Nunca
      // transformar moradas, países e rótulos fiscais em nomes comerciais.
      const firstLine = lineArray[0]?.trim();
      const isPlausibleHeaderBrand = firstLine &&
        /^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s&'’-]{2,40}$/.test(firstLine) &&
        firstLine.split(/\s+/).length <= 4 &&
        !/^(?:portugal|espanha|lisboa|porto|faro|albufeira|moeda|original|duplicado)$/i.test(firstLine) &&
        !LEGAL_SUFFIX_REGEX.test(firstLine) &&
        !isDisqualifiedAsSupplierName(firstLine);
      if (isPlausibleHeaderBrand) chosenTradeName = firstLine;
    }

    // Registo de candidatos para auditoria
    scoredCandidates.slice(0, 5).forEach((c) => {
      supplierCandidates.push({
        name: c.name,
        nif: targetIssuerNif,
        score: c.score,
        reason: c.reasons.join('; '),
      });
    });

    const top = scoredCandidates.length > 0 ? scoredCandidates[0] : null;
    let fiscalAnchor = Boolean(top?.issuerAnchored && chosenNif);
    if (top) {
      const topIdx = lineArray.findIndex((l) => l.includes(top.name));
      if (topIdx !== -1) {
        const nearLines = lineArray.slice(Math.max(0, topIdx - 5), Math.min(totalLines, topIdx + 6));
        const nearText = nearLines.join(' ');
        if (chosenNif) {
          fiscalAnchor = top.issuerAnchored || (!top.hasSpatialEvidence && nearText.includes(chosenNif));
        } else {
          const nifOptions = Array.from(new Set((nearText.match(/\b[1235689]\d{8}\b/g) || [])
            .filter((n) => n !== targetBuyerNif && isValidPortugueseNif(n))));
          // "NIF" isolado também aparece no bloco do comprador. Exigir
          // indícios mais específicos de identificação legal do emitente.
          const legalContext = /matr[ií]cula|capital social|\bcrc\b|\b(?:emitente|fornecedor|vendedor)\b/i.test(nearText);
          if (nifOptions.length === 1 && legalContext && LEGAL_SUFFIX_REGEX.test(top.name)) {
            chosenNif = nifOptions[0];
            fiscalAnchor = true;
          }
        }
      }
    }
    const isLegalName = !!top && LEGAL_SUFFIX_REGEX.test(top.name);
    if (top && top.score >= 70 && isLegalName && fiscalAnchor) {
      chosenSupplier = top.name;
      supplierConfidence = true;
      supplierSource = 'Análise Textual Contextual';
      supplierReason = top.reasons.join('; ');
    } else if (top && top.score >= 50 && isLegalName) {
      chosenSupplier = top.name;
      supplierConfidence = false;
      supplierSource = 'Análise Textual Contextual';
      supplierReason = `Sugestão documental: ${top.reasons.join(', ')}. Confirmação recomendada.`;
    } else {
      // Incerteza total: DEIXAR EM BRANCO para introdução manual, NUNCA preencher com ATCUD
      chosenSupplier = '';
      supplierConfidence = false;
      supplierSource = 'Manual';
      supplierReason = targetIssuerNif
        ? `NIF do emitente identificado (${targetIssuerNif}). Por favor introduza a denominação social do fornecedor.`
        : 'Fornecedor não identificado com evidência suficiente no documento.';
    }
  }

  // --- 2. EXTRAÇÃO DA DATA DO DOCUMENTO ---
  let chosenDate: string | undefined = qrFiscalData?.docDate;
  let dateConfidence = !!chosenDate;
  let dateReason = chosenDate ? 'Data identificada diretamente no QR Code Fiscal da AT.' : '';

  if (!chosenDate) {
    const dateRegexPt = /\b(0?[1-9]|[12][0-9]|3[01])[\/\-.](0?[1-9]|1[012])[\/\-.](20\d\d)\b/g;
    const dateRegexIso = /\b(20\d\d)[\/\-.](0?[1-9]|1[012])[\/\-.](0?[1-9]|[12][0-9]|3[01])\b/g;

    let match: RegExpExecArray | null;
    const candidates: string[] = [];

    while ((match = dateRegexPt.exec(fullText)) !== null) {
      const d = match[1].padStart(2, '0');
      const m = match[2].padStart(2, '0');
      const y = match[3];
      candidates.push(`${y}-${m}-${d}`);
    }

    while ((match = dateRegexIso.exec(fullText)) !== null) {
      const y = match[1];
      const m = match[2].padStart(2, '0');
      const d = match[3].padStart(2, '0');
      candidates.push(`${y}-${m}-${d}`);
    }

    if (candidates.length > 0) {
      chosenDate = candidates[0];
      dateConfidence = true;
      dateReason = `Data extraída do texto do documento: ${formatPtDate(chosenDate)}.`;
    } else {
      dateReason = 'Data não localizada no texto; preenchimento manual necessário.';
    }
  }

  // --- 3. EXTRAÇÃO DO NÚMERO DO DOCUMENTO ---
  let chosenNumber: string | undefined = qrFiscalData?.docNumber;
  let numberConfidence = !!chosenNumber;
  let numberReason = chosenNumber ? 'Número do documento extraído do QR Code Fiscal da AT.' : '';

  if (!chosenNumber) {
    // "Fatura-recibo F26VD/5 003 de 2026-10-20": o número pode ter espaços
    // de formatação; a sigla FR é inferida do tipo impresso no documento.
    const receipt = /\bfatura\s*[-–]?\s*recibo\s+(?:n[º°.]*\s*)?(F[A-Z0-9]{1,8}\s*\/\s*\d(?:[\d ]{0,14}))\s+de\b/i.exec(fullText)
      || lines.map(line => line.text).map(text => /\bfatura\s*[-–]?\s*recibo\s+(?:n[º°.]*\s*)?(F[A-Z0-9]{1,8}\s*\/\s*\d(?:[\d ]{0,14}))\s+de\b/i.exec(text)).find(Boolean);
    if (receipt?.[1]) {
      chosenNumber = 'FR ' + receipt[1].replace(/\s+/g, '');
      numberConfidence = false;
      numberReason = 'Número de fatura-recibo reconstruído do texto; confirmar, pois o QR fiscal não foi lido.';
    }
  }
  if (!chosenNumber) {
    const numPatterns = [
      // Exigir sempre pelo menos um algarismo na identificação.
      // Caso contrário "FA" dentro de "Fatura" seria aceite como série!
      /\b((?:FT|FR|FS|NC|ND|FA)\s+[A-Za-z0-9_.-]*\d[A-Za-z0-9_.\/-]*)\b/i,
      /\b(?:fatura|factura|documento|doc\.?)\s*(?:n[º°.]|número|num\.?)\s*:?\s*([A-Za-z0-9_.-]*\d[A-Za-z0-9_.\/-]*)\b/i,
      /\b([A-Z]{1,4}\s+\d{4}\/\d{1,8})\b/,
      /\b([A-Z]{1,4}\s+\d{1,8}\/\d{1,8})\b/,
    ];

    for (const pat of numPatterns) {
      const m = pat.exec(fullText);
      if (m && m[1]) {
        chosenNumber = m[0].trim();
        numberConfidence = true;
        numberReason = `Número identificado no texto: "${chosenNumber}".`;
        break;
      }
    }

    if (!chosenNumber) {
      numberReason = 'Número do documento não identificado com certeza suficiente.';
    }
  }

  // --- 4. EXTRAÇÃO DO VALOR TOTAL (€) ---
  // QR fiscal: campo O é o total real do documento; referências MB e IVA não são totais.
  // Sem QR, aceitar apenas rótulos explícitos inequívocos. Nunca maximizar números.
  const qrAmount = qrFiscalData?.totalAmount;
  const hasQrAmount = qrAmount !== undefined && Number.isFinite(qrAmount);
  const textTotal = hasQrAmount ? undefined : selectInvoiceTotal(lines.length ? lines : fullText.split('\n').map(text => ({ text })));
  const chosenAmount = hasQrAmount ? qrAmount : textTotal?.amount;
  const amountConfidence = hasQrAmount ? true : Boolean(textTotal?.confidence);
  const amountReason = hasQrAmount
    ? 'Total confirmado pelo campo O do QR fiscal da Autoridade Tributária.'
    : (textTotal?.reason || 'Total não identificado com confiança suficiente.');


  return {
    supplier: chosenSupplier,
    tradeName: chosenTradeName !== chosenSupplier ? chosenTradeName : undefined,
    supplierNif: chosenNif,
    documentDate: chosenDate,
    documentNumber: chosenNumber,
    amount: chosenAmount,
    confidence: {
      supplier: supplierConfidence,
      date: dateConfidence,
      number: numberConfidence,
      amount: amountConfidence,
    },
    fieldDetails: {
      supplier: {
        value: chosenSupplier,
        confidence: supplierConfidence,
        reason: supplierReason,
        candidatesCount: supplierCandidates.length,
      },
      date: {
        value: chosenDate,
        confidence: dateConfidence,
        reason: dateReason,
        candidatesCount: chosenDate ? 1 : 0,
      },
      number: {
        value: chosenNumber,
        confidence: numberConfidence,
        reason: numberReason,
        candidatesCount: chosenNumber ? 1 : 0,
      },
      amount: {
        value: chosenAmount,
        confidence: amountConfidence,
        reason: amountReason,
        candidatesCount: chosenAmount ? 1 : 0,
      },
    },
    warnings,
    qrFiscalData: qrFiscalData || undefined,
    issuerNif: chosenNif,
    buyerNif: qrFiscalData?.buyerNif,
    supplierIdentificationSource: supplierSource,
    supplierCandidates,
  };
}

/**
 * OCR apenas no cabeçalho do emitente quando o nome não existe na camada de texto.
 * Executado localmente, sem rede; o resultado exige sempre confirmação manual.
 */
async function recognizeIssuerLogoHeader(
  imageDataUrl: string,
  issuerOnRight: boolean,
): Promise<string | undefined> {
  let worker: Awaited<ReturnType<typeof createWorker>> | undefined;
  try {
    const image = new Image();
    image.src = imageDataUrl;
    await image.decode();
    const canvas = document.createElement('canvas');
    const cropWidth = Math.floor(image.width * 0.53);
    const cropHeight = Math.floor(image.height * 0.36);
    canvas.width = cropWidth;
    canvas.height = cropHeight;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return undefined;
    const originX = issuerOnRight ? image.width - cropWidth : 0;
    ctx.drawImage(image, originX, 0, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    const assets = new URL('tesseract/', document.baseURI).href;
    worker = await createWorker('por', 1, {
      workerPath: `${assets}worker.min.js`,
      workerBlobURL: false,
      corePath: assets,
      langPath: assets.replace(/\/$/, ''),
      gzip: true,
    });
    const result = await worker.recognize(canvas);
    canvas.width = 0;
    canvas.height = 0;
    return suggestIssuerFromHeaderOcr(result.data.text || '');
  } catch (error) {
    console.warn('OCR local de cabeçalho indisponível:', error);
    return undefined;
  } finally {
    if (worker) await worker.terminate().catch(() => undefined);
  }
}

/**
 * Executa Tesseract.js com caminhos estritamente locais e recursos offline
 */
async function runTesseractOcr(
  imageSource: Blob | File | string,
  onProgress?: (progress: number, stage: string) => void,
  docTypeLabel: 'PDF Digitalizado (sem texto digital)' | 'Imagem (JPG / PNG)' = 'Imagem (JPG / PNG)',
  clientCompanyName?: string,
  qrFiscalData?: PortugueseQrFiscalData | null,
  confirmedSuppliers: ConfirmedSupplier[] = []
): Promise<ExtractedInvoiceData> {
  let worker: Awaited<ReturnType<typeof createWorker>> | undefined;
  try {
    onProgress?.(30, 'A carregar modelo ótico local (Tesseract.js)...');

    // Os trabalhadores Web executam fora do contexto da página. Caminhos
    // relativos deixam de funcionar quando o worker usa um URL blob:.
    const localAssetsUrl = new URL('tesseract/', document.baseURI).href;
    worker = await createWorker('por', 1, {
      workerPath: `${localAssetsUrl}worker.min.js`,
      workerBlobURL: false,
      corePath: localAssetsUrl,
      langPath: localAssetsUrl.replace(/\/$/, ''),
      gzip: true,
      logger: (m) => {
        if (m.status === 'recognizing text' && m.progress) {
          const pct = 30 + Math.round(m.progress * 65);
          onProgress?.(pct, `Reconhecimento ótico em curso (${Math.round(m.progress * 100)}%)...`);
        }
      },
    });

    onProgress?.(50, 'A ler carateres óticos da digitalização...');
    const result = await worker.recognize(imageSource);

    const rawText = result.data.text || '';
    onProgress?.(100, 'Reconhecimento ótico concluído.');

    const lines: ReconstructedLine[] = rawText
      .split('\n')
      .map((l, idx) => ({ y: 1000 - idx * 20, tokens: [], text: l.trim() }))
      .filter((l) => l.text.length > 0);

    const parsed = evaluateCandidateSystem(
      rawText,
      lines,
      clientCompanyName,
      qrFiscalData,
      confirmedSuppliers
    );

    const diagnostic = buildDiagnostic(
      docTypeLabel,
      'OCR Local Offline (Tesseract.js)',
      1,
      false,
      rawText.length,
      'Concluído Localmente',
      parsed
    );

    return {
      documentDate: parsed.documentDate,
      documentNumber: parsed.documentNumber,
      supplier: parsed.supplier,
      tradeName: parsed.tradeName,
      supplierNif: parsed.supplierNif,
      amount: parsed.amount,
      confidence: parsed.confidence,
      rawText,
      method: 'tesseract_ocr',
      diagnostic,
    };
  } catch (error) {
    console.error('Falha no Tesseract OCR local:', error);
    onProgress?.(100, 'OCR indisponível. Preenchimento manual ativo.');

    const emptyDiag: ExtractionDiagnostic = {
      documentType: docTypeLabel,
      method: 'Heurística Local de Fallback',
      pagesAnalyzed: 1,
      hasDigitalText: false,
      charactersExtracted: 0,
      ocrStatus: 'Falhou',
      situation: 'SITUACAO_A_FALHA_LEITURA',
      situationMessage: 'Falha de leitura: O motor OCR encontrou um erro no processamento da imagem.',
      fields: {
        supplier: { confidence: false, reason: 'OCR falhou', candidatesCount: 0 },
        date: { confidence: false, reason: 'OCR falhou', candidatesCount: 0 },
        number: { confidence: false, reason: 'OCR falhou', candidatesCount: 0 },
        amount: { confidence: false, reason: 'OCR falhou', candidatesCount: 0 },
      },
      warnings: ['Não foi possível executar o reconhecimento ótico nesta imagem.'],
    };

    return {
      confidence: { date: false, number: false, supplier: false, amount: false },
      rawText: '',
      method: 'fallback_heuristic',
      diagnostic: emptyDiag,
    };
  } finally {
    // Terminar também em caso de erro evita trabalhadores órfãos e fugas de memória.
    if (worker) {
      try {
        await worker.terminate();
      } catch (terminationError) {
        console.warn('Não foi possível terminar o trabalhador OCR:', terminationError);
      }
    }
  }
}

/**
 * Função principal de extração de dados do documento com prioridade máxima para PDF digital,
 * leitura de QR Code fiscal e fallback offline com OCR Tesseract.
 */
export async function extractDocumentData(
  file: File | Blob,
  fileName: string,
  onProgress?: (progress: number, stage: string) => void,
  clientCompanyName?: string
): Promise<ExtractedInvoiceData> {
  const isPdf = file.type === 'application/pdf' || fileName.toLowerCase().endsWith('.pdf');
  let qrFiscalData: PortugueseQrFiscalData | null = null;
  const confirmedSuppliers = await storage.getConfirmedSuppliers();

  // 1. PROCESSAMENTO DE DOCUMENTOS PDF
  if (isPdf) {
    onProgress?.(10, 'A analisar estrutura do ficheiro PDF...');
    let loadingTask: ReturnType<typeof pdfjsLib.getDocument> | undefined;
    try {
      const arrayBuffer = await file.arrayBuffer();
      loadingTask = pdfjsLib.getDocument({
        data: arrayBuffer,
        useWorkerFetch: false,
      });

      const pdfDoc = await loadingTask.promise;
      const numPages = pdfDoc.numPages;
      let totalExtractedText = '';
      const reconstructedLines: ReconstructedLine[] = [];
      let firstPageImage: string | undefined;
      let firstPageWidth = 0;

      // O QR fiscal pode estar no verso ou na última página; não assumir que
      // fica sempre na primeira. Limitar a análise visual a quatro páginas.
      const pagesToInspect = Array.from(new Set([
        1,
        Math.min(2, numPages),
        Math.min(3, numPages),
        numPages,
      ])).sort((a, b) => a - b);

      for (const pageNumber of pagesToInspect) {
        onProgress?.(20, `A analisar página ${pageNumber} de ${numPages}...`);
        try {
          const page = await pdfDoc.getPage(pageNumber);
           if (pageNumber === 1) firstPageWidth = page.getViewport({ scale: 1 }).width;
          const textContent = await page.getTextContent();

          textContent.items.forEach((item: any) => {
            if ('str' in item && item.str.trim()) {
              totalExtractedText += item.str + ' ';
              // Evita juntar linhas de páginas diferentes à mesma altura.
              const y = Math.round(item.transform[5]) - (pageNumber - 1) * 10000;
              let line = reconstructedLines.find((l) => Math.abs(l.y - y) <= 4);
              if (!line) {
                line = { y, tokens: [], text: '' };
                reconstructedLines.push(line);
              }
              line.tokens.push({
                str: item.str,
                x: item.transform[4],
                y,
                width: item.width,
                height: item.height,
              });
              line.text += (line.text ? ' ' : '') + item.str;
            }
          });

          // É preciso renderizar a primeira página para OCR. As restantes só
          // precisam de renderização enquanto ainda não se encontrou QR fiscal.
          if (pageNumber === 1 || !qrFiscalData) {
            const viewport = page.getViewport({ scale: 1.8 });
            const canvas = document.createElement('canvas');
            canvas.width = Math.ceil(viewport.width);
            canvas.height = Math.ceil(viewport.height);
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            if (!ctx) throw new Error('O navegador não permitiu criar um canvas para leitura.');

            await page.render({ canvasContext: ctx, viewport, canvas } as any).promise;
            if (!qrFiscalData) qrFiscalData = await scanQrFromCanvasRobust(canvas);
            if (pageNumber === 1) firstPageImage = canvas.toDataURL('image/png');

            canvas.width = 0;
            canvas.height = 0;
          }
        } catch (pageError) {
          if (pageNumber === 1) throw pageError;
          console.warn(`Não foi possível analisar a página ${pageNumber} para QR fiscal:`, pageError);
        }
      }

      reconstructedLines.sort((a, b) => b.y - a.y);

      // SE EXISTIR TEXTO DIGITAL SUFICIENTE (PDF Digital Nativo)
      if (totalExtractedText.trim().length >= 25) {
        onProgress?.(70, 'A interpretar campos da fatura...');
        const parsed = evaluateCandidateSystem(
          totalExtractedText,
          reconstructedLines,
          clientCompanyName,
          qrFiscalData,
          confirmedSuppliers
        );

        // Logótipo pode ser uma imagem sem texto no PDF (associações, IPSS,
        // marcas e entidades sem Lda./S.A.). Ler só o cabeçalho do emitente.
        if ((!parsed.supplier || !parsed.confidence.supplier) && firstPageImage && parsed.supplierNif) {
          onProgress?.(75, 'A verificar visualmente o nome do emitente no cabeçalho...');
          const nifToken = reconstructedLines.flatMap(line => line.tokens)
            .find(token => token.str.replace(/\D/g, '').includes(parsed.supplierNif!));
          const issuerOnRight = Boolean(nifToken && firstPageWidth > 0 && nifToken.x > firstPageWidth / 2);
          const visualName = await recognizeIssuerLogoHeader(firstPageImage, issuerOnRight);
          if (visualName && !isDisqualifiedAsSupplierName(visualName) && visualName.length >= (parsed.supplier?.length || 0)) {
            parsed.supplier = visualName;
            parsed.confidence.supplier = false;
            parsed.supplierIdentificationSource = 'Análise Textual Contextual';
            parsed.fieldDetails.supplier = {
              value: visualName, confidence: false,
              reason: 'Nome sugerido por OCR local do cabeçalho; confirmar a denominação antes de guardar.',
              candidatesCount: 1,
            };
          }
        }


        onProgress?.(100, 'Leitura de PDF concluída com sucesso.');

        const diagnostic = buildDiagnostic(
          'PDF Digital (com texto selecionável)',
          'Extração Direta Estruturada (PDF.js)',
          pagesToInspect.length,
          true,
          totalExtractedText.length,
          'Não necessário (PDF Digital)',
          parsed
        );

        return {
          documentDate: parsed.documentDate,
          documentNumber: parsed.documentNumber,
          supplier: parsed.supplier,
          tradeName: parsed.tradeName,
          supplierNif: parsed.supplierNif,
          amount: parsed.amount,
          confidence: parsed.confidence,
          rawText: totalExtractedText,
          method: 'direct_pdf_text',
          diagnostic,
        };
      }

      // SE NÃO HOUVER TEXTO DIGITAL: PDF DIGITALIZADO (Fallback para OCR Tesseract local)
      onProgress?.(30, 'PDF sem texto selecionável. A ativar OCR Tesseract local...');
      if (!firstPageImage) throw new Error('Não foi possível renderizar a primeira página para OCR.');
      return await runTesseractOcr(
        firstPageImage,
        onProgress,
        'PDF Digitalizado (sem texto digital)',
        clientCompanyName,
        qrFiscalData,
        confirmedSuppliers
      );
    } catch (pdfErr) {
      console.warn('Erro ao processar PDF via pdfjs-dist:', pdfErr);
      onProgress?.(100, 'Erro ao abrir PDF. Preenchimento manual ativo.');

      return {
        confidence: { date: false, number: false, supplier: false, amount: false },
        rawText: '',
        method: 'fallback_heuristic',
      };
    } finally {
      await loadingTask?.destroy();
    }
  }

  // 2. PROCESSAMENTO DE IMAGENS (JPG / PNG)
  onProgress?.(15, 'A analisar imagem e procurar código QR fiscal...');
  try {
    qrFiscalData = await scanQrFromImageBlob(file);
  } catch (qrErr) {
    console.warn('Deteção de QR falhou:', qrErr);
  }

  onProgress?.(30, 'A inicializar OCR local Tesseract para imagem...');
  return await runTesseractOcr(
    file,
    onProgress,
    'Imagem (JPG / PNG)',
    clientCompanyName,
    qrFiscalData,
    confirmedSuppliers
  );
}
