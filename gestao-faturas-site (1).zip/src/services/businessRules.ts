import { AppSettings, AuditEvent, DuplicateCheckResult, InvoiceRecord, InvoiceStatus, Signer } from '../types';
import { storage } from './storage';

/**
 * Calcula a diferença de dias de calendário entre duas datas (AAAA-MM-DD).
 * Se endDate não for fornecida, utiliza a data local atual.
 */
export function calculateDaysElapsed(startDateStr?: string | null, endDateStr?: string | null): number {
  if (!startDateStr) return 0;
  
  const start = new Date(startDateStr + 'T00:00:00');
  const end = endDateStr ? new Date(endDateStr + 'T00:00:00') : new Date();
  
  // Normalizar para meia-noite para cálculo de dias de calendário
  const startMidnight = new Date(start.getFullYear(), start.getMonth(), start.getDate());
  const endMidnight = new Date(end.getFullYear(), end.getMonth(), end.getDate());
  
  const diffTime = endMidnight.getTime() - startMidnight.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

/**
 * Determina o nível de urgência visual com base nos limiares configuráveis
 */
export function getDelayAlertLevel(
  invoice: InvoiceRecord,
  settings: AppSettings
): {
  level: 'normal' | 'warning' | 'critical';
  days: number;
  label: string;
} {
  if (invoice.status !== 'EM_ASSINATURA' || !invoice.deliveryDate) {
    return { level: 'normal', days: 0, label: '' };
  }

  const days = calculateDaysElapsed(invoice.deliveryDate);

  if (days >= settings.criticalDaysThreshold) {
    return {
      level: 'critical',
      days,
      label: `Devolução pendente há ${days} dias`,
    };
  }

  if (days >= settings.warningDaysThreshold) {
    return {
      level: 'warning',
      days,
      label: `Aguarda devolução há ${days} dias`,
    };
  }

  return {
    level: 'normal',
    days,
    label: `Em assinatura há ${days} ${days === 1 ? 'dia' : 'dias'}`,
  };
}

/**
 * Calcula o estado da fatura de forma estrita a partir dos campos
 */
export function computeInvoiceStatus(invoice: {
  deliveryDate?: string | null;
  assignedTo?: string | null;
  returnDate?: string | null;
}): InvoiceStatus {
  if (invoice.returnDate && invoice.returnDate.trim().length > 0) {
    return 'DEVOLVIDA';
  }
  if (invoice.deliveryDate && invoice.assignedTo && invoice.deliveryDate.trim().length > 0) {
    return 'EM_ASSINATURA';
  }
  return 'POR_ENTREGAR';
}

/**
 * Validação rigorosa de datas: Data de devolução não pode ser anterior à data de entrega
 */
export function validateReturnDate(deliveryDate?: string | null, returnDate?: string | null): { valid: boolean; error?: string } {
  if (!returnDate || returnDate.trim().length === 0) {
    return { valid: false, error: 'A data de devolução é de preenchimento obrigatório.' };
  }

  if (deliveryDate && returnDate < deliveryDate) {
    return {
      valid: false,
      error: `A data de devolução (${formatDisplayDate(returnDate)}) não pode ser anterior à data de entrega física (${formatDisplayDate(deliveryDate)}).`,
    };
  }

  return { valid: true };
}

function formatDisplayDate(isoDate: string): string {
  const parts = isoDate.split('-');
  return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : isoDate;
}

/**
 * Verificação de faturas duplicadas (mesmo Fornecedor e mesmo Número de Documento)
 */
export function checkForDuplicates(
  supplier: string,
  documentNumber: string,
  amount: number,
  documentDate: string,
  existingInvoices: InvoiceRecord[],
  currentInvoiceId?: string
): DuplicateCheckResult {
  const cleanSupplier = supplier.trim().toLowerCase();
  const cleanDocNum = documentNumber.trim().toLowerCase().replace(/[\s/._-]/g, '');

  const matches = existingInvoices.filter((inv) => {
    if (currentInvoiceId && inv.id === currentInvoiceId) return false;
    const existingCleanSupplier = inv.supplier.trim().toLowerCase();
    const existingCleanDocNum = inv.documentNumber.trim().toLowerCase().replace(/[\s/._-]/g, '');

    const sameSupplier =
      existingCleanSupplier === cleanSupplier ||
      existingCleanSupplier.includes(cleanSupplier) ||
      cleanSupplier.includes(existingCleanSupplier);

    const sameDocNumber = existingCleanDocNum === cleanDocNum;

    return sameSupplier && sameDocNumber;
  });

  const exactMatch = matches.some((inv) => {
    return inv.amount === amount && inv.documentDate === documentDate;
  });

  return {
    isDuplicate: matches.length > 0,
    matchedInvoices: matches,
    exactMatch,
  };
}

/**
 * Gera um documento PDF de exemplo em Blob real utilizando canvas local
 */
export function createSampleInvoicePdfBlob(supplier: string, docNum: string, date: string, amount: number): Blob {
  const canvas = document.createElement('canvas');
  canvas.width = 800;
  canvas.height = 1100;
  const ctx = canvas.getContext('2d')!;

  // Fundo branco papel
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Borda elegante
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.strokeRect(40, 40, canvas.width - 80, canvas.height - 80);

  // Cabeçalho da Fatura
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(supplier.toUpperCase(), 70, 110);

  ctx.fillStyle = '#64748B';
  ctx.font = '14px sans-serif';
  ctx.fillText('DOCUMENTO CONTABILÍSTICO ORIGINAL (CÓPIA FÍSICA PARA ASSINATURA)', 70, 140);
  ctx.fillText('NIPC: 509 123 456 · Sede: Lisboa, Portugal', 70, 160);

  // Linha divisória
  ctx.strokeStyle = '#CBD5E1';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(70, 190);
  ctx.lineTo(730, 190);
  ctx.stroke();

  // Caixa de identificação da fatura
  ctx.fillStyle = '#F8FAFC';
  ctx.fillRect(70, 220, 660, 100);
  ctx.strokeStyle = '#E2E8F0';
  ctx.strokeRect(70, 220, 660, 100);

  ctx.fillStyle = '#334155';
  ctx.font = 'bold 15px sans-serif';
  ctx.fillText(`NÚMERO DO DOCUMENTO: ${docNum}`, 90, 260);
  ctx.fillText(`DATA DE EMISSÃO: ${formatDisplayDate(date)}`, 90, 290);

  ctx.fillText('CLIENTE: EMPRESA MODELO, LDA.', 420, 260);
  ctx.fillText('NIF CLIENTE: 501 987 654', 420, 290);

  // Tabela de Itens
  ctx.fillStyle = '#1E293B';
  ctx.fillRect(70, 360, 660, 35);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 13px sans-serif';
  ctx.fillText('DESCRIÇÃO DOS SERVIÇOS / FORNECIMENTOS', 85, 383);
  ctx.fillText('QTD', 480, 383);
  ctx.fillText('TOTAL LÍQ.', 620, 383);

  ctx.fillStyle = '#334155';
  ctx.font = '14px sans-serif';
  ctx.fillText('Fornecimento mensal e consumos certificados', 85, 430);
  ctx.fillText('1', 490, 430);
  ctx.fillText(`${(amount * 0.77).toFixed(2)} €`, 620, 430);

  ctx.fillText('Despesas de expediente e taxa regulamentar', 85, 470);
  ctx.fillText('1', 490, 470);
  ctx.fillText(`${(amount * 0.04).toFixed(2)} €`, 620, 470);

  // Caixa de Totais
  ctx.fillStyle = '#F1F5F9';
  ctx.fillRect(440, 560, 290, 130);
  ctx.strokeStyle = '#CBD5E1';
  ctx.strokeRect(440, 560, 290, 130);

  ctx.fillStyle = '#475569';
  ctx.font = '14px sans-serif';
  ctx.fillText('Incidência (Base Tributável):', 455, 595);
  ctx.fillText(`${(amount * 0.81).toFixed(2)} €`, 640, 595);

  ctx.fillText('IVA (Taxa Normal 23%):', 455, 625);
  ctx.fillText(`${(amount * 0.19).toFixed(2)} €`, 640, 625);

  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 18px sans-serif';
  ctx.fillText('TOTAL A PAGAR:', 455, 665);
  ctx.fillText(`${amount.toFixed(2)} €`, 620, 665);

  // Caixa de Carimbo Físico de Assinatura
  ctx.strokeStyle = '#94A3B8';
  ctx.setLineDash([5, 5]);
  ctx.strokeRect(70, 750, 660, 180);
  ctx.setLineDash([]);

  ctx.fillStyle = '#64748B';
  ctx.font = 'italic 14px sans-serif';
  ctx.fillText('ESPAÇO RESERVADO PARA ASSINATURA FÍSICA DO RESPONSÁVEL', 90, 785);
  ctx.fillText('Rubrica / Assinatura do Aprovador: ____________________________________________', 90, 850);
  ctx.fillText('Data da Validação Física: _____ / _____ / 2026', 90, 890);

  // Rodapé
  ctx.fillStyle = '#94A3B8';
  ctx.font = '11px sans-serif';
  ctx.fillText('Certificado pelo Software Contabilístico em conformidade com o Decreto-Lei 28/2019 de Portugal.', 70, 1030);

  // Criar dataURL -> Blob
  const dataUrl = canvas.toDataURL('image/png');
  const byteString = atob(dataUrl.split(',')[1]);
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  return new Blob([ab], { type: 'image/png' });
}

/**
 * Povoa a base de dados com responsáveis e faturas de teste caso esteja vazia
 */
export async function seedInitialDemoData(): Promise<void> {
  const existingInvoices = await storage.getInvoices();
  const existingSigners = await storage.getSigners();

  if (existingInvoices.length > 0 && existingSigners.length > 0) {
    return; // Já tem dados
  }

  // 1. Criar Responsáveis
  const defaultSigners: Signer[] = [
    { id: 'sig-marco', name: 'Marco António', department: 'Direção de Operações', active: true, createdAt: new Date().toISOString() },
    { id: 'sig-ana', name: 'Ana Santos', department: 'Recursos Humanos', active: true, createdAt: new Date().toISOString() },
    { id: 'sig-carlos', name: 'Carlos Silva', department: 'Direção Técnica & IT', active: true, createdAt: new Date().toISOString() },
    { id: 'sig-sofia', name: 'Sofia Ramos', department: 'Marketing & Vendas', active: true, createdAt: new Date().toISOString() },
    { id: 'sig-miguel', name: 'Miguel Costa', department: 'Logística', active: true, createdAt: new Date().toISOString() },
  ];

  for (const s of defaultSigners) {
    await storage.saveSigner(s);
  }

  // Calcular datas relativas para os cenários exatos de teste:
  // Data atual de referência
  const now = new Date();
  const formatDateStr = (d: Date) => d.toISOString().slice(0, 10);

  const dMinus3 = new Date(now.getTime() - 3 * 24 * 3600 * 1000);   // Há 3 dias (Marco - normal)
  const dMinus9 = new Date(now.getTime() - 9 * 24 * 3600 * 1000);   // Há 9 dias (Ana - aviso amarelo)
  const dMinus16 = new Date(now.getTime() - 16 * 24 * 3600 * 1000); // Há 16 dias (Carlos - atraso vermelho)
  const dMinus25 = new Date(now.getTime() - 25 * 24 * 3600 * 1000);
  const dMinus18 = new Date(now.getTime() - 18 * 24 * 3600 * 1000);
  const dMinus1 = new Date(now.getTime() - 1 * 24 * 3600 * 1000);

  const demoInvoicesSeed: {
    inv: Omit<InvoiceRecord, 'history'>;
    docDate: string;
    events: AuditEvent[];
  }[] = [
    {
      inv: {
        id: 'demo-inv-1',
        documentDate: formatDateStr(new Date(dMinus3.getTime() - 5 * 24 * 3600 * 1000)),
        documentNumber: 'FT 2026/0491',
        supplier: 'EDP Comercial',
        amount: 412.50,
        status: 'EM_ASSINATURA',
        assignedTo: 'Marco António',
        deliveryDate: formatDateStr(dMinus3),
        notes: 'Fatura de eletricidade da sede relativa ao mês anterior.',
        fileId: 'file-demo-1',
        fileName: 'Fatura_EDP_2026_0491.png',
        fileType: 'image/png',
        fileSize: 125400,
        createdAt: new Date(dMinus3.getTime() - 3600 * 1000).toISOString(),
        updatedAt: dMinus3.toISOString(),
        isDemo: true,
      },
      docDate: formatDateStr(dMinus3),
      events: [
        {
          id: 'evt-1-1',
          timestamp: new Date(dMinus3.getTime() - 3600 * 1000).toISOString(),
          effectiveDate: formatDateStr(new Date(dMinus3.getTime() - 5 * 24 * 3600 * 1000)),
          type: 'CRIACAO',
          description: 'Fatura registada na aplicação pelo departamento de contabilidade.',
          author: 'Departamento de Contabilidade',
        },
        {
          id: 'evt-1-2',
          timestamp: dMinus3.toISOString(),
          effectiveDate: formatDateStr(dMinus3),
          type: 'ENTREGA',
          description: `Fatura entregue fisicamente a Marco António em ${formatDisplayDate(formatDateStr(dMinus3))}.`,
          author: 'Departamento de Contabilidade',
        },
      ],
    },
    {
      inv: {
        id: 'demo-inv-2',
        documentDate: formatDateStr(new Date(dMinus9.getTime() - 4 * 24 * 3600 * 1000)),
        documentNumber: 'FT ST/2026/1842',
        supplier: 'Staples Portugal',
        amount: 289.40,
        status: 'EM_ASSINATURA',
        assignedTo: 'Ana Santos',
        deliveryDate: formatDateStr(dMinus9),
        notes: 'Material de escritório e arquivo trimestral.',
        fileId: 'file-demo-2',
        fileName: 'Fatura_Staples_1842.png',
        fileType: 'image/png',
        fileSize: 118200,
        createdAt: new Date(dMinus9.getTime() - 7200 * 1000).toISOString(),
        updatedAt: dMinus9.toISOString(),
        isDemo: true,
      },
      docDate: formatDateStr(dMinus9),
      events: [
        {
          id: 'evt-2-1',
          timestamp: new Date(dMinus9.getTime() - 7200 * 1000).toISOString(),
          effectiveDate: formatDateStr(new Date(dMinus9.getTime() - 4 * 24 * 3600 * 1000)),
          type: 'CRIACAO',
          description: 'Fatura registada na aplicação pelo departamento de contabilidade.',
          author: 'Departamento de Contabilidade',
        },
        {
          id: 'evt-2-2',
          timestamp: dMinus9.toISOString(),
          effectiveDate: formatDateStr(dMinus9),
          type: 'ENTREGA',
          description: `Fatura entregue fisicamente a Ana Santos em ${formatDisplayDate(formatDateStr(dMinus9))}.`,
          author: 'Departamento de Contabilidade',
        },
      ],
    },
    {
      inv: {
        id: 'demo-inv-3',
        documentDate: formatDateStr(new Date(dMinus16.getTime() - 6 * 24 * 3600 * 1000)),
        documentNumber: 'FAT 2026/9931',
        supplier: 'MEO - Serviços de Comunicações e Multimédia, S.A.',
        amount: 1240.80,
        status: 'EM_ASSINATURA',
        assignedTo: 'Carlos Silva',
        deliveryDate: formatDateStr(dMinus16),
        notes: 'Comunicações fibra e VPN inter-edifícios. Aguarda assinatura urgente.',
        fileId: 'file-demo-3',
        fileName: 'Fatura_MEO_9931.png',
        fileType: 'image/png',
        fileSize: 132900,
        createdAt: new Date(dMinus16.getTime() - 3600 * 1000).toISOString(),
        updatedAt: dMinus16.toISOString(),
        isDemo: true,
      },
      docDate: formatDateStr(dMinus16),
      events: [
        {
          id: 'evt-3-1',
          timestamp: new Date(dMinus16.getTime() - 3600 * 1000).toISOString(),
          effectiveDate: formatDateStr(new Date(dMinus16.getTime() - 6 * 24 * 3600 * 1000)),
          type: 'CRIACAO',
          description: 'Fatura registada na aplicação pelo departamento de contabilidade.',
          author: 'Departamento de Contabilidade',
        },
        {
          id: 'evt-3-1',
          timestamp: dMinus16.toISOString(),
          effectiveDate: formatDateStr(dMinus16),
          type: 'ENTREGA',
          description: `Fatura entregue fisicamente a Carlos Silva em ${formatDisplayDate(formatDateStr(dMinus16))}.`,
          author: 'Departamento de Contabilidade',
        },
      ],
    },
    {
      inv: {
        id: 'demo-inv-4',
        documentDate: formatDateStr(dMinus1),
        documentNumber: 'FT GLP/2026/8812',
        supplier: 'Galp Energia',
        amount: 875.00,
        status: 'POR_ENTREGAR',
        notes: 'Documento recebido ontem pelo correio. Por entregar para assinatura.',
        fileId: 'file-demo-4',
        fileName: 'Fatura_Galp_8812.png',
        fileType: 'image/png',
        fileSize: 110400,
        createdAt: dMinus1.toISOString(),
        updatedAt: dMinus1.toISOString(),
        isDemo: true,
      },
      docDate: formatDateStr(dMinus1),
      events: [
        {
          id: 'evt-4-1',
          timestamp: dMinus1.toISOString(),
          effectiveDate: formatDateStr(dMinus1),
          type: 'CRIACAO',
          description: 'Fatura registada na aplicação como "Por Entregar".',
          author: 'Departamento de Contabilidade',
        },
      ],
    },
    {
      inv: {
        id: 'demo-inv-5',
        documentDate: formatDateStr(new Date(dMinus25.getTime() - 4 * 24 * 3600 * 1000)),
        documentNumber: 'FT WRT/2026/3041',
        supplier: 'Worten Equipamentos do Lar',
        amount: 649.99,
        status: 'DEVOLVIDA',
        assignedTo: 'Marco António',
        deliveryDate: formatDateStr(dMinus25),
        returnDate: formatDateStr(dMinus18),
        notes: 'Equipamento audiovisual para a sala de reuniões. Devolvida assinada.',
        fileId: 'file-demo-5',
        fileName: 'Fatura_Worten_3041.png',
        fileType: 'image/png',
        fileSize: 115000,
        createdAt: new Date(dMinus25.getTime() - 3600 * 1000).toISOString(),
        updatedAt: dMinus18.toISOString(),
        isDemo: true,
      },
      docDate: formatDateStr(dMinus25),
      events: [
        {
          id: 'evt-5-1',
          timestamp: new Date(dMinus25.getTime() - 3600 * 1000).toISOString(),
          effectiveDate: formatDateStr(new Date(dMinus25.getTime() - 4 * 24 * 3600 * 1000)),
          type: 'CRIACAO',
          description: 'Fatura registada na aplicação.',
          author: 'Departamento de Contabilidade',
        },
        {
          id: 'evt-5-2',
          timestamp: dMinus25.toISOString(),
          effectiveDate: formatDateStr(dMinus25),
          type: 'ENTREGA',
          description: `Fatura entregue fisicamente a Marco António em ${formatDisplayDate(formatDateStr(dMinus25))}.`,
          author: 'Departamento de Contabilidade',
        },
        {
          id: 'evt-5-3',
          timestamp: dMinus18.toISOString(),
          effectiveDate: formatDateStr(dMinus18),
          type: 'DEVOLUCAO',
          description: `Fatura devolvida e rececionada pela contabilidade em ${formatDisplayDate(formatDateStr(dMinus18))}.`,
          author: 'Departamento de Contabilidade',
        },
      ],
    },
  ];

  // Dados de demonstração também não guardam anexos.
  for (const item of demoInvoicesSeed) {
    const fullRecord: InvoiceRecord = {
      ...item.inv,
      history: item.events,
    };
    await storage.saveInvoice(asDemoMetadata(fullRecord));
  }
}

function asDemoMetadata(record: InvoiceRecord): InvoiceRecord {
  const { fileId, fileName, fileType, fileSize, ocrRawText, ...metadata } = record;
  return metadata;
}
