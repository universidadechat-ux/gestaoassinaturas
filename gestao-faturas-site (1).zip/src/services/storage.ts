import { isDisqualifiedAsSupplierName } from "./extractor";
import { AppSettings, AuditEvent, ConfirmedSupplier, InvoiceRecord, Signer, StoredFile } from '../types';

const DB_NAME = 'GestaoFaturasDB';
const DB_VERSION = 2;

export interface StorageEstimateResult {
  usedBytes: number;
  quotaBytes: number;
  percent: number;
  supported: boolean;
}

export interface BackupPayload {
  version: number;
  timestamp: string;
  source: string;
  recordCount: number;
  fileCount: number;
  checksum: string;
  invoices: InvoiceRecord[];
  signers: Signer[];
  settings: AppSettings;
  confirmedSuppliers?: ConfirmedSupplier[];
  files: {
    id: string;
    fileName: string;
    fileType: string;
    fileSize: number;
    base64Data: string;
    createdAt: string;
  }[];
}

// Incluir nas novas cópias apenas os metadados necessários ao controlo.
function asAdministrativeRecord(invoice: InvoiceRecord): InvoiceRecord {
  const { fileId, fileName, fileType, fileSize, ocrRawText, ...administrative } = invoice;
  return administrative;
}

async function sha256(data: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, '0')).join('');
}

declare global {
  interface Window {
    electronAPI?: {
      isElectron: boolean;
      getDataPath: () => Promise<string>;
      openDataFolder: () => Promise<void>;
      getInvoices: () => Promise<InvoiceRecord[]>;
      saveInvoice: (invoice: InvoiceRecord) => Promise<boolean>;
      deleteInvoice: (id: string) => Promise<boolean>;
      getSigners: () => Promise<Signer[]>;
      saveSigner: (signer: Signer) => Promise<boolean>;
      deleteSigner: (id: string) => Promise<boolean>;
      getSettings: () => Promise<AppSettings | null>;
      saveSettings: (settings: AppSettings) => Promise<boolean>;
      getConfirmedSuppliers: () => Promise<ConfirmedSupplier[]>;
      saveConfirmedSupplier: (supplier: ConfirmedSupplier) => Promise<boolean>;
      deleteConfirmedSupplier: (nif: string) => Promise<boolean>;
      saveFile: (fileId: string, meta: { fileName: string; fileType: string; fileSize: number }, base64Data: string) => Promise<boolean>;
      getFile: (fileId: string) => Promise<{ id: string; fileName: string; fileType: string; fileSize: number; base64Data: string } | null>;
      deleteFile: (fileId: string) => Promise<boolean>;
      exportFullBackup: () => Promise<string>;
      importFullBackup: (jsonContent: string) => Promise<{ success: boolean; recordsRestored: number; filesRestored: number; message: string }>;
      getStorageEstimate: () => Promise<StorageEstimateResult>;
    };
  }
}

class StorageService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  isElectronApp(): boolean {
    return typeof window !== 'undefined' && !!window.electronAPI?.isElectron;
  }

  async getDataPath(): Promise<string | null> {
    if (this.isElectronApp() && window.electronAPI) {
      try {
        return await window.electronAPI.getDataPath();
      } catch (err) {
        console.error('Erro ao obter caminho de dados Electron:', err);
      }
    }
    return null;
  }

  async openDataFolder(): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      try {
        await window.electronAPI.openDataFolder();
      } catch (err) {
        console.error('Erro ao abrir pasta de dados Electron:', err);
      }
    }
  }

  private getDB(): Promise<IDBDatabase> {
    if (!this.dbPromise) {
      this.dbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;

          // Store faturas (metadados leves, sem blobs ou base64)
          if (!db.objectStoreNames.contains('invoices')) {
            const invoiceStore = db.createObjectStore('invoices', { keyPath: 'id' });
            invoiceStore.createIndex('status', 'status', { unique: false });
            invoiceStore.createIndex('assignedTo', 'assignedTo', { unique: false });
            invoiceStore.createIndex('supplier', 'supplier', { unique: false });
            invoiceStore.createIndex('documentNumber', 'documentNumber', { unique: false });
            invoiceStore.createIndex('isDemo', 'isDemo', { unique: false });
          }

          // Store isolado de ficheiros originais (Blobs binários)
          if (!db.objectStoreNames.contains('files')) {
            db.createObjectStore('files', { keyPath: 'id' });
          }

          // Store responsáveis
          if (!db.objectStoreNames.contains('signers')) {
            const signerStore = db.createObjectStore('signers', { keyPath: 'id' });
            signerStore.createIndex('active', 'active', { unique: false });
            signerStore.createIndex('name', 'name', { unique: false });
          }

          // Store configurações
          if (!db.objectStoreNames.contains('settings')) {
            db.createObjectStore('settings', { keyPath: 'key' });
          }

          // Store catálogo de fornecedores confirmados (NIF como chave)
          if (!db.objectStoreNames.contains('confirmedSuppliers')) {
            const supplierStore = db.createObjectStore('confirmedSuppliers', { keyPath: 'nif' });
            supplierStore.createIndex('name', 'name', { unique: false });
            supplierStore.createIndex('tradeName', 'tradeName', { unique: false });
          }
        };

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
    }
    return this.dbPromise;
  }

  // --- FATURAS ---
  async getInvoices(): Promise<InvoiceRecord[]> {
    if (this.isElectronApp() && window.electronAPI) {
      return await window.electronAPI.getInvoices();
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('invoices', 'readonly');
      const store = tx.objectStore('invoices');
      const request = store.getAll();
      request.onsuccess = () => {
        // São registos de faturas, NÃO objetos ConfirmedSupplier.
        // Nunca filtrar ou eliminar dados contabilísticos durante a leitura.
        resolve((request.result || []) as InvoiceRecord[]);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveInvoice(invoice: InvoiceRecord): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.saveInvoice(invoice);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('invoices', 'readwrite');
      const store = tx.objectStore('invoices');
      const request = store.put(invoice);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteInvoice(id: string): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.deleteInvoice(id);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('invoices', 'readwrite');
      const store = tx.objectStore('invoices');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --- FICHEIROS (ARMAZENAMENTO ISOLADO) ---
  async saveFile(fileId: string, blob: Blob, meta: { fileName: string; fileType: string; fileSize?: number }): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const res = reader.result as string;
          const base64 = res.includes(',') ? res.split(',')[1] : res;
          resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
      await window.electronAPI.saveFile(
        fileId,
        {
          fileName: meta.fileName,
          fileType: meta.fileType,
          fileSize: meta.fileSize || blob.size,
        },
        base64Data
      );
      return;
    }

    const db = await this.getDB();
    const storedFile: StoredFile = {
      id: fileId,
      fileName: meta.fileName,
      fileType: meta.fileType,
      fileSize: meta.fileSize || blob.size,
      blob,
      createdAt: new Date().toISOString(),
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction('files', 'readwrite');
      const store = tx.objectStore('files');
      const request = store.put(storedFile);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getFile(fileId: string): Promise<StoredFile | null> {
    if (this.isElectronApp() && window.electronAPI) {
      const res = await window.electronAPI.getFile(fileId);
      if (!res) return null;
      try {
        const byteCharacters = atob(res.base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: res.fileType || 'application/pdf' });
        return {
          id: res.id,
          fileName: res.fileName,
          fileType: res.fileType,
          fileSize: res.fileSize,
          blob,
          createdAt: new Date().toISOString(),
        };
      } catch (e) {
        console.error('Erro ao descodificar ficheiro do Electron:', e);
        return null;
      }
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('files', 'readonly');
      const store = tx.objectStore('files');
      const request = store.get(fileId);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async deleteFile(fileId: string): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.deleteFile(fileId);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('files', 'readwrite');
      const store = tx.objectStore('files');
      const request = store.delete(fileId);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --- RESPONSÁVEIS ---
  async getSigners(): Promise<Signer[]> {
    if (this.isElectronApp() && window.electronAPI) {
      return await window.electronAPI.getSigners();
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('signers', 'readonly');
      const store = tx.objectStore('signers');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async saveSigner(signer: Signer): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.saveSigner(signer);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('signers', 'readwrite');
      const store = tx.objectStore('signers');
      const request = store.put(signer);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async deleteSigner(id: string): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.deleteSigner(id);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('signers', 'readwrite');
      const store = tx.objectStore('signers');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --- DEFINIÇÕES ---
  async getSettings(): Promise<AppSettings> {
    const defaultSettings: AppSettings = {
      warningDaysThreshold: 7,
      criticalDaysThreshold: 14,
      companyName: 'Empresa Modelo, Lda.',
      departmentName: 'Departamento de Contabilidade',
    };

    if (this.isElectronApp() && window.electronAPI) {
      const s = await window.electronAPI.getSettings();
      return s ? { ...defaultSettings, ...s } : defaultSettings;
    }

    const db = await this.getDB();
    return new Promise((resolve) => {
      const tx = db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const request = store.get('app_settings');
      request.onsuccess = () => {
        if (request.result && request.result.value) {
          resolve({ ...defaultSettings, ...request.result.value });
        } else {
          resolve(defaultSettings);
        }
      };
      request.onerror = () => resolve(defaultSettings);
    });
  }

  async saveSettings(settings: AppSettings): Promise<void> {
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.saveSettings(settings);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      const request = store.put({ key: 'app_settings', value: settings });
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --- CATÁLOGO DE FORNECEDORES CONFIRMADOS (APRENDIZAGEM LOCAL) ---
  async getConfirmedSuppliers(): Promise<ConfirmedSupplier[]> {
    if (this.isElectronApp() && window.electronAPI) {
      return await window.electronAPI.getConfirmedSuppliers();
    }

    const db = await this.getDB();
    return new Promise((resolve) => {
      if (!db.objectStoreNames.contains('confirmedSuppliers')) {
        return resolve([]);
      }
      const tx = db.transaction('confirmedSuppliers', 'readonly');
      const store = tx.objectStore('confirmedSuppliers');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => resolve([]);
    });
  }

  async getConfirmedSupplier(nif: string): Promise<ConfirmedSupplier | null> {
    const cleanNif = nif.replace(/\D/g, '');
    if (!cleanNif || cleanNif.length !== 9) return null;

    if (this.isElectronApp() && window.electronAPI) {
      const all = await window.electronAPI.getConfirmedSuppliers();
      return all.find((s) => s.nif === cleanNif) || null;
    }

    const db = await this.getDB();
    return new Promise((resolve) => {
      if (!db.objectStoreNames.contains('confirmedSuppliers')) {
        return resolve(null);
      }
      const tx = db.transaction('confirmedSuppliers', 'readonly');
      const store = tx.objectStore('confirmedSuppliers');
      const request = store.get(cleanNif);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => resolve(null);
    });
  }

  async saveConfirmedSupplier(supplier: ConfirmedSupplier): Promise<void> {
    const cleanNif = supplier.nif.replace(/\D/g, '');
    if (!cleanNif || cleanNif.length !== 9) return;
    if (!supplier.name || isDisqualifiedAsSupplierName(supplier.name)) {
      console.warn('Tentativa de gravar fornecedor desqualificado no catálogo ignorada:', supplier.name);
      return;
    }

    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.saveConfirmedSupplier({
        ...supplier,
        nif: cleanNif,
        lastUsedAt: supplier.lastUsedAt || new Date().toISOString(),
      });
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      if (!db.objectStoreNames.contains('confirmedSuppliers')) {
        return resolve();
      }
      const tx = db.transaction('confirmedSuppliers', 'readwrite');
      const store = tx.objectStore('confirmedSuppliers');
      const request = store.put({
        ...supplier,
        nif: cleanNif,
        lastUsedAt: supplier.lastUsedAt || new Date().toISOString(),
      });
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async recordConfirmedSupplierUsage(nif: string, name: string, tradeName?: string): Promise<void> {
    if (!name || isDisqualifiedAsSupplierName(name)) {
      console.warn('Tentativa de memorizar fornecedor inválido bloqueada:', name);
      return;
    }
    const cleanNif = nif.replace(/\D/g, '');
    if (!cleanNif || cleanNif.length !== 9) return;
    const existing = await this.getConfirmedSupplier(cleanNif);
    if (existing) {
      await this.saveConfirmedSupplier({
        ...existing,
        name: name || existing.name,
        tradeName: tradeName || existing.tradeName,
        verifiedCount: (existing.verifiedCount || 1) + 1,
        lastUsedAt: new Date().toISOString(),
      });
    } else {
      await this.saveConfirmedSupplier({
        nif,
        name,
        tradeName,
        verifiedCount: 1,
        lastUsedAt: new Date().toISOString(),
        source: 'automatic',
      });
    }
  }

  async deleteConfirmedSupplier(nif: string): Promise<void> {
    const cleanNif = nif.replace(/\D/g, '');
    if (this.isElectronApp() && window.electronAPI) {
      await window.electronAPI.deleteConfirmedSupplier(cleanNif);
      return;
    }

    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      if (!db.objectStoreNames.contains('confirmedSuppliers')) {
        return resolve();
      }
      const tx = db.transaction('confirmedSuppliers', 'readwrite');
      const store = tx.objectStore('confirmedSuppliers');
      const request = store.delete(cleanNif);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // --- ESTIMATIVA DE ESPAÇO ---
  async getStorageEstimate(): Promise<StorageEstimateResult> {
    if (this.isElectronApp() && window.electronAPI) {
      return await window.electronAPI.getStorageEstimate();
    }

    if (navigator.storage && navigator.storage.estimate) {
      try {
        const estimate = await navigator.storage.estimate();
        const used = estimate.usage || 0;
        const quota = estimate.quota || 0;
        const percent = quota > 0 ? (used / quota) * 100 : 0;
        return {
          usedBytes: used,
          quotaBytes: quota,
          percent: Math.round(percent * 10) / 10,
          supported: true,
        };
      } catch {
        // fallback
      }
    }
    return {
      usedBytes: 0,
      quotaBytes: 0,
      percent: 0,
      supported: false,
    };
  }

  // --- ELIMINAR DADOS DE DEMONSTRAÇÃO ---
  async deleteDemoData(): Promise<number> {
    const invoices = await this.getInvoices();
    const demoInvoices = invoices.filter((inv) => inv.isDemo === true);
    let count = 0;

    for (const inv of demoInvoices) {
      if (inv.fileId) {
        await this.deleteFile(inv.fileId).catch(() => {});
      }
      await this.deleteInvoice(inv.id);
      count++;
    }

    return count;
  }

  // --- CÓPIA DE SEGURANÇA DE METADADOS (BACKUP JSON) ---
  async exportFullBackup(): Promise<string> {
    const invoices = (await this.getInvoices()).map(asAdministrativeRecord);
    const signers = await this.getSigners();
    const settings = await this.getSettings();
    const confirmedSuppliers = await this.getConfirmedSuppliers();

    // Não ler sequer a tabela de anexos antigos.
    const integrityData = JSON.stringify({ invoices, signers, settings, confirmedSuppliers });

    const payload: BackupPayload = {
      version: 3,
      timestamp: new Date().toISOString(),
      source: 'GestaoFaturasControloAssinaturas',
      recordCount: invoices.length,
      fileCount: 0,
      checksum: await sha256(integrityData),
      invoices,
      signers,
      settings,
      confirmedSuppliers,
      files: [],
    };

    return JSON.stringify(payload, null, 2);
  }

  // --- RESTAURO COMPLETO COM VERIFICAÇÃO RIGOROSA DE INTEGRIDADE ---
  async importFullBackup(jsonString: string): Promise<{
    success: boolean;
    recordsRestored: number;
    filesRestored: number;
    signersRestored?: number;
    message: string;
    errors?: string[];
  }> {
    try {
      // FASE 1: Validação de Sintaxe JSON e Estrutura Geral
      let payload: BackupPayload;
      try {
        payload = JSON.parse(jsonString);
      } catch {
        return {
          success: false,
          recordsRestored: 0,
          filesRestored: 0,
          message: 'Falha de integridade: O ficheiro fornecido não é um JSON válido ou encontra-se corrompido.',
        };
      }

      if (!payload || typeof payload !== 'object') {
        return {
          success: false,
          recordsRestored: 0,
          filesRestored: 0,
          message: 'Falha de integridade: Estrutura do ficheiro de cópia de segurança inválida.',
        };
      }

      if (!payload.invoices || !Array.isArray(payload.invoices)) {
        return {
          success: false,
          recordsRestored: 0,
          filesRestored: 0,
          message: 'Falha de integridade: A lista de faturas está ausente ou inválida.',
        };
      }

      const integrityErrors: string[] = [];

      if (payload.version >= 3) {
        const canonical = JSON.stringify({
          invoices: payload.invoices,
          signers: payload.signers,
          settings: payload.settings,
          confirmedSuppliers: payload.confirmedSuppliers,
        });
        if (payload.files?.length) {
          integrityErrors.push('Cópia administrativa inválida: contém documentos anexos.');
        }
        if (!payload.checksum || payload.checksum !== await sha256(canonical)) {
          integrityErrors.push('Assinatura de integridade SHA-256 inválida.');
        }
      }

      // Versões antigas podem conter anexos. Nunca são lidos nem importados.
      // Na versão 3, a assinatura SHA-256 protege os campos administrativos.

      // FASE 3: Verificar os campos administrativos obrigatórios.
      for (const inv of payload.invoices) {
        if (!inv.id || !inv.documentNumber || !inv.supplier) {
          integrityErrors.push(`Registo de fatura com campos obrigatórios em falta (ID: ${inv.id || 'desconhecido'}).`);
          continue;
        }
        // Ficheiros e texto integral OCR de cópias antigas são descartados.
      }

      // Se existir QUALQUER erro de integridade, ABORTAR IMEDIATAMENTE sem tocar na base de dados
      if (integrityErrors.length > 0) {
        const summaryMsg = integrityErrors.length === 1
          ? integrityErrors[0]
          : `${integrityErrors.length} falhas de integridade detetadas: ${integrityErrors.slice(0, 3).join('; ')}${integrityErrors.length > 3 ? ` ...e mais ${integrityErrors.length - 3} falhas.` : ''}`;
        
        return {
          success: false,
          recordsRestored: 0,
          filesRestored: 0,
          message: `Falha na verificação de integridade dos dados: ${summaryMsg}. A base de dados existente foi mantida intacta e não sofreu alterações parciais.`,
          errors: integrityErrors,
        };
      }

      // FASE 4: Gravação Segura na Base de Dados (Apenas executada após 100% de sucesso nas fases anteriores)
      if (payload.settings) {
        await this.saveSettings(payload.settings);
      }

      let signersRestored = 0;
      if (payload.signers && Array.isArray(payload.signers)) {
        for (const signer of payload.signers) {
          if (signer.id && signer.name) {
            await this.saveSigner(signer);
            signersRestored++;
          }
        }
      }

      if (payload.confirmedSuppliers && Array.isArray(payload.confirmedSuppliers)) {
        for (const sup of payload.confirmedSuppliers) {
          if (sup.nif && sup.name) {
            await this.saveConfirmedSupplier(sup);
          }
        }
      }

      const filesRestored = 0;

      let invoiceCount = 0;
      for (const inv of payload.invoices) {
        await this.saveInvoice(asAdministrativeRecord(inv));
        invoiceCount++;
      }

      return {
        success: true,
        recordsRestored: invoiceCount,
        filesRestored: filesRestored,
        signersRestored: signersRestored,
        message: `Restauro concluído: ${invoiceCount} faturas e ${signersRestored} responsáveis. Por privacidade, não foram importados PDFs, imagens nem texto integral do OCR.`,
      };
    } catch (error: any) {
      return {
        success: false,
        recordsRestored: 0,
        filesRestored: 0,
        message: `Erro durante o restauro: ${error.message || 'Erro desconhecido'}. Alguns registos poderão ter sido gravados antes do erro; confirme o histórico e a cópia de segurança.`,
      };
    }
  }
}

export const storage = new StorageService();
