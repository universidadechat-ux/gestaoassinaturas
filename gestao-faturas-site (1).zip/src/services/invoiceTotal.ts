export interface InvoiceLineForTotal { text: string }
export interface TotalResult { amount?: number; confidence: boolean; reason: string }

/** Nunca escolher o maior número do documento; exigir indicação explícita e moeda com casas decimais. */
export function selectInvoiceTotal(lines: InvoiceLineForTotal[]): TotalResult {
  const money = String.raw`(-?(?:\d{1,3}(?:[. ]\d{3})+|\d+)[,.]\d{2})`;
  const strong = new RegExp(String.raw`\b(?:TOTAL\s*\(\s*EUR\s*\)|TOTAL\s+(?:A\s+PAGAR|DO\s+DOCUMENTO|DA\s+FATURA|GERAL)|VALOR\s+TOTAL(?:\s+A\s+PAGAR)?|MONTANTE\s+A\s+PAGAR)\s*[:–-]?\s*€?\s*` + money + String.raw`\b`, 'gi');
  const weak = new RegExp(String.raw`^\s*TOTAL\s*[:–-]?\s*€?\s*` + money + String.raw`\s*€?\s*$`, 'i');
  const hits: number[] = [];
  for (const raw of lines.map(l => l.text)) {
    const text = raw.replace(/\s+/g, ' ').trim();
    if (/conta\s+corrente|pagamento\s+total\s+da\s+conta|total\s+(?:do\s+)?iva|total\s+descontos|total\s+il[ií]quido|total\s+reten[cç][aã]o/i.test(text) && !/TOTAL\s*\(\s*EUR\s*\)/i.test(text)) continue;
    for (const m of text.matchAll(strong)) {
      const rawValue = m[1];
      const value = Number(rawValue.replace(/[ .](?=\d{3}(?:[.,]|$))/g, '').replace(',', '.'));
      if (Number.isFinite(value)) hits.push(value);
    }
    const basic = weak.exec(text);
    if (basic) {
      const value = Number(basic[1].replace(/[ .](?=\d{3}(?:[.,]|$))/g, '').replace(',', '.'));
      if (Number.isFinite(value)) hits.push(value);
    }
  }
  const unique = [...new Set(hits.map(v => Math.round(v * 100) / 100))];
  if (unique.length === 1) return {amount: unique[0],confidence:true,reason:'Valor validado por rótulo explícito de total do documento.'};
  if (unique.length > 1) return {confidence:false,reason:'Vários totais possíveis; é necessário confirmar manualmente.'};
  return {confidence:false,reason:'Total não confirmado pelo QR fiscal nem por um rótulo inequívoco. Preencher manualmente.'};
}
