import * as XLSX from 'xlsx';
import { InvoiceRecord } from '../types';
import { calculateDaysElapsed } from './businessRules';
import { formatPtDate } from './extractor';

export function exportInvoicesToExcel(
  invoices: InvoiceRecord[],
  fileNamePrefix: string = 'Controlo_Faturas_Assinaturas'
): void {
  const rows = invoices.map((inv) => {
    const daysInSigning =
      inv.status === 'EM_ASSINATURA'
        ? calculateDaysElapsed(inv.deliveryDate)
        : inv.status === 'DEVOLVIDA'
        ? calculateDaysElapsed(inv.deliveryDate, inv.returnDate)
        : 0;

    let statusLabel = 'Por Entregar';
    if (inv.status === 'EM_ASSINATURA') statusLabel = 'Em Assinatura';
    if (inv.status === 'DEVOLVIDA') statusLabel = 'Devolvida';

    return {
      'Data Documento': formatPtDate(inv.documentDate),
      'Nº Documento': inv.documentNumber,
      'Fornecedor': inv.supplier,
      'Valor (€)': inv.amount,
      'Entregue a': inv.assignedTo || '—',
      'Data Entrega': formatPtDate(inv.deliveryDate),
      'Data Devolução': formatPtDate(inv.returnDate),
      'Estado': statusLabel,
      'Dias em Assinatura': inv.deliveryDate ? daysInSigning : '—',
      'Observações': inv.notes || '',
      'Tipo Registo': inv.isDemo ? 'Demonstração' : 'Real',
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(rows);

  // Definir larguras de coluna ajustadas para legibilidade profissional
  worksheet['!cols'] = [
    { wch: 15 }, // Data Documento
    { wch: 18 }, // Nº Documento
    { wch: 30 }, // Fornecedor
    { wch: 14 }, // Valor (€)
    { wch: 22 }, // Entregue a
    { wch: 15 }, // Data Entrega
    { wch: 15 }, // Data Devolução
    { wch: 16 }, // Estado
    { wch: 18 }, // Dias em Assinatura
    { wch: 35 }, // Observações
    { wch: 14 }, // Tipo Registo
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Faturas');

  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10);
  const fullFileName = `${fileNamePrefix}_${dateStr}.xlsx`;

  XLSX.writeFile(workbook, fullFileName);
}
