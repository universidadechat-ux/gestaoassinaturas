import jsQR from 'jsqr';
import { PortugueseQrFiscalData } from '../types';

/**
 * Validação do dígito de controlo do NIF português (Módulo 11)
 * Suporta pessoas singulares (1, 2, 3), coletivas (5, 6), entidades especiais (8, 9)
 * e o NIF genérico de Consumidor Final (999999990).
 */
export function isValidPortugueseNif(nifStr: string): boolean {
  const clean = nifStr.replace(/\D/g, '');
  if (clean.length !== 9) return false;
  if (clean === '999999990') return true; // Consumidor Final

  const firstDigit = clean[0];
  if (!['1', '2', '3', '5', '6', '8', '9'].includes(firstDigit)) {
    return false;
  }

  let sum = 0;
  for (let i = 0; i < 8; i++) {
    sum += parseInt(clean[i], 10) * (9 - i);
  }

  const remainder = sum % 11;
  const expectedCheckDigit = remainder < 2 ? 0 : 11 - remainder;
  return parseInt(clean[8], 10) === expectedCheckDigit;
}

/**
 * Descodifica o formato oficial de Código QR Fiscal da Autoridade Tributária (Portaria n.º 195/2020)
 * Campos obrigatórios AT:
 * A: NIF do emitente
 * B: NIF do adquirente (ou 999999990)
 * C: País do adquirente (ex: PT)
 * D: Tipo de documento (FT, FS, FR, NC, ND)
 * E: Estado do documento (N = Normal, A = Anulado, R = Recuperado)
 * F: Data do documento (YYYYMMDD ou YYYY-MM-DD)
 * G: Identificação única do documento (ex: FT 2026/416 ou Série/Número)
 * H: ATCUD (ou 0 se isento)
 * N: Total de impostos
 * O: Total do documento com impostos
 * Q: 4 carateres da assinatura/hash
 * R: Número do certificado
 */
export function parsePortugueseAtQrCode(rawText: string): PortugueseQrFiscalData | null {
  if (!rawText || typeof rawText !== 'string') return null;

  const trimmed = rawText.trim();
  // Verificar se contém marcadores típicos do QR da AT
  if (!trimmed.includes('A:') && !trimmed.includes('*A:') && !trimmed.startsWith('A:')) {
    return null;
  }

  // Separar tokens por '*' ou quebras de linha
  const tokens = trimmed.split(/[*;\r\n]+/);
  const fields: Record<string, string> = {};

  for (const token of tokens) {
    const colonIdx = token.indexOf(':');
    if (colonIdx > 0) {
      const key = token.substring(0, colonIdx).trim().toUpperCase();
      const val = token.substring(colonIdx + 1).trim();
      fields[key] = val;
    }
  }

  const issuerNif = fields['A'] ? fields['A'].replace(/\D/g, '') : undefined;
  const buyerNif = fields['B'] ? fields['B'].replace(/\D/g, '') : undefined;

  // Um QR Fiscal AT válido deve conter pelo menos o NIF do emitente no campo A
  if (!issuerNif || issuerNif.length !== 9) {
    return null;
  }

  // Normalizar Data (F)
  let docDate: string | undefined = undefined;
  const rawDate = fields['F'];
  if (rawDate) {
    if (/^\d{8}$/.test(rawDate)) {
      // YYYYMMDD
      const y = rawDate.substring(0, 4);
      const m = rawDate.substring(4, 6);
      const d = rawDate.substring(6, 8);
      docDate = `${y}-${m}-${d}`;
    } else if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
      docDate = rawDate;
    } else if (/^\d{2}[\/.-]\d{2}[\/.-]\d{4}$/.test(rawDate)) {
      const parts = rawDate.split(/[\/.-]/);
      docDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
    }
  }

  // Normalizar Montante Total (O)
  let totalAmount: number | undefined = undefined;
  if (fields['O']) {
    const parsedAmt = parseFloat(fields['O'].replace(',', '.'));
    if (!isNaN(parsedAmt)) {
      totalAmount = parsedAmt;
    }
  }

  // Normalizar Total Imposto (N)
  let taxAmount: number | undefined = undefined;
  if (fields['N']) {
    const parsedTax = parseFloat(fields['N'].replace(',', '.'));
    if (!isNaN(parsedTax)) {
      taxAmount = parsedTax;
    }
  }

  return {
    raw: trimmed,
    issuerNif,
    buyerNif,
    buyerCountry: fields['C'],
    docType: fields['D'],
    docState: fields['E'],
    docDate,
    docNumber: fields['G'],
    atcud: fields['H'],
    taxAmount,
    totalAmount,
    hash: fields['Q'],
    certificate: fields['R'],
    isValid: true,
  };
}

/**
 * Lê código QR a partir de um HTMLCanvasElement no browser utilizando jsQR
 */
export function scanQrFromCanvas(canvas: HTMLCanvasElement): PortugueseQrFiscalData | null {
  try {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return null;

    // 1. Tentar ler no canvas inteiro
    const fullImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    let code = jsQR(fullImageData.data, fullImageData.width, fullImageData.height, {
      inversionAttempts: 'attemptBoth',
    });

    if (code && code.data) {
      const parsed = parsePortugueseAtQrCode(code.data);
      if (parsed) return parsed;
    }

    // 2. Se o canvas for de alta resolução, o QR pode estar num dos cantos
    // (comum nos cantos inferior direito, inferior esquerdo ou superior direito)
    const regions = [
      // Metade inferior direita
      { x: Math.floor(canvas.width * 0.5), y: Math.floor(canvas.height * 0.5), w: Math.ceil(canvas.width * 0.5), h: Math.ceil(canvas.height * 0.5) },
      // Metade inferior esquerda
      { x: 0, y: Math.floor(canvas.height * 0.5), w: Math.ceil(canvas.width * 0.5), h: Math.ceil(canvas.height * 0.5) },
      // Metade superior direita
      { x: Math.floor(canvas.width * 0.5), y: 0, w: Math.ceil(canvas.width * 0.5), h: Math.ceil(canvas.height * 0.5) },
      // Canto inferior central
      { x: Math.floor(canvas.width * 0.25), y: Math.floor(canvas.height * 0.6), w: Math.ceil(canvas.width * 0.5), h: Math.ceil(canvas.height * 0.4) },
    ];

    for (const r of regions) {
      if (r.w > 40 && r.h > 40) {
        const subImageData = ctx.getImageData(r.x, r.y, r.w, r.h);
        code = jsQR(subImageData.data, subImageData.width, subImageData.height, {
          inversionAttempts: 'attemptBoth',
        });
        if (code && code.data) {
          const parsed = parsePortugueseAtQrCode(code.data);
          if (parsed) return parsed;
        }
      }
    }
  } catch (err) {
    console.warn('Erro ao ler QR code do canvas:', err);
  }

  return null;
}

/**
 * Segundo motor de leitura QR: primeiro jsQR, depois BarcodeDetector local
 * quando disponível no navegador. Nenhuma imagem é transmitida.
 */
export async function scanQrFromCanvasRobust(canvas: HTMLCanvasElement): Promise<PortugueseQrFiscalData | null> {
  const initial = scanQrFromCanvas(canvas);
  if (initial) return initial;
  try {
    type NativeResult = { rawValue?: string };
    type NativeScanner = { detect(input: HTMLCanvasElement): Promise<NativeResult[]> };
    type NativeConstructor = new (opts: { formats: string[] }) => NativeScanner;
    const globalWithBarcode = window as unknown as { BarcodeDetector?: NativeConstructor };
    if (globalWithBarcode.BarcodeDetector) {
      const scanner = new globalWithBarcode.BarcodeDetector({ formats: ['qr_code'] });
      for (const code of await scanner.detect(canvas)) {
        const parsed = parsePortugueseAtQrCode(code.rawValue || '');
        if (parsed) return parsed;
      }
    }
  } catch (error) {
    console.info('Leitura nativa QR indisponível; a aplicar fallback local:', error);
  }
  // Redimensionar a zona inferior/central para QRs pequenos no documento.
  const regions = [
    { x: 0.18, y: 0.65, w: 0.65, h: 0.30 },
    { x: 0.05, y: 0.52, w: 0.50, h: 0.46 },
    { x: 0.43, y: 0.52, w: 0.55, h: 0.46 },
  ];
  for (const r of regions) {
    const cropped = document.createElement('canvas');
    cropped.width = Math.max(1, Math.round(canvas.width * r.w * 1.5));
    cropped.height = Math.max(1, Math.round(canvas.height * r.h * 1.5));
    const ctx = cropped.getContext('2d', { willReadFrequently: true });
    if (!ctx) continue;
    ctx.drawImage(canvas,
      Math.round(canvas.width * r.x), Math.round(canvas.height * r.y),
      Math.round(canvas.width * r.w), Math.round(canvas.height * r.h),
      0, 0, cropped.width, cropped.height);
    const qr = scanQrFromCanvas(cropped);
    cropped.width = 0;
    cropped.height = 0;
    if (qr) return qr;
  }
  return null;
}

/**
 * Lê código QR a partir de um Blob ou File de Imagem no browser
 */
export async function scanQrFromImageBlob(blob: Blob | File): Promise<PortugueseQrFiscalData | null> {
  if (typeof window === 'undefined') return null;

  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(blob);

    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          URL.revokeObjectURL(url);
          return resolve(null);
        }
        ctx.drawImage(img, 0, 0);
        const result = scanQrFromCanvas(canvas);
        URL.revokeObjectURL(url);
        resolve(result);
      } catch (err) {
        console.warn('Falha no processamento de imagem para QR:', err);
        URL.revokeObjectURL(url);
        resolve(null);
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(null);
    };

    img.src = url;
  });
}
