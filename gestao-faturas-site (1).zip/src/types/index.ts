export type InvoiceStatus = 'POR_ENTREGAR' | 'EM_ASSINATURA' | 'DEVOLVIDA';

export interface AuditEvent {
  id: string;
  timestamp: string;       // Data e hora de gravação no sistema (ISO)
  effectiveDate: string;   // Data efetiva do movimento (YYYY-MM-DD)
  type: 'CRIACAO' | 'ENTREGA' | 'DEVOLUCAO' | 'EDICAO' | 'CANCELAMENTO_DEVOLUCAO' | 'NOTA';
  description: string;     // Ex: "Fatura entregue a Marco em 13/10/2026"
  author: string;          // Ex: "Departamento de Contabilidade"
}

export interface InvoiceRecord {
  id: string;
  documentDate: string;     // Data de emissão da fatura (YYYY-MM-DD)
  documentNumber: string;   // Número do documento (ex: FT 2026/0491)
  supplier: string;         // Nome do fornecedor (ex: EDP Comercial)
  amount: number;           // Valor em EUR (pode ser negativo para notas de crédito)
  status: InvoiceStatus;    // Calculado automaticamente a partir dos dados
  assignedTo?: string;      // Nome do responsável pela assinatura física
  deliveryDate?: string;    // Data de entrega física (YYYY-MM-DD)
  returnDate?: string;      // Data de devolução física à contabilidade (YYYY-MM-DD)
  notes?: string;           // Observações administrativas
  fileId?: string;          // Referência ao ficheiro binário na tabela de ficheiros
  fileName?: string;        // Nome original do ficheiro
  fileType?: string;        // application/pdf, image/jpeg, image/png
  fileSize?: number;        // Tamanho em bytes
  createdAt: string;        // Timestamp ISO de entrada no sistema
  updatedAt: string;        // Timestamp ISO de última atualização
  ocrRawText?: string;      // Texto integral extraído pelo OCR/extrator
  history: AuditEvent[];    // Histórico individual e imutável de movimentos
  supplierNif?: string;     // NIF de 9 dígitos do fornecedor/emitente (se identificado)
  isDemo?: boolean;         // Marcador explícito de dados fictícios para teste
  isManual?: boolean;       // Marcador de fatura inserida manualmente (sem documento anexo inicial)
}

export interface ConfirmedSupplier {
  nif: string;              // NIF português de 9 dígitos (chave primária)
  name: string;             // Denominação social oficial (ex: Mundo Aquático, S.A.)
  tradeName?: string;       // Nome comercial ou marca (ex: Zoomarine)
  verifiedCount: number;    // Número de faturas confirmadas com este NIF
  lastUsedAt: string;       // Timestamp ISO da última fatura
  source: 'automatic' | 'manual' | 'qr';
}

export interface PortugueseQrFiscalData {
  raw: string;
  issuerNif?: string;       // Campo A: NIF do emitente
  buyerNif?: string;        // Campo B: NIF do adquirente (ou 999999990)
  buyerCountry?: string;    // Campo C: País do adquirente (PT)
  docType?: string;         // Campo D: Tipo de documento (FT, FR, FS, NC, ND)
  docState?: string;        // Campo E: Estado (N, A, R)
  docDate?: string;         // Campo F: Data (YYYY-MM-DD)
  docNumber?: string;       // Campo G: Identificação do documento (ex: FT 2026/416)
  atcud?: string;           // Campo H: ATCUD
  taxAmount?: number;       // Campo N: Total impostos
  totalAmount?: number;     // Campo O: Total com impostos
  hash?: string;            // Campo Q: Assinatura/hash
  certificate?: string;     // Campo R: Nº do certificado
  isValid: boolean;
}

export interface SupplierCandidateInfo {
  name: string;
  nif?: string;
  score: number;
  reason: string;
  isClientRejected?: boolean;
}

export interface Signer {
  id: string;
  name: string;
  department?: string;
  active: boolean;
  createdAt: string;
}

export interface AppSettings {
  warningDaysThreshold: number;   // Limiar de dias para aviso (omissão: 7)
  criticalDaysThreshold: number;  // Limiar de dias para alerta crítico (omissão: 14)
  companyName: string;
  departmentName: string;
}

export interface StoredFile {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  blob: Blob;
  createdAt: string;
}

export type ExtractionSituation =
  | 'SITUACAO_A_FALHA_LEITURA'      // Texto não foi extraído do PDF
  | 'SITUACAO_B_FALHA_INTERPRETACAO'// Texto extraído, mas campo não identificado
  | 'SITUACAO_C_LEITURA_PARCIAL'    // Alguns campos identificados, outros necessitam confirmação
  | 'SUCESSO_TOTAL';                // Todos os 4 campos identificados com elevada certeza

export interface FieldExtractionDetail {
  value?: string | number;
  confidence: boolean;
  reason: string;
  candidatesCount: number;
  candidates?: string[];
}

export interface ExtractionDiagnostic {
  documentType: 'PDF Digital (com texto selecionável)' | 'PDF Digitalizado (sem texto digital)' | 'Imagem (JPG / PNG)';
  method: 'Extração Direta Estruturada (PDF.js)' | 'OCR Local Offline (Tesseract.js)' | 'Heurística Local de Fallback';
  pagesAnalyzed: number;
  hasDigitalText: boolean;
  charactersExtracted: number;
  ocrStatus: 'Não necessário (PDF Digital)' | 'Concluído Localmente' | 'Falhou';
  situation: ExtractionSituation;
  situationMessage: string;
  fields: {
    supplier: FieldExtractionDetail;
    date: FieldExtractionDetail;
    number: FieldExtractionDetail;
    amount: FieldExtractionDetail;
  };
  warnings: string[];
  // Novos campos de auditoria e intervenientes (Requisitos Prioritários)
  qrFiscalData?: PortugueseQrFiscalData;
  issuerNif?: string;
  buyerNif?: string;
  supplierIdentificationSource?: 'QR Fiscal AT' | 'Catálogo Local' | 'Análise Textual Contextual' | 'Manual';
  supplierCandidates?: SupplierCandidateInfo[];
  isSupplierAmbiguous?: boolean;
}

export interface ExtractedInvoiceData {
  documentDate?: string;
  documentNumber?: string;
  supplier?: string;
  supplierNif?: string;
  amount?: number;
  confidence: {
    date: boolean;
    number: boolean;
    supplier: boolean;
    amount: boolean;
  };
  rawText: string;
  method: 'direct_pdf_text' | 'tesseract_ocr' | 'fallback_heuristic';
  diagnostic?: ExtractionDiagnostic;
  tradeName?: string;
}

export interface DuplicateCheckResult {
  isDuplicate: boolean;
  matchedInvoices: InvoiceRecord[];
  exactMatch: boolean;
}
