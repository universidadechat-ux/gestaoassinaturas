import React, { useState, useEffect, useRef } from 'react';
import { AppSettings, ConfirmedSupplier } from '../types';
import { storage, StorageEstimateResult } from '../services/storage';
import { isValidPortugueseNif } from '../services/qrScanner';
import { isDisqualifiedAsSupplierName } from '../services/extractor';
import {
  Settings,
  HardDrive,
  Save,
  Download,
  Upload,
  Trash2,
  ShieldCheck,
  AlertTriangle,
  Wifi,
  WifiOff,
  CheckCircle2,
  RefreshCw,
  Info,
  Building2,
  Plus,
  Search,
  Edit2,
  X,
  Monitor,
  FolderOpen,
  Terminal,
  ExternalLink,
} from 'lucide-react';

interface SettingsViewProps {
  settings: AppSettings;
  demoCount: number;
  onSaveSettings: (settings: AppSettings) => Promise<void>;
  onDeleteDemoData: () => Promise<void>;
  onBackupRestored: () => Promise<void>;
  onInstallClick?: () => void;
  isAppInstalled?: boolean;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  demoCount,
  onSaveSettings,
  onDeleteDemoData,
  onBackupRestored,
  onInstallClick,
  isAppInstalled,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Estados das definições
  const [warningDays, setWarningDays] = useState(settings.warningDaysThreshold);
  const [criticalDays, setCriticalDays] = useState(settings.criticalDaysThreshold);
  const [companyName, setCompanyName] = useState(settings.companyName);
  const [departmentName, setDepartmentName] = useState(settings.departmentName);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Diagnóstico de armazenamento
  const [storageEstimate, setStorageEstimate] = useState<StorageEstimateResult>({
    usedBytes: 0,
    quotaBytes: 0,
    percent: 0,
    supported: false,
  });

  // Estado de rede offline
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Estados de backup e restauro
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Confirmação para eliminação de demo
  const [showConfirmDeleteDemo, setShowConfirmDeleteDemo] = useState(false);
  const [isDeletingDemo, setIsDeletingDemo] = useState(false);

  // Catálogo Local de Fornecedores
  const [suppliers, setSuppliers] = useState<ConfirmedSupplier[]>([]);
  const [supplierSearch, setSupplierSearch] = useState('');
  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [supplierFormNif, setSupplierFormNif] = useState('');
  const [supplierFormName, setSupplierFormName] = useState('');
  const [supplierFormTradeName, setSupplierFormTradeName] = useState('');
  const [supplierFormError, setSupplierFormError] = useState<string | null>(null);
  const [editingNif, setEditingNif] = useState<string | null>(null);

  useEffect(() => {
    async function loadStorageInfo() {
      const est = await storage.getStorageEstimate();
      setStorageEstimate(est);
    }
    loadStorageInfo();
    loadSuppliers();

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadSuppliers = async () => {
    const list = await storage.getConfirmedSuppliers();
    setSuppliers(list);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const updated: AppSettings = {
      warningDaysThreshold: Math.max(1, parseInt(String(warningDays)) || 7),
      criticalDaysThreshold: Math.max(warningDays + 1, parseInt(String(criticalDays)) || 14),
      companyName: companyName.trim() || 'Empresa',
      departmentName: departmentName.trim() || 'Departamento de Contabilidade',
    };

    await onSaveSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleExportBackup = async () => {
    setIsExporting(true);
    try {
      const jsonBackup = await storage.exportFullBackup();
      const blob = new Blob([jsonBackup], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Backup_Gestao_Faturas_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert('Erro ao gerar cópia de segurança: ' + err.message);
    } finally {
      setIsExporting(false);
    }
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsRestoring(true);
    setRestoreMessage(null);

    try {
      const text = await file.text();
      const result = await storage.importFullBackup(text);

      if (result.success) {
        setRestoreMessage({ type: 'success', text: result.message });
        await loadSuppliers();
        await onBackupRestored();
      } else {
        setRestoreMessage({ type: 'error', text: result.message });
      }
    } catch (err: any) {
      setRestoreMessage({
        type: 'error',
        text: 'Erro ao processar ficheiro de restauro: ' + (err.message || 'Ficheiro corrompido'),
      });
    } finally {
      setIsRestoring(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDeleteDemo = async () => {
    setIsDeletingDemo(true);
    try {
      await onDeleteDemoData();
      setShowConfirmDeleteDemo(false);
    } catch (err: any) {
      alert('Erro ao eliminar dados de teste: ' + err.message);
    } finally {
      setIsDeletingDemo(false);
    }
  };

  const formatMb = (bytes: number) => {
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  // Funções do Catálogo de Fornecedores
  const handleOpenAddSupplier = () => {
    setEditingNif(null);
    setSupplierFormNif('');
    setSupplierFormName('');
    setSupplierFormTradeName('');
    setSupplierFormError(null);
    setIsSupplierModalOpen(true);
  };

  const handleOpenEditSupplier = (s: ConfirmedSupplier) => {
    setEditingNif(s.nif);
    setSupplierFormNif(s.nif);
    setSupplierFormName(s.name);
    setSupplierFormTradeName(s.tradeName || '');
    setSupplierFormError(null);
    setIsSupplierModalOpen(true);
  };

  const handleSaveSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNif = supplierFormNif.trim().replace(/\D/g, '');
    const cleanName = supplierFormName.trim();
    const cleanTrade = supplierFormTradeName.trim();

    if (!cleanNif || cleanNif.length !== 9) {
      setSupplierFormError('O NIF deve conter exatamente 9 dígitos.');
      return;
    }
    if (!isValidPortugueseNif(cleanNif)) {
      setSupplierFormError('O NIF introduzido não cumpre a fórmula de validação fiscal portuguesa (Módulo 11).');
      return;
    }
    if (!cleanName) {
      setSupplierFormError('Indique a denominação social oficial da empresa.');
      return;
    }
    if (isDisqualifiedAsSupplierName(cleanName)) {
      setSupplierFormError('O nome introduzido parece ser um código fiscal, ATCUD ou identificador de sistema. Indique a denominação social oficial da empresa.');
      return;
    }

    const existing = suppliers.find((s) => s.nif === cleanNif);
    const supplierToSave: ConfirmedSupplier = {
      nif: cleanNif,
      name: cleanName,
      tradeName: cleanTrade || undefined,
      verifiedCount: existing ? existing.verifiedCount : 1,
      lastUsedAt: new Date().toISOString(),
      source: 'manual',
    };

    await storage.saveConfirmedSupplier(supplierToSave);
    await loadSuppliers();
    setIsSupplierModalOpen(false);
  };

  const handleDeleteSupplier = async (nif: string, name: string) => {
    if (window.confirm(`Tem a certeza de que pretende remover "${name}" (NIF ${nif}) do catálogo local?`)) {
      await storage.deleteConfirmedSupplier(nif);
      await loadSuppliers();
    }
  };

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.nif.includes(supplierSearch) ||
      s.name.toLowerCase().includes(supplierSearch.toLowerCase()) ||
      (s.tradeName && s.tradeName.toLowerCase().includes(supplierSearch.toLowerCase()))
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Cabeçalho */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#253B53] tracking-tight flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#287DBB]" />
            <span>Definições do Sistema e Segurança</span>
          </h1>
          <p className="text-xs text-[#64788B] mt-0.5">
            Parametrização de atrasos, catálogo de fornecedores, cópias de segurança e diagnóstico
          </p>
        </div>

        {/* Indicador de Operação Offline */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs bg-[#F3F9FF] border-[#B8DBFA]">
          {isOnline ? (
            <div className="flex items-center gap-1.5 text-[#253B53]">
              <Wifi className="w-4 h-4 text-emerald-600" />
              <span className="font-medium">Ligado à rede</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-amber-800 font-bold">
              <WifiOff className="w-4 h-4 text-amber-600" />
              <span>Modo 100% Offline Ativo</span>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Lado Esquerdo: Formulário de Configuração de Atrasos & Catálogo (7 colunas) */}
        <div className="lg:col-span-7 space-y-6">
          
          <form onSubmit={handleSave} className="bg-white rounded-xl border border-[#B8DBFA] p-6 shadow-xs space-y-5">
            <h2 className="text-sm font-bold text-[#253B53] uppercase tracking-wider pb-2 border-b border-[#DCEEFF] flex items-center justify-between">
              <span>Limiares de Alerta de Devolução</span>
              {savedSuccess && (
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 normal-case">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Definições guardadas com sucesso!</span>
                </span>
              )}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  Aviso de Atraso Inicial (dias)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={warningDays}
                    onChange={(e) => setWarningDays(parseInt(e.target.value) || 1)}
                    className="w-full text-sm px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white font-mono text-[#253B53]"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs text-[#64788B]">dias</span>
                </div>
                <p className="text-[11px] text-amber-800 mt-1 font-medium">
                  Destaca a amarelo/laranja na tabela a partir de {warningDays} dias decorridos.
                </p>
              </div>

              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  Alerta de Atraso Crítico (dias)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="2"
                    max="90"
                    value={criticalDays}
                    onChange={(e) => setCriticalDays(parseInt(e.target.value) || 2)}
                    className="w-full text-sm px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white font-mono text-[#253B53]"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs text-[#64788B]">dias</span>
                </div>
                <p className="text-[11px] text-rose-700 mt-1 font-medium">
                  Destaca a vermelho suave na tabela a partir de {criticalDays} dias decorridos.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  Nome da Empresa
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  Departamento
                </label>
                <input
                  type="text"
                  value={departmentName}
                  onChange={(e) => setDepartmentName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Guardar Parâmetros</span>
              </button>
            </div>
          </form>

          {/* Secção do Catálogo Local de Fornecedores */}
          <div className="bg-white rounded-xl border border-[#B8DBFA] p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-[#DCEEFF] gap-2">
              <div>
                <h2 className="text-sm font-bold text-[#253B53] uppercase tracking-wider flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#287DBB]" />
                  <span>Catálogo Local de Fornecedores Conhecidos</span>
                </h2>
                <p className="text-[11px] text-[#64788B] mt-0.5">
                  Memória local no dispositivo com NIF e denominação oficial. Alimenta a identificação de novos documentos.
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddSupplier}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold shadow-xs transition-colors self-start sm:self-auto"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Adicionar Fornecedor</span>
              </button>
            </div>

            {/* Caixa de pesquisa */}
            <div className="relative">
              <Search className="w-4 h-4 text-[#64788B] absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Pesquisar por NIF, denominação social ou marca habitual..."
                value={supplierSearch}
                onChange={(e) => setSupplierSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-[#F3F9FF]/50 text-[#253B53]"
              />
            </div>

            {/* Tabela de Fornecedores */}
            <div className="border border-[#DCEEFF] rounded-lg overflow-hidden max-h-72 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F3F9FF] text-[#253B53] font-bold border-b border-[#DCEEFF] sticky top-0">
                  <tr>
                    <th className="py-2 px-3">NIF</th>
                    <th className="py-2 px-3">Denominação Social / Marca</th>
                    <th className="py-2 px-3 text-center">Faturas</th>
                    <th className="py-2 px-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DCEEFF]">
                  {filteredSuppliers.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-4 text-center text-[#64788B]">
                        Nenhum fornecedor encontrado no catálogo local.
                      </td>
                    </tr>
                  ) : (
                    filteredSuppliers.map((s) => (
                      <tr key={s.nif} className="hover:bg-[#F3F9FF]/70 transition-colors">
                        <td className="py-2 px-3 font-mono font-bold text-[#287DBB]">
                          {s.nif}
                        </td>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-[#253B53] line-clamp-1">{s.name}</div>
                          {s.tradeName && (
                            <div className="text-[11px] text-[#64788B] italic">Marca: {s.tradeName}</div>
                          )}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#DCEEFF] text-[#253B53]">
                            {s.verifiedCount || 1}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right space-x-1 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleOpenEditSupplier(s)}
                            className="p-1 hover:bg-[#DCEEFF] text-[#287DBB] rounded transition-colors"
                            title="Editar fornecedor"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteSupplier(s.nif, s.name)}
                            className="p-1 hover:bg-rose-100 text-rose-600 rounded transition-colors"
                            title="Remover do catálogo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            <p className="text-[11px] text-[#64788B]">
              Total de fornecedores memorizados: <strong>{suppliers.length}</strong>. Novos fornecedores validados na criação de faturas são associados automaticamente ao catálogo.
            </p>
          </div>

          {/* Salvaguarda administrativa e restauro */}
          <div className="bg-white rounded-xl border border-[#B8DBFA] p-6 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-[#253B53] uppercase tracking-wider pb-2 border-b border-[#DCEEFF] flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-[#287DBB]" />
              <span>Cópias de Segurança e Restauro de Dados (JSON)</span>
            </h2>

            <p className="text-xs text-[#64788B] leading-relaxed">
              A cópia de segurança inclui <strong>dados das faturas, catálogo de fornecedores, responsáveis, observações e histórico</strong>. Não inclui PDFs, imagens nem texto bruto OCR. As cópias antigas podem conter anexos; nesta versão, não são importados.
            </p>

            {restoreMessage && (
              <div
                className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
                  restoreMessage.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                {restoreMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                ) : (
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                )}
                <span className="font-medium">{restoreMessage.text}</span>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={handleExportBackup}
                disabled={isExporting}
                className="px-4 py-2.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold flex items-center gap-2 transition-colors shadow-xs"
              >
                {isExporting ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <Download className="w-4 h-4 text-white" />
                )}
                <span>Exportar Dados de Controlo</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isRestoring}
                className="px-4 py-2.5 bg-white hover:bg-[#DCEEFF] text-[#253B53] border border-[#B8DBFA] rounded-lg text-xs font-bold flex items-center gap-2 transition-colors"
              >
                {isRestoring ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-[#287DBB]" />
                ) : (
                  <Upload className="w-4 h-4 text-[#287DBB]" />
                )}
                <span>Restaurar de Ficheiro JSON</span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={handleImportBackup}
              />
            </div>
          </div>

          {/* Gestão de Dados de Demonstração */}
          {demoCount > 0 && (
            <div className="bg-[#FEF3C7]/40 rounded-xl border border-amber-200 p-5 shadow-xs space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                    <Trash2 className="w-4 h-4 text-amber-700" />
                    <span>Dados de Demonstração ({demoCount} faturas de teste ativas)</span>
                  </h3>
                  <p className="text-xs text-amber-800 mt-1">
                    Existem faturas de exemplo na base de dados para testes de circuito e atraso. Quando pretender iniciar a utilização em produção real com os dados da empresa, pode eliminá-las com total segurança.
                  </p>
                </div>
              </div>

              {showConfirmDeleteDemo ? (
                <div className="p-3 bg-white rounded-lg border border-rose-300 space-y-2">
                  <p className="text-xs font-semibold text-rose-800">
                    Confirma que pretende eliminar as {demoCount} faturas de demonstração e os respetivos ficheiros de teste? As faturas reais inseridas por si não serão afetadas.
                  </p>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowConfirmDeleteDemo(false)}
                      className="px-3 py-1 text-xs text-[#64788B] hover:text-[#253B53]"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleDeleteDemo}
                      disabled={isDeletingDemo}
                      className="px-3 py-1 bg-rose-700 hover:bg-rose-800 text-white rounded text-xs font-bold transition-colors"
                    >
                      {isDeletingDemo ? 'A eliminar...' : 'Sim, Eliminar Dados de Teste'}
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowConfirmDeleteDemo(true)}
                  className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Eliminar todos os dados de demonstração</span>
                </button>
              )}
            </div>
          )}

        </div>

        {/* Lado Direito: Instalar no Windows & Diagnóstico de Espaço em Disco (5 colunas) */}
        <div className="lg:col-span-5 space-y-6">

          {/* Secção: Instalar no PC (PWA) */}
          <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#DCEEFF]">
              <h2 className="text-sm font-bold text-[#253B53] uppercase tracking-wider flex items-center gap-2">
                <Monitor className="w-4 h-4 text-[#287DBB]" />
                <span>Instalar no PC</span>
              </h2>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isAppInstalled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA]'
                }`}
              >
                {isAppInstalled ? 'Aplicação Instalada' : 'Disponível no Navegador'}
              </span>
            </div>

            <p className="text-xs text-[#64788B] leading-relaxed">
              {isAppInstalled
                ? 'A Gestão de Faturas está instalada neste computador e a funcionar numa janela independente.'
                : 'Instale a aplicação no seu computador através do Chrome ou Edge (PWA). Abre numa janela própria sem barras do navegador e funciona 100% offline.'}
            </p>

            {isAppInstalled ? (
              <div className="p-3.5 bg-emerald-50/70 rounded-lg border border-emerald-200 space-y-2 text-xs text-emerald-950">
                <div className="font-bold flex items-center gap-1.5 text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Aplicação Instalada no PC</span>
                </div>
                <ul className="text-[11px] text-emerald-900 space-y-1 list-disc pl-4">
                  <li>Janela independente sem controlos de navegação.</li>
                  <li>Funcionamento offline garantido com cache local.</li>
                  <li>Armazenamento persistente no dispositivo.</li>
                  <li>Acesso direto pelo atalho no computador.</li>
                </ul>
              </div>
            ) : (
              <div className="space-y-3">
                {onInstallClick && (
                  <button
                    type="button"
                    onClick={onInstallClick}
                    className="w-full py-2.5 px-4 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-white" />
                    <span>Instalar no PC</span>
                  </button>
                )}

                <div className="p-3.5 bg-[#F3F9FF] rounded-lg border border-[#B8DBFA] space-y-2 text-xs">
                  <div className="font-bold text-[#253B53] flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#287DBB]" />
                    <span>Vantagens da Instalação no PC:</span>
                  </div>
                  <ul className="text-[11px] text-[#64788B] space-y-1 list-disc pl-4">
                    <li>
                      <strong>Sem programas adicionais</strong>: Não necessita de Node.js, comandos de terminal ou ficheiros de instalação.
                    </li>
                    <li>
                      <strong>Janela autónoma</strong>: Funciona como uma aplicação nativa no seu computador.
                    </li>
                    <li>
                      <strong>100% Offline</strong>: OCR local, leitura de PDF e leitor de QR Code fiscal funcionam sem Internet.
                    </li>
                    <li>
                      <strong>Dados protegidos</strong>: Persistência permanente no dispositivo através de IndexedDB.
                    </li>
                  </ul>
                </div>
              </div>
            )}
          </div>

          
          {/* Monitor de Quota de Armazenamento */}
          <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-[#253B53] uppercase tracking-wider pb-2 border-b border-[#DCEEFF] flex items-center gap-1.5">
              <HardDrive className="w-4 h-4 text-[#287DBB]" />
              <span>Espaço de Armazenamento Local</span>
            </h2>

            {storageEstimate.supported ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#64788B]">Espaço utilizado:</span>
                  <span className="font-mono font-bold text-[#253B53]">
                    {formatMb(storageEstimate.usedBytes)} / {formatMb(storageEstimate.quotaBytes)}
                  </span>
                </div>

                <div className="w-full bg-[#DCEEFF] h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      storageEstimate.percent > 80
                        ? 'bg-rose-600'
                        : storageEstimate.percent > 50
                        ? 'bg-amber-500'
                        : 'bg-[#287DBB]'
                    }`}
                    style={{ width: `${Math.max(2, storageEstimate.percent)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#64788B]">
                  <span>{storageEstimate.percent}% da capacidade do navegador</span>
                  {storageEstimate.percent > 80 && (
                    <span className="text-rose-600 font-bold">Aviso: quota elevada</span>
                  )}
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#64788B]">
                A persistência no IndexedDB permanece ativa e funcional no seu dispositivo.
              </p>
            )}
          </div>

          {/* Aviso Legal e Limitações de Segurança do Armazenamento no Navegador */}
          <div className="bg-[#F3F9FF] rounded-xl border border-[#B8DBFA] p-5 space-y-3 text-xs text-[#253B53]">
            <h3 className="font-bold text-[#253B53] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#287DBB]" />
              <span>Política de Segurança e Limitações Locais</span>
            </h3>

            <p className="leading-relaxed text-[#64788B]">
              <strong>Privacidade Documental:</strong> Os novos PDFs e imagens são processados localmente e descartados quando terminar a validação. Só os dados administrativos são guardados no dispositivo. Anexos de versões antigas, caso existam, são preservados até decisão expressa do utilizador.
            </p>

            <div className="p-3 bg-white rounded-lg border border-[#B8DBFA] space-y-1.5">
              <span className="font-bold text-[#253B53] flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-[#287DBB]" />
                <span>Limitações do Armazenamento Local:</span>
              </span>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-[#64788B]">
                <li>Os dados pertencem exclusivamente a este dispositivo e navegador.</li>
                <li>A limpeza de dados do navegador pode apagar o arquivo local.</li>
                <li>Utilize a funcionalidade de <strong>Exportar Cópia de Segurança</strong> com regularidade para salvaguarda em local seguro na rede da empresa.</li>
              </ul>
            </div>

            <p className="text-[11px] text-[#64788B]">
              Arquitetura preparada com repositório isolado e interface padrão pronta para conversão futura em aplicação portátil desktop (SQLite / Windows).
            </p>
          </div>

        </div>

      </div>

      {/* Modal de Criação / Edição de Fornecedor */}
      {isSupplierModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#253B53]/40 backdrop-blur-xs">
          <div className="bg-white rounded-xl border border-[#B8DBFA] shadow-xl max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-[#DCEEFF]">
              <h3 className="text-sm font-bold text-[#253B53] flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#287DBB]" />
                <span>{editingNif ? 'Editar Fornecedor' : 'Adicionar Fornecedor ao Catálogo'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsSupplierModalOpen(false)}
                className="text-[#64788B] hover:text-[#253B53] p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSupplier} className="space-y-4">
              {supplierFormError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{supplierFormError}</span>
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  NIF da Empresa (9 dígitos) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  maxLength={9}
                  placeholder="Ex: 503254174"
                  value={supplierFormNif}
                  onChange={(e) => setSupplierFormNif(e.target.value)}
                  disabled={!!editingNif}
                  className="w-full text-xs font-mono px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53] disabled:bg-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  Denominação Social Oficial <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Ex: Mundo Aquático – Parques Oceanográficos, S.A."
                  value={supplierFormName}
                  onChange={(e) => setSupplierFormName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#253B53] block mb-1">
                  Nome Comercial / Marca Habitual (opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ex: Zoomarine"
                  value={supplierFormTradeName}
                  onChange={(e) => setSupplierFormTradeName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[#DCEEFF]">
                <button
                  type="button"
                  onClick={() => setIsSupplierModalOpen(false)}
                  className="px-4 py-2 border border-[#B8DBFA] text-[#64788B] hover:text-[#253B53] text-xs font-semibold rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Guardar Fornecedor</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};


