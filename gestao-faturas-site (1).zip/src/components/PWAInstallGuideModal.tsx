import React from 'react';
import { Monitor, X, Chrome, Compass, ExternalLink, Check } from 'lucide-react';

interface PWAInstallGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallGuideModal: React.FC<PWAInstallGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#253B53]/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-[#B8DBFA] shadow-2xl max-w-lg w-full p-6 space-y-4 animate-in zoom-in-95 duration-200">
        
        {/* Cabeçalho */}
        <div className="flex items-start justify-between pb-3 border-b border-[#DCEEFF]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#DCEEFF] border border-[#B8DBFA] flex items-center justify-center text-[#287DBB]">
              <Monitor className="w-5 h-5 text-[#287DBB]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#253B53]">
                Instalar Aplicação no Computador (PC)
              </h3>
              <p className="text-[11px] text-[#64788B]">
                Google Chrome e Microsoft Edge (Tecnologia PWA)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#64788B] hover:text-[#253B53] p-1.5 rounded-lg hover:bg-[#F3F9FF] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-[#253B53] leading-relaxed">
          Pode instalar a <strong>Gestão de Faturas</strong> diretamente no seu computador através do navegador, criando uma aplicação independente com atalho no ambiente de trabalho e sem barras do browser:
        </p>

        {/* Instruções Passo a Passo */}
        <div className="space-y-2.5 text-xs">
          
          {/* Opção 1: Barra de Endereço */}
          <div className="p-3 bg-[#F3F9FF] rounded-xl border border-[#B8DBFA] space-y-1">
            <div className="flex items-center gap-2 font-bold text-[#253B53]">
              <span className="w-5 h-5 rounded-full bg-[#287DBB] text-white flex items-center justify-center text-[11px] font-bold shrink-0">
                1
              </span>
              <span>Através do ícone na barra de endereço (Método Direto)</span>
            </div>
            <p className="text-[11px] text-[#64788B] pl-7 leading-relaxed">
              No canto direito da barra de endereço do Chrome ou Edge, clique no pequeno ícone de ecrã/computador com uma seta de instalação (<strong>«Instalar aplicação»</strong>) e confirme.
            </p>
          </div>

          {/* Opção 2: Menu do Navegador */}
          <div className="p-3 bg-white rounded-xl border border-[#DCEEFF] space-y-1">
            <div className="flex items-center gap-2 font-bold text-[#253B53]">
              <span className="w-5 h-5 rounded-full bg-[#287DBB] text-white flex items-center justify-center text-[11px] font-bold shrink-0">
                2
              </span>
              <span>Através do menu do navegador</span>
            </div>
            <ul className="text-[11px] text-[#64788B] pl-7 space-y-1 list-disc">
              <li>
                <strong>No Google Chrome:</strong> Clique nos três pontos verticais (<span className="font-mono font-bold">⋮</span>) no canto superior direito $\rightarrow$ selecione <strong>«Guardar e partilhar»</strong> ou <strong>«Instalar Gestão de Faturas...»</strong>.
              </li>
              <li>
                <strong>No Microsoft Edge:</strong> Clique nos três pontos (<span className="font-mono font-bold">...</span>) $\rightarrow$ selecione <strong>«Aplicações»</strong> $\rightarrow$ <strong>«Instalar este site como uma aplicação»</strong>.
              </li>
            </ul>
          </div>

        </div>

        {/* Vantagens */}
        <div className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-200 text-emerald-900 text-[11px] flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Após a instalação, a aplicação abre numa janela própria sem barras do browser e funciona offline.</span>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white text-xs font-bold rounded-lg transition-colors shadow-xs"
          >
            Entendido
          </button>
        </div>

      </div>
    </div>
  );
};
