import React, { useEffect, useState } from 'react';
import { storage } from '../services/storage';
import { ZoomIn, ZoomOut, RotateCw, Download, FileText, RefreshCw } from 'lucide-react';

interface DocumentViewerProps {
  fileId?: string;
  fileName?: string;
  fileType?: string;
  fallbackBlob?: Blob;
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  fileId,
  fileName,
  fileType,
  fallbackBlob,
}) => {
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);

  useEffect(() => {
    let active = true;
    let createdUrl: string | null = null;

    async function loadDocument() {
      setLoading(true);
      setError(null);

      try {
        let blobToDisplay: Blob | null = fallbackBlob || null;

        if (!blobToDisplay && fileId) {
          const stored = await storage.getFile(fileId);
          if (stored) {
            blobToDisplay = stored.blob;
          }
        }

        if (active) {
          if (blobToDisplay) {
            createdUrl = URL.createObjectURL(blobToDisplay);
            setObjectUrl(createdUrl);
          } else {
            setError('Ficheiro não encontrado no armazenamento local.');
          }
          setLoading(false);
        }
      } catch {
        if (active) {
          setError('Erro ao carregar o documento do armazenamento local.');
          setLoading(false);
        }
      }
    }

    loadDocument();

    return () => {
      active = false;
      if (createdUrl) {
        URL.revokeObjectURL(createdUrl);
      }
    };
  }, [fileId, fallbackBlob]);

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.5));
  const handleResetZoom = () => {
    setZoom(1);
    setRotation(0);
  };
  const handleRotate = () => setRotation((r) => (r + 90) % 360);

  const isPdf =
    fileType === 'application/pdf' ||
    (fileName && fileName.toLowerCase().endsWith('.pdf'));

  if (loading) {
    return (
      <div className="h-72 flex flex-col items-center justify-center bg-[#F3F9FF] rounded-lg border border-[#B8DBFA] text-[#64788B]">
        <RefreshCw className="w-6 h-6 animate-spin text-[#287DBB] mb-2" />
        <span className="text-xs font-semibold">A carregar documento do repositório...</span>
      </div>
    );
  }

  if (error || !objectUrl) {
    return (
      <div className="h-64 flex flex-col items-center justify-center bg-[#F3F9FF] rounded-lg border border-[#B8DBFA] text-[#64788B] p-4 text-center">
        <FileText className="w-10 h-10 text-[#69B5ED] mb-2" />
        <span className="text-xs font-bold text-[#253B53]">{fileName || 'Documento sem anexo'}</span>
        <span className="text-[11px] text-[#64788B] mt-1">
          {error || 'Não existe ficheiro digital guardado para esta fatura.'}
        </span>
      </div>
    );
  }

  return (
    <div className="flex flex-col bg-white rounded-xl overflow-hidden border border-[#B8DBFA] shadow-xs">
      {/* Barra de Ferramentas de Visualização Clara */}
      <div className="bg-[#DCEEFF] px-3 py-2 border-b border-[#B8DBFA] flex items-center justify-between text-xs text-[#253B53]">
        <div className="flex items-center gap-2 truncate max-w-xs">
          <FileText className="w-4 h-4 text-[#287DBB] shrink-0" />
          <span className="truncate font-semibold">{fileName || 'Documento'}</span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={handleZoomOut}
            title="Diminuir Zoom"
            className="p-1.5 hover:bg-[#B8DBFA] rounded-md text-[#253B53] transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-[11px] font-mono font-bold px-1 text-[#287DBB]">{Math.round(zoom * 100)}%</span>
          <button
            type="button"
            onClick={handleZoomIn}
            title="Aumentar Zoom"
            className="p-1.5 hover:bg-[#B8DBFA] rounded-md text-[#253B53] transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleRotate}
            title="Rodar 90º"
            className="p-1.5 hover:bg-[#B8DBFA] rounded-md text-[#253B53] ml-1 transition-colors"
          >
            <RotateCw className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleResetZoom}
            title="Repor Visualização"
            className="px-2 py-1 hover:bg-[#B8DBFA] rounded-md text-[11px] text-[#287DBB] font-semibold transition-colors"
          >
            Repor
          </button>
          <a
            href={objectUrl}
            download={fileName || 'fatura_documento'}
            title="Descarregar Ficheiro Original"
            className="p-1.5 bg-[#287DBB] hover:bg-[#1E679B] rounded-md text-white ml-2 flex items-center gap-1 shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Área de Visualização Clara */}
      <div className="relative min-h-[360px] max-h-[520px] overflow-auto bg-[#F3F9FF] flex items-center justify-center p-4">
        {isPdf ? (
          <iframe
            src={objectUrl}
            title="Visualizador de PDF"
            className="w-full h-[480px] rounded-lg border border-[#B8DBFA] bg-white shadow-xs"
          />
        ) : (
          <div
            className="transition-transform duration-150 origin-center"
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
            }}
          >
            <img
              src={objectUrl}
              alt={fileName || 'Fatura digital'}
              className="max-h-[480px] w-auto object-contain rounded-lg shadow-sm bg-white"
            />
          </div>
        )}
      </div>
    </div>
  );
};
