import React from 'react';
import { CheckCircle2, Monitor, WifiOff, HardDrive, Laptop, X } from 'lucide-react';

interface PWAInstallSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallSuccessModal: React.FC<PWAInstallSuccessModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#253B53]/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-[#B8DBFA] shadow-2xl max-w-md w-full p-6 space-y-5 animate-in zoom-in-95 duration-200">
        
        {/* Cabeçalho com Ícone de Sucesso */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-xs">
              <CheckCircle2 className="w-7 h-7 text-emerald-600" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#253B53]">
                Aplicação Instalada no PC
              </h3>
              <p className="text-xs text-emerald-700 font-medium">
                Instalação concluída com sucesso
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#64788B] hover:text-[#253B53] p-1.5 rounded-lg hover:bg-[#F3F9FF] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mensagem Principal */}
        <p className="text-xs text-[#253B53] leading-relaxed">
          A <strong>Gestão de Faturas</strong> está instalada neste computador e disponível para utilização independente.
        </p>

        {/* Lista de Características Oficiais */}
        <div className="p-4 bg-[#F3F9FF] rounded-xl border border-[#B8DBFA] space-y-2.5 text-xs text-[#253B53]">
          <div className="flex items-center gap-2.5">
            <Monitor className="w-4 h-4 text-[#287DBB] shrink-0" />
            <span className="font-medium">Janela independente.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <WifiOff className="w-4 h-4 text-[#287DBB] shrink-0" />
            <span className="font-medium">Funcionamento offline.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <HardDrive className="w-4 h-4 text-[#287DBB] shrink-0" />
            <span className="font-medium">Armazenamento local dos dados.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <Laptop className="w-4 h-4 text-[#287DBB] shrink-0" />
            <span className="font-medium">Acesso através do computador.</span>
          </div>
        </div>

        {/* Botão de Fecho */}
        <div className="pt-1 flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-[#287DBB] hover:bg-[#1E679B] text-white text-xs font-bold rounded-lg transition-colors shadow-xs"
          >
            Concluir
          </button>
        </div>

      </div>
    </div>
  );
};
