import React, { useState } from 'react';
import { InvoiceRecord } from '../types';
import { formatEuro, formatPtDate } from '../services/extractor';
import { AlertTriangle, ExternalLink, X } from 'lucide-react';

interface DuplicateWarningModalProps {
  isOpen: boolean;
  newInvoiceData: {
    supplier: string;
    documentNumber: string;
    amount: number;
    documentDate: string;
  };
  matchedInvoices: InvoiceRecord[];
  onCancel: () => void;
  onViewExisting: (invoice: InvoiceRecord) => void;
  onProceedAnyway: (justification: string) => void;
}

export const DuplicateWarningModal: React.FC<DuplicateWarningModalProps> = ({
  isOpen,
  newInvoiceData,
  matchedInvoices,
  onCancel,
  onViewExisting,
  onProceedAnyway,
}) => {
  const [justification, setJustification] = useState('');
  const [showJustificationInput, setShowJustificationInput] = useState(false);

  if (!isOpen) return null;

  const primaryMatch = matchedInvoices[0];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#253B53]/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full border border-amber-300 overflow-hidden animate-in fade-in duration-150">
        
        {/* Cabeçalho de Alerta */}
        <div className="bg-amber-600 px-6 py-4 text-white flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Aviso: Possível Fatura Duplicada
              </h3>
              <p className="text-xs text-amber-100 mt-0.5">
                Já existe uma fatura registada no sistema com o mesmo fornecedor e número.
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-white/80 hover:text-white transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabela de Comparação */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-[#64788B]">
            Para evitar duplicações acidentais no controlo de assinaturas, compare os dados do novo documento com o registo já existente na base de dados da contabilidade:
          </p>

          <div className="grid grid-cols-2 gap-3 text-xs">
            {/* Novo Documento */}
            <div className="p-3 bg-[#FEF3C7]/40 rounded-lg border border-amber-200 space-y-2">
              <div className="font-bold text-amber-900 pb-1 border-b border-amber-200 flex items-center justify-between">
                <span>NOVA FATURA</span>
                <span className="text-[10px] font-normal text-amber-700">A ser inserida</span>
              </div>
              <div>
                <span className="text-[#64788B] block text-[11px]">Fornecedor:</span>
                <span className="font-bold text-[#253B53]">{newInvoiceData.supplier}</span>
              </div>
              <div>
                <span className="text-[#64788B] block text-[11px]">Nº Documento:</span>
                <span className="font-mono font-bold text-[#287DBB]">{newInvoiceData.documentNumber}</span>
              </div>
              <div>
                <span className="text-[#64788B] block text-[11px]">Data de Emissão:</span>
                <span className="font-mono text-[#253B53]">{formatPtDate(newInvoiceData.documentDate)}</span>
              </div>
              <div>
                <span className="text-[#64788B] block text-[11px]">Valor Total:</span>
                <span className="font-mono font-bold text-[#253B53] text-sm">
                  {formatEuro(newInvoiceData.amount)}
                </span>
              </div>
            </div>

            {/* Documento Já Existente */}
            {primaryMatch && (
              <div className="p-3 bg-[#F3F9FF] rounded-lg border border-[#B8DBFA] space-y-2">
                <div className="font-bold text-[#253B53] pb-1 border-b border-[#B8DBFA] flex items-center justify-between">
                  <span>FATURA JÁ REGISTADA</span>
                  <button
                    type="button"
                    onClick={() => onViewExisting(primaryMatch)}
                    className="text-[10px] text-[#287DBB] hover:underline flex items-center gap-0.5 font-semibold"
                  >
                    <span>Ver ficha</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
                <div>
                  <span className="text-[#64788B] block text-[11px]">Fornecedor:</span>
                  <span className="font-bold text-[#253B53]">{primaryMatch.supplier}</span>
                </div>
                <div>
                  <span className="text-[#64788B] block text-[11px]">Nº Documento:</span>
                  <span className="font-mono font-bold text-[#287DBB]">{primaryMatch.documentNumber}</span>
                </div>
                <div>
                  <span className="text-[#64788B] block text-[11px]">Data de Emissão:</span>
                  <span className="font-mono text-[#253B53]">{formatPtDate(primaryMatch.documentDate)}</span>
                </div>
                <div>
                  <span className="text-[#64788B] block text-[11px]">Valor Total:</span>
                  <span className="font-mono font-bold text-[#253B53] text-sm">
                    {formatEuro(primaryMatch.amount)}
                  </span>
                </div>
                <div className="pt-1 border-t border-[#DCEEFF] text-[11px]">
                  <span className="text-[#64788B]">Estado atual: </span>
                  <strong className="text-[#253B53]">
                    {primaryMatch.status === 'EM_ASSINATURA'
                      ? `Em Assinatura (${primaryMatch.assignedTo || '—'})`
                      : primaryMatch.status === 'DEVOLVIDA'
                      ? 'Devolvida'
                      : 'Por Entregar'}
                  </strong>
                </div>
              </div>
            )}
          </div>

          {/* Justificação para gravação em exceção */}
          {showJustificationInput ? (
            <div className="p-3 bg-rose-50 rounded-lg border border-rose-200 space-y-2">
              <label className="text-xs font-bold text-rose-900 block">
                Justificação da exceção (obrigatória para avançar):
              </label>
              <input
                type="text"
                placeholder="Ex: Segunda via física solicitada pelo departamento, aditamento contratual, etc."
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-rose-300 rounded-md bg-white focus:ring-2 focus:ring-rose-500 text-[#253B53]"
                autoFocus
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowJustificationInput(false)}
                  className="px-2.5 py-1 text-xs text-[#64788B] hover:text-[#253B53]"
                >
                  Cancelar exceção
                </button>
                <button
                  type="button"
                  disabled={!justification.trim()}
                  onClick={() => onProceedAnyway(justification.trim())}
                  className="px-3 py-1 bg-rose-700 hover:bg-rose-800 disabled:opacity-50 text-white rounded text-xs font-bold"
                >
                  Confirmar Gravação de Exceção
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-[#64788B]">
                Se este for um documento legítimo distinto:
              </span>
              <button
                type="button"
                onClick={() => setShowJustificationInput(true)}
                className="text-xs font-bold text-rose-700 hover:text-rose-900 underline"
              >
                Permitir exceção justificada
              </button>
            </div>
          )}
        </div>

        {/* Rodapé de Decisão */}
        <div className="bg-[#F3F9FF] px-6 py-3.5 border-t border-[#B8DBFA] flex items-center justify-between">
          {primaryMatch && (
            <button
              type="button"
              onClick={() => onViewExisting(primaryMatch)}
              className="text-xs text-[#287DBB] hover:text-[#1E679B] font-semibold flex items-center gap-1"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Consultar fatura existente</span>
            </button>
          )}

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold transition-colors"
            >
              Corrigir dados da nova fatura
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
