import React, { useState, useMemo } from 'react';
import { InvoiceRecord } from '../types';
import { formatPtDate } from '../services/extractor';
import {
  History,
  Search,
  Calendar,
  Clock,
  ArrowDownLeft,
  Send,
  PlusCircle,
  Edit3,
} from 'lucide-react';

interface HistoryViewProps {
  invoices: InvoiceRecord[];
  onSelectInvoice: (invoice: InvoiceRecord) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ invoices, onSelectInvoice }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  const allEvents = useMemo(() => {
    return invoices
      .flatMap((inv) =>
        inv.history.map((evt) => ({
          ...evt,
          invoice: inv,
        }))
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [invoices]);

  const filteredEvents = useMemo(() => {
    return allEvents.filter((item) => {
      if (typeFilter !== 'ALL' && item.type !== typeFilter) return false;

      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const matchesDoc = item.invoice.documentNumber.toLowerCase().includes(term);
        const matchesSup = item.invoice.supplier.toLowerCase().includes(term);
        const matchesDesc = item.description.toLowerCase().includes(term);
        const matchesAuthor = item.author.toLowerCase().includes(term);
        if (!matchesDoc && !matchesSup && !matchesDesc && !matchesAuthor) return false;
      }

      return true;
    });
  }, [allEvents, typeFilter, searchTerm]);

  const getEventBadge = (type: string) => {
    switch (type) {
      case 'ENTREGA':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#FEF3C7] text-amber-900 border border-amber-300">
            <Send className="w-3 h-3 text-amber-700" />
            <span>Entrega Física</span>
          </span>
        );
      case 'DEVOLUCAO':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#ECFDF5] text-emerald-800 border border-emerald-300">
            <ArrowDownLeft className="w-3 h-3 text-emerald-600" />
            <span>Devolução à Contabilidade</span>
          </span>
        );
      case 'CRIACAO':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA]">
            <PlusCircle className="w-3 h-3 text-[#287DBB]" />
            <span>Registo Inicial</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#F3F9FF] text-[#253B53] border border-[#B8DBFA]">
            <Edit3 className="w-3 h-3 text-[#69B5ED]" />
            <span>Modificação</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Cabeçalho */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#253B53] tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-[#287DBB]" />
            <span>Histórico de Circulação e Auditoria</span>
          </h1>
          <p className="text-xs text-[#64788B] mt-0.5">
            Rastreio cronológico imutável de todas as entregas, receções e operações efetuadas
          </p>
        </div>

        <span className="text-xs px-3 py-1 bg-[#DCEEFF] rounded-lg text-[#287DBB] font-mono font-bold border border-[#B8DBFA]">
          {filteredEvents.length} movimentos registados
        </span>
      </div>

      {/* Filtros de Histórico */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-3.5 shadow-xs flex flex-col sm:flex-row gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#69B5ED] absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Filtrar histórico por fatura, fornecedor ou descrição..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] text-xs bg-[#F3F9FF] text-[#253B53]"
          />
        </div>

        <div className="sm:w-60">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full py-2 px-3 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] text-xs bg-white text-[#253B53]"
          >
            <option value="ALL">Todos os Movimentos</option>
            <option value="ENTREGA">Apenas Entregas</option>
            <option value="DEVOLUCAO">Apenas Devoluções</option>
            <option value="CRIACAO">Apenas Registos Iniciais</option>
            <option value="NOTA">Apenas Observações</option>
          </select>
        </div>
      </div>

      {/* Linha Temporal Geral */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] shadow-xs p-6">
        <div className="relative pl-6 space-y-6 border-l-2 border-[#B8DBFA] ml-2">
          {filteredEvents.length === 0 ? (
            <p className="text-xs text-[#64788B]">Nenhum registo de movimento corresponde aos critérios.</p>
          ) : (
            filteredEvents.map((item, idx) => (
              <div key={`${item.id}-${idx}`} className="relative group">
                <div className="absolute -left-[31px] top-1.5 w-3.5 h-3.5 rounded-full bg-white border-2 border-[#287DBB] group-hover:scale-110 transition-transform" />

                <div className="bg-[#F3F9FF] hover:bg-[#DCEEFF]/50 p-4 rounded-xl border border-[#B8DBFA] transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs mb-2">
                    <div className="flex items-center gap-2">
                      {getEventBadge(item.type)}
                      <button
                        type="button"
                        onClick={() => onSelectInvoice(item.invoice)}
                        className="font-mono font-bold text-[#287DBB] hover:text-[#1E679B] underline text-xs"
                      >
                        {item.invoice.documentNumber}
                      </button>
                      <span className="text-[#64788B]">·</span>
                      <span className="text-[#253B53] font-bold">{item.invoice.supplier}</span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-[#64788B] font-mono">
                      <Clock className="w-3 h-3 text-[#69B5ED]" />
                      <span>{new Date(item.timestamp).toLocaleString('pt-PT')}</span>
                    </div>
                  </div>

                  <p className="text-[#253B53] text-xs font-medium leading-relaxed">
                    {item.description}
                  </p>

                  <div className="mt-2.5 pt-2 border-t border-[#DCEEFF] flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#64788B]">
                    <div className="flex items-center gap-1 font-mono">
                      <Calendar className="w-3 h-3 text-[#69B5ED]" />
                      <span>Data efetiva do movimento: <strong className="text-[#253B53]">{formatPtDate(item.effectiveDate)}</strong></span>
                    </div>
                    <span>{item.author}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
