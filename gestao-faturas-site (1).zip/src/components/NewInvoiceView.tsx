import React, { useState, useRef, useEffect } from 'react';
import { InvoiceRecord, Signer, AppSettings, ExtractionDiagnostic } from '../types';
import {
  extractDocumentData,
  formatEuro,
  parsePtCurrency,
  formatPtDate,
  KNOWN_PT_SUPPLIERS,
  isDisqualifiedAsSupplierName,
} from '../services/extractor';
import { checkForDuplicates } from '../services/businessRules';
import { storage } from '../services/storage';
import { isValidPortugueseNif } from '../services/qrScanner';
import { DeliveryModal } from './DeliveryModal';
import { DuplicateWarningModal } from './DuplicateWarningModal';
import { PdfPagePreview } from './PdfPagePreview';
import {
  UploadCloud,
  FileText,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Copy,
  Check,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Trash2,
  Send,
  Eye,
  Info,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  HelpCircle,
  QrCode,
  Building2,
  UserX,
  BookOpen,
  Edit3,
  ArrowLeft,
  Calendar,
  Euro,
  UserCheck,
} from 'lucide-react';

interface NewInvoiceViewProps {
  existingInvoices: InvoiceRecord[];
  signers: Signer[];
  settings: AppSettings;
  onInvoiceCreated: (newInvoice: InvoiceRecord) => void;
  onAddNewSigner: (name: string, department?: string) => Promise<Signer>;
  onViewInvoice: (invoice: InvoiceRecord) => void;
}

interface QueuedFile {
  id: string;
  file: File;
  previewUrl: string;
  isProcessing: boolean;
  progress: number;
  stage: string;
  diagnostic?: ExtractionDiagnostic;
  extractedData?: import("../types").ExtractedInvoiceData;
}

export const NewInvoiceView: React.FC<NewInvoiceViewProps> = ({
  existingInvoices,
  signers,
  settings,
  onInvoiceCreated,
  onAddNewSigner,
  onViewInvoice,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queueRef = useRef<QueuedFile[]>([]);

  // Fila de ficheiros carregados
  const [fileQueue, setFileQueue] = useState<QueuedFile[]>([]);
  queueRef.current = fileQueue;
  useEffect(() => () => {
    queueRef.current.forEach((item) => URL.revokeObjectURL(item.previewUrl));
  }, []);
  const [currentQueueIndex, setCurrentQueueIndex] = useState<number>(0);
  const currentQueueIndexRef = useRef(0);
  currentQueueIndexRef.current = currentQueueIndex;

  // Campos do formulário para o documento ativo
  const [documentDate, setDocumentDate] = useState<string>('');
  const [documentNumber, setDocumentNumber] = useState<string>('');
  const [supplier, setSupplier] = useState<string>('');
  const [tradeName, setTradeName] = useState<string>('');
  const [supplierNif, setSupplierNif] = useState<string>('');
  const [saveToSupplierCatalog, setSaveToSupplierCatalog] = useState<boolean>(true);
  const [amountStr, setAmountStr] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [rawText, setRawText] = useState<string>('');
  const [diagnostic, setDiagnostic] = useState<ExtractionDiagnostic | null>(null);
  const [showDiagnosticPanel, setShowDiagnosticPanel] = useState<boolean>(true);

  const [confidence, setConfidence] = useState<{
    date: boolean;
    number: boolean;
    supplier: boolean;
    amount: boolean;
  }>({ date: false, number: false, supplier: false, amount: false });

  // Controlos de pré-visualização
  const [previewZoom, setPreviewZoom] = useState<number>(1);
  const [previewRotation, setPreviewRotation] = useState<number>(0);
  const [copiedRawText, setCopiedRawText] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Modais de decisão
  const [showDeliveryModal, setShowDeliveryModal] = useState<boolean>(false);
  const [showDuplicateModal, setShowDuplicateModal] = useState<boolean>(false);
  const [duplicateMatches, setDuplicateMatches] = useState<InvoiceRecord[]>([]);
  const [isOverrideDuplicate, setIsOverrideDuplicate] = useState<boolean>(false);
  const [duplicateJustification, setDuplicateJustification] = useState<string>('');

  // Estados de Inserção Manual de Fatura
  const [isManualMode, setIsManualMode] = useState<boolean>(false);
  const [manualDeliveryOption, setManualDeliveryOption] = useState<'EM_ASSINATURA' | 'POR_ENTREGAR' | 'DEVOLVIDA'>('EM_ASSINATURA');
  const [manualSigner, setManualSigner] = useState<string>('');
  const [manualDeliveryDate, setManualDeliveryDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [manualReturnDate, setManualReturnDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [showAddSignerInline, setShowAddSignerInline] = useState<boolean>(false);
  const [inlineSignerName, setInlineSignerName] = useState<string>('');
  const [inlineSignerDept, setInlineSignerDept] = useState<string>('');
  const [manualNifError, setManualNifError] = useState<string>('');

  // Sugestões de fornecedores
  const supplierSuggestions: string[] = React.useMemo(() => {
    const set = new Set<string>();
    existingInvoices.forEach((inv) => {
      if (inv.supplier) set.add(inv.supplier.trim());
    });
    KNOWN_PT_SUPPLIERS.forEach((s) => {
      if (typeof s === 'string') set.add(s.trim());
      else if (s && (s as any).name) set.add((s as any).name.trim());
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'pt'));
  }, [existingInvoices]);

  const currentFileItem = fileQueue[currentQueueIndex] || null;

  // Processar ficheiro selecionado
  const handleFilesSelected = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const newQueueItems: QueuedFile[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const previewUrl = URL.createObjectURL(file);
      newQueueItems.push({
        id: `file-q-${Date.now()}-${i}`,
        file,
        previewUrl,
        isProcessing: false,
        progress: 0,
        stage: 'Aguardando processamento...',
      });
    }

    const updatedQueue = [...fileQueue, ...newQueueItems];
    setFileQueue(updatedQueue);

    if (fileQueue.length === 0 && newQueueItems.length > 0) {
      setCurrentQueueIndex(0);
      processFile(newQueueItems[0], 0, updatedQueue);
    }
  };

  const processFile = async (item: QueuedFile, index: number, queue: QueuedFile[]) => {
    setFileQueue((prev) => prev.map((queued) => queued.id === item.id ? {
      ...queued, isProcessing: true, progress: 10, stage: 'A analisar documento e estrutura...',
    } : queued));

    try {
      const extracted = await extractDocumentData(
        item.file,
        item.file.name,
        (progress: number, stage: string) => {
          setFileQueue((prev) => prev.map((queued) =>
            queued.id === item.id ? { ...queued, progress, stage } : queued
          ));
        },
        settings.companyName
      );

      // Preencher campos no formulário se estivermos a ver este ficheiro
      if (index === currentQueueIndexRef.current && queueRef.current.some((queued) => queued.id === item.id)) {
        setDocumentDate(extracted.documentDate || '');
        setDocumentNumber(extracted.documentNumber || '');
        setSupplier(extracted.supplier || '');
        setTradeName(extracted.tradeName || '');
        const identifiedNif = extracted.supplierNif || extracted.diagnostic?.issuerNif || '';
        setSupplierNif(identifiedNif);
        // Se a denominação tiver de ser preenchida manualmente, guardar essa
        // confirmação evita pedir o mesmo fornecedor em faturas futuras.
        setSaveToSupplierCatalog(isValidPortugueseNif(identifiedNif));
        setAmountStr(extracted.amount !== undefined ? extracted.amount.toString() : '');
        setRawText(extracted.rawText || '');
        setConfidence(extracted.confidence);
        setDiagnostic(extracted.diagnostic || null);
      }

      setFileQueue((prev) => prev.map((queued) => queued.id === item.id ? {
        ...queued, isProcessing: false, progress: 100,
        stage: 'Extração concluída', diagnostic: extracted.diagnostic, extractedData: extracted,
      } : queued));
    } catch (err: any) {
      setFileQueue((prev) => prev.map((queued) => queued.id === item.id ? {
        ...queued, isProcessing: false, stage: 'Erro na extração. Preenchimento manual ativo.',
      } : queued));
    }
  };

  const handleSelectQueueItem = (idx: number) => {
    setCurrentQueueIndex(idx);
    const item = fileQueue[idx];
    if (item && item.extractedData) {
      setDocumentDate(item.extractedData.documentDate || '');
      setDocumentNumber(item.extractedData.documentNumber || '');
      setSupplier(item.extractedData.supplier || '');
      setTradeName(item.extractedData.tradeName || '');
      const identifiedNif = item.extractedData.supplierNif || item.diagnostic?.issuerNif || '';
      setSupplierNif(identifiedNif);
      setSaveToSupplierCatalog(isValidPortugueseNif(identifiedNif));
      setAmountStr(item.extractedData.amount !== undefined ? item.extractedData.amount.toString() : '');
      setRawText(item.extractedData.rawText || '');
      setConfidence(item.extractedData.confidence);
      setDiagnostic(item.diagnostic || null);
    } else if (item && !item.isProcessing) {
      processFile(item, idx, fileQueue);
    }
  };

  const handleRemoveQueueItem = (idx: number) => {
    const item = fileQueue[idx];
    if (item) URL.revokeObjectURL(item.previewUrl);

    const updated = fileQueue.filter((_, i) => i !== idx);
    setFileQueue(updated);
    const nextIndex = Math.max(0, Math.min(
      currentQueueIndex > idx ? currentQueueIndex - 1 : currentQueueIndex,
      updated.length - 1
    ));
    setCurrentQueueIndex(nextIndex);
    const next = updated[nextIndex];
    if (next?.extractedData) {
      setDocumentDate(next.extractedData.documentDate || '');
      setDocumentNumber(next.extractedData.documentNumber || '');
      setSupplier(next.extractedData.supplier || '');
      setTradeName(next.extractedData.tradeName || '');
      setSupplierNif(next.extractedData.supplierNif || '');
      setSaveToSupplierCatalog(isValidPortugueseNif(next.extractedData.supplierNif || ''));
      setAmountStr(next.extractedData.amount !== undefined ? String(next.extractedData.amount) : '');
      setDiagnostic(next.extractedData.diagnostic || null);
      setConfidence(next.extractedData.confidence);
      setRawText(next.extractedData.rawText || '');
    } else {
      setDocumentDate('');
      setDocumentNumber('');
      setSupplier('');
      setTradeName('');
      setSupplierNif('');
      setSaveToSupplierCatalog(false);
      setAmountStr('');
      setDiagnostic(null);
      setRawText('');
      setConfidence({ date: false, number: false, supplier: false, amount: false });
    }
  };

  // Botão de Avanço: Validação dos dados e Verificação de Duplicados

    // Gravação de fatura manual com validações completas
  const handleSaveManualInvoice = async () => {
    setFormError('');
    setManualNifError('');

    if (!documentDate.trim()) {
      setFormError('Por favor indique a data do documento.');
      return;
    }
    if (!documentNumber.trim()) {
      setFormError('Por favor introduza o número do documento (ex: FT 2024/001).');
      return;
    }
    if (!supplier.trim()) {
      setFormError('Por favor indique a designação do fornecedor.');
      return;
    }

    const numVal = parsePtCurrency(amountStr);
    if (numVal <= 0) {
      setFormError('Por favor introduza um valor monetário válido superior a 0,00 € (ex: 1.234,56 €).');
      return;
    }

    if (supplierNif.trim()) {
      if (!isValidPortugueseNif(supplierNif.trim())) {
        setManualNifError('O NIF indicado não é um NIF português válido (deve conter 9 dígitos válidos).');
        return;
      }
    }

    if (manualDeliveryOption === 'EM_ASSINATURA') {
      if (!manualSigner) {
        setFormError('Por favor selecione o responsável a quem será entregue a fatura.');
        return;
      }
      if (!manualDeliveryDate) {
        setFormError('Por favor indique a data de entrega.');
        return;
      }
    } else if (manualDeliveryOption === 'DEVOLVIDA') {
      if (!manualSigner) {
        setFormError('Por favor selecione o responsável que assinou e devolveu a fatura.');
        return;
      }
      if (!manualDeliveryDate) {
        setFormError('Por favor indique a data em que a fatura foi entregue.');
        return;
      }
      if (!manualReturnDate) {
        setFormError('Por favor indique a data de devolução assinada.');
        return;
      }
      if (manualReturnDate < manualDeliveryDate) {
        setFormError('A data de devolução assinada não pode ser anterior à data de entrega ao responsável.');
        return;
      }
    }

    // Verificar duplicados se não foi dada exceção prévia
    if (!isOverrideDuplicate) {
      const dupCheck = checkForDuplicates(
        supplier,
        documentNumber,
        numVal,
        documentDate,
        existingInvoices
      );

      if (dupCheck.isDuplicate) {
        setDuplicateMatches(dupCheck.matchedInvoices);
        setShowDuplicateModal(true);
        return;
      }
    }

    await saveCompleteInvoice(
      manualDeliveryOption,
      manualSigner || undefined,
      manualDeliveryDate || undefined,
      manualReturnDate || undefined,
      true
    );
  };

  const handleCreateSignerInline = async () => {
    if (!inlineSignerName.trim()) return;
    try {
      const created = await onAddNewSigner(inlineSignerName.trim(), inlineSignerDept.trim() || undefined);
      setManualSigner(created.name);
      setInlineSignerName('');
      setInlineSignerDept('');
      setShowAddSignerInline(false);
    } catch (err) {
      console.error('Erro ao adicionar responsável:', err);
    }
  };

  const handleProceedToDelivery = () => {
    setFormError('');

    if (!supplier.trim()) {
      setFormError('Por favor indique a designação do fornecedor.');
      return;
    }
    if (!documentNumber.trim()) {
      setFormError('Por favor introduza o número do documento.');
      return;
    }
    if (!documentDate.trim()) {
      setFormError('Por favor indique a data do documento.');
      return;
    }

    const numVal = parsePtCurrency(amountStr);
    if (numVal <= 0) {
      setFormError('Por favor introduza um valor monetário válido em euros (superior a 0,00 €).');
      return;
    }

    // Verificar Duplicados se não tiver sido dada exceção
    if (!isOverrideDuplicate) {
      const dupCheck = checkForDuplicates(
        supplier,
        documentNumber,
        numVal,
        documentDate,
        existingInvoices
      );

      if (dupCheck.isDuplicate) {
        setDuplicateMatches(dupCheck.matchedInvoices);
        setShowDuplicateModal(true);
        return;
      }
    }

    // Abrir Janela: "A quem será entregue esta fatura para assinatura?"
    setShowDeliveryModal(true);
  };

  // Gravação final no IndexedDB
  const saveCompleteInvoice = async (
    deliveryStatus: 'EM_ASSINATURA' | 'POR_ENTREGAR' | 'DEVOLVIDA',
    signerName?: string,
    delivDate?: string,
    retDate?: string,
    isManualFlag?: boolean,
    customJustification?: string
  ) => {
    const numVal = parsePtCurrency(amountStr);
    const invoiceId = `inv-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const nowIso = new Date().toISOString();
    const todayStr = nowIso.slice(0, 10);
    const isManual = isManualFlag !== undefined ? isManualFlag : (!currentFileItem);

    // O ficheiro e o texto OCR existem apenas durante a análise.
    // A única informação persistida é a necessária ao controlo administrativo.

    // Construção do Histórico
    const historyEvents: import('../types').AuditEvent[] = [
      {
        id: `evt-create-${Date.now()}`,
        timestamp: nowIso,
        effectiveDate: documentDate,
        type: 'CRIACAO',
        description: isManual
          ? `Fatura introduzida manualmente na contabilidade com estado "${deliveryStatus === 'EM_ASSINATURA' ? 'Em Assinatura' : deliveryStatus === 'DEVOLVIDA' ? 'Devolvida' : 'Por Entregar'}".`
          : `Fatura registada na contabilidade como "${deliveryStatus === 'EM_ASSINATURA' ? 'Em Assinatura' : 'Por Entregar'}".`,
        author: 'Departamento de Contabilidade',
      },
    ];

    if ((deliveryStatus === 'EM_ASSINATURA' || deliveryStatus === 'DEVOLVIDA') && signerName && delivDate) {
      historyEvents.push({
        id: `evt-deliv-${Date.now() + 1}`,
        timestamp: nowIso,
        effectiveDate: delivDate,
        type: 'ENTREGA',
        description: `Fatura entregue fisicamente a ${signerName} em ${formatPtDate(delivDate)}.`,
        author: 'Departamento de Contabilidade',
      });
    }

    if (deliveryStatus === 'DEVOLVIDA' && signerName) {
      historyEvents.push({
        id: `evt-ret-${Date.now() + 2}`,
        timestamp: nowIso,
        effectiveDate: retDate || todayStr,
        type: 'DEVOLUCAO',
        description: `Fatura devolvida e assinada por ${signerName} em ${formatPtDate(retDate || todayStr)}.`,
        author: 'Departamento de Contabilidade',
      });
    }

    const justText = customJustification || (isOverrideDuplicate ? duplicateJustification : '');
    if (justText) {
      historyEvents.push({
        id: `evt-dup-${Date.now() + 2}`,
        timestamp: nowIso,
        effectiveDate: todayStr,
        type: 'NOTA',
        description: `Exceção de duplicação autorizada: "${justText}"`,
        author: 'Departamento de Contabilidade',
      });
    }

    const newRecord: InvoiceRecord = {
      id: invoiceId,
      documentDate,
      documentNumber: documentNumber.trim(),
      supplier: supplier.trim(),
      supplierNif: supplierNif.trim() || undefined,
      amount: numVal,
      status: deliveryStatus,
      assignedTo: (deliveryStatus === 'EM_ASSINATURA' || deliveryStatus === 'DEVOLVIDA') ? signerName : undefined,
      deliveryDate: (deliveryStatus === 'EM_ASSINATURA' || deliveryStatus === 'DEVOLVIDA') ? delivDate : undefined,
      returnDate: deliveryStatus === 'DEVOLVIDA' ? (retDate || todayStr) : undefined,
      notes: notes.trim() || undefined,
      createdAt: nowIso,
      updatedAt: nowIso,
      history: historyEvents,
      isDemo: false,
      isManual: isManual,
    };

    // Guardar apenas metadados no IndexedDB (sem PDF, imagem ou texto integral).
    await storage.saveInvoice(newRecord);

    // Guardar no Catálogo Local de Fornecedores para aprendizagem contínua
    if (supplier.trim() && supplierNif.trim() && saveToSupplierCatalog && !isDisqualifiedAsSupplierName(supplier.trim())) {
      try {
        await storage.recordConfirmedSupplierUsage(supplierNif.trim(), supplier.trim(), tradeName || undefined);
      } catch (catErr) {
        console.warn('Erro ao atualizar catálogo local de fornecedores:', catErr);
      }
    }

    // Fechar modais
    setShowDeliveryModal(false);
    setShowDuplicateModal(false);
    setIsOverrideDuplicate(false);
    setDuplicateJustification('');

    // Notificar componente pai
    onInvoiceCreated(newRecord);

    // Remover da fila o ficheiro concluído ou repor modo manual
    if (currentFileItem) {
      handleRemoveQueueItem(currentQueueIndex);
    }
    setIsManualMode(false);

    // Limpar campos
    setDocumentDate('');
    setDocumentNumber('');
    setSupplier('');
    setTradeName('');
    setSupplierNif('');
    setAmountStr('');
    setNotes('');
    setRawText('');
    setDiagnostic(null);
  };

  const handleCopyRawText = async () => {
    if (!rawText) return;
    try {
      await navigator.clipboard.writeText(rawText);
      setCopiedRawText(true);
      setTimeout(() => setCopiedRawText(false), 2000);
    } catch {
      // fallback
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="application/pdf,image/png,image/jpeg,image/jpg"
        className="hidden"
        onChange={(e) => {
          void handleFilesSelected(e.target.files);
          e.target.value = '';
        }}
      />
      
      {/* Título da Página */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#253B53] tracking-tight">
            Adicionar Nova Fatura
          </h1>
          <p className="text-xs text-[#64788B] mt-0.5">
            Carregamento de documento, extração ótica local e encaminhamento para assinatura
          </p>
        </div>

        {/* Fila de Ficheiros Multi-documento */}
        {fileQueue.length > 0 && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-[#64788B] font-medium">Documentos na fila:</span>
            <div className="flex items-center gap-1.5">
              {fileQueue.map((item, idx) => (
                <button
                  key={item.id}
                  onClick={() => handleSelectQueueItem(idx)}
                  className={`px-3 py-1 rounded-md text-xs font-mono font-bold transition-colors ${
                    idx === currentQueueIndex
                      ? 'bg-[#287DBB] text-white shadow-xs'
                      : 'bg-[#DCEEFF] hover:bg-[#B8DBFA] text-[#253B53]'
                  }`}
                >
                  Doc #{idx + 1}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* SELEÇÃO DO MÉTODO DE INTRODUÇÃO (QUANDO A FILA ESTÁ VAZIA E NÃO ESTÁ EM MODO MANUAL) */}
      {fileQueue.length === 0 && !isManualMode && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            {/* Opção A — Carregar documento (com OCR e QR code) */}
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                handleFilesSelected(e.dataTransfer.files);
              }}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[#B8DBFA] hover:border-[#287DBB] bg-white hover:bg-[#F3F9FF]/80 rounded-2xl p-7 text-center transition-all cursor-pointer shadow-xs group flex flex-col justify-between"
            >
              <div>
                <div className="inline-block px-3 py-1 rounded-full text-[11px] font-bold bg-[#DCEEFF] text-[#287DBB] uppercase tracking-wider mb-4">
                  Opção A — Leitura Automática
                </div>
                <div className="w-16 h-16 bg-[#DCEEFF] text-[#287DBB] rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform shadow-xs">
                  <UploadCloud className="w-8 h-8" />
                </div>
                <h2 className="text-base font-bold text-[#253B53]">
                  Carregar documento
                </h2>
                <p className="text-xs text-[#64788B] max-w-sm mx-auto mt-2 leading-relaxed">
                  Importe um PDF ou imagem para extrair automaticamente a data, número, fornecedor e valor com OCR e QR Code fiscal local.
                </p>
              </div>

              <div className="mt-6">
                <button
                  type="button"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-xl text-xs font-semibold shadow-xs transition-colors pointer-events-none"
                >
                  <FileText className="w-4 h-4 text-white" />
                  <span>Selecionar faturas do computador</span>
                </button>
                <div className="mt-4 pt-3 border-t border-[#DCEEFF] flex flex-wrap items-center justify-center gap-3 text-[11px] text-[#64788B]">
                  <span>✓ PDF direto & Digitalizado</span>
                  <span>·</span>
                  <span>✓ OCR local offline</span>
                  <span>·</span>
                  <span>✓ QR Code AT</span>
                </div>
              </div>
            </div>

            {/* Opção B — Inserir fatura manualmente */}
            <div
              onClick={() => {
                setIsManualMode(true);
                if (!documentDate) setDocumentDate(new Date().toISOString().slice(0, 10));
                setFormError('');
              }}
              className="border-2 border-dashed border-[#B8DBFA] hover:border-[#287DBB] bg-white hover:bg-[#F3F9FF]/80 rounded-2xl p-7 text-center transition-all cursor-pointer shadow-xs group flex flex-col justify-between"
            >
              <div>
                <div className="inline-block px-3 py-1 rounded-full text-[11px] font-bold bg-[#DCEEFF] text-[#287DBB] uppercase tracking-wider mb-4">
                  Opção B — Registo Direto
                </div>
                <div className="w-16 h-16 bg-[#DCEEFF] text-[#287DBB] rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform shadow-xs">
                  <Edit3 className="w-8 h-8" />
                </div>
                <h2 className="text-base font-bold text-[#253B53]">
                  Inserir fatura manualmente
                </h2>
                <p className="text-xs text-[#64788B] max-w-sm mx-auto mt-2 leading-relaxed">
                  Registe uma fatura sem carregar qualquer documento. Apenas os dados administrativos são guardados.
                </p>
              </div>

              <div className="mt-6">
                <button
                  type="button"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-white hover:bg-[#DCEEFF] text-[#287DBB] border border-[#287DBB] rounded-xl text-xs font-semibold shadow-xs transition-colors pointer-events-none"
                >
                  <Edit3 className="w-4 h-4 text-[#287DBB]" />
                  <span>Inserir fatura manualmente</span>
                </button>
                <div className="mt-4 pt-3 border-t border-[#DCEEFF] flex flex-wrap items-center justify-center gap-3 text-[11px] text-[#64788B]">
                  <span>✓ Registo imediato</span>
                  <span>·</span>
                  <span>✓ Sugestões de fornecedores</span>
                  <span>·</span>
                  <span>✓ Sem guardar documentos</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FORMULÁRIO COMPLETO DE INSERÇÃO MANUAL DE FATURA */}
      {fileQueue.length === 0 && isManualMode && (
        <div className="bg-white rounded-2xl border border-[#B8DBFA] shadow-xs overflow-hidden">
          {/* Cabeçalho do formulário manual */}
          <div className="bg-[#DCEEFF] px-6 py-4 border-b border-[#B8DBFA] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsManualMode(false)}
                className="p-1.5 hover:bg-[#B8DBFA] rounded-lg text-[#287DBB] transition-colors"
                title="Voltar às opções"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h2 className="text-sm font-bold text-[#253B53] flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-[#287DBB]" />
                  <span>Inserir Fatura Manualmente</span>
                  <span className="text-[11px] bg-[#B8DBFA] text-[#287DBB] px-2 py-0.5 rounded-full font-semibold">
                    Registo manual
                  </span>
                </h2>
                <p className="text-xs text-[#64788B] mt-0.5">
                  Preencha os dados da fatura para registo contabilístico imediato e controlo de assinaturas.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsManualMode(false)}
              className="text-xs text-[#64788B] hover:text-[#253B53] font-medium"
            >
              Cancelar
            </button>
          </div>

          {/* Mensagens de erro de validação */}
          {formError && (
            <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{formError}</span>
            </div>
          )}

          <div className="p-6 space-y-6">
            {/* Bloco 1: Dados do Documento */}
            <div>
              <h3 className="text-xs font-bold text-[#253B53] uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-[#287DBB]" />
                <span>1. Dados da Fatura</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Data do Documento */}
                <div>
                  <label className="block text-xs font-semibold text-[#253B53] mb-1">
                    Data do Documento <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      value={documentDate}
                      onChange={(e) => setDocumentDate(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F3F9FF] border border-[#B8DBFA] focus:border-[#287DBB] focus:bg-white rounded-lg text-xs text-[#253B53] font-medium outline-hidden"
                    />
                  </div>
                </div>

                {/* Número do Documento */}
                <div>
                  <label className="block text-xs font-semibold text-[#253B53] mb-1">
                    Número do Documento <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={documentNumber}
                    onChange={(e) => setDocumentNumber(e.target.value)}
                    placeholder="Ex: FT 2024/0042"
                    className="w-full px-3 py-2 bg-[#F3F9FF] border border-[#B8DBFA] focus:border-[#287DBB] focus:bg-white rounded-lg text-xs text-[#253B53] font-medium outline-hidden uppercase"
                  />
                </div>

                {/* Valor do Documento (€) */}
                <div>
                  <label className="block text-xs font-semibold text-[#253B53] mb-1">
                    Valor do Documento (€) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={amountStr}
                      onChange={(e) => setAmountStr(e.target.value)}
                      placeholder="0,00"
                      className="w-full pl-7 pr-3 py-2 bg-[#F3F9FF] border border-[#B8DBFA] focus:border-[#287DBB] focus:bg-white rounded-lg text-xs text-[#253B53] font-bold outline-hidden"
                    />
                    <span className="absolute left-2.5 top-2.5 text-xs text-[#64788B] font-bold">€</span>
                  </div>
                </div>

                {/* Fornecedor com Autocompletar */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-[#253B53] mb-1">
                    Fornecedor / Emitente <span className="text-rose-500">*</span>
                  </label>
                  <input
                    list="manual-suppliers-datalist"
                    type="text"
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    placeholder="Comece a escrever para ver fornecedores sugeridos..."
                    className="w-full px-3 py-2 bg-[#F3F9FF] border border-[#B8DBFA] focus:border-[#287DBB] focus:bg-white rounded-lg text-xs text-[#253B53] font-medium outline-hidden"
                  />
                  <datalist id="manual-suppliers-datalist">
                    {supplierSuggestions.map((sup) => (
                      <option key={sup} value={sup} />
                    ))}
                  </datalist>
                  <p className="text-[10px] text-[#64788B] mt-1">
                    Sugestões baseadas nas faturas anteriores e nos principais fornecedores portugueses.
                  </p>
                </div>

                {/* NIF do Fornecedor */}
                <div>
                  <label className="block text-xs font-semibold text-[#253B53] mb-1">
                    NIF do Fornecedor <span className="text-[10px] font-normal text-[#64788B]">(Opcional)</span>
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    value={supplierNif}
                    onChange={(e) => {
                      setSupplierNif(e.target.value);
                      setManualNifError('');
                    }}
                    placeholder="Ex: 500123456"
                    className="w-full px-3 py-2 bg-[#F3F9FF] border border-[#B8DBFA] focus:border-[#287DBB] focus:bg-white rounded-lg text-xs text-[#253B53] font-mono outline-hidden"
                  />
                  {manualNifError && (
                    <p className="text-[10px] text-rose-600 mt-1 font-semibold">{manualNifError}</p>
                  )}
                </div>

                {/* Observações da Contabilidade */}
                <div className="md:col-span-3">
                  <label className="block text-xs font-semibold text-[#253B53] mb-1">
                    Observações <span className="text-[10px] font-normal text-[#64788B]">(Opcional)</span>
                  </label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Notas internas, centro de custos, referência de encomenda, etc."
                    className="w-full px-3 py-2 bg-[#F3F9FF] border border-[#B8DBFA] focus:border-[#287DBB] focus:bg-white rounded-lg text-xs text-[#253B53] outline-hidden resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Bloco 2: Controlo Administrativo de Assinaturas */}
            <div className="pt-4 border-t border-[#DCEEFF]">
              <h3 className="text-xs font-bold text-[#253B53] uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-[#287DBB]" />
                <span>2. Destino Administrativo da Fatura</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                {/* Opção 1: Entregar para Assinatura */}
                <label
                  className={`border-2 rounded-xl p-3.5 cursor-pointer transition-all flex flex-col justify-between ${
                    manualDeliveryOption === 'EM_ASSINATURA'
                      ? 'border-[#287DBB] bg-[#DCEEFF]/50 shadow-xs'
                      : 'border-[#B8DBFA] bg-white hover:bg-[#F3F9FF]'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <input
                      type="radio"
                      name="manualDeliveryOption"
                      checked={manualDeliveryOption === 'EM_ASSINATURA'}
                      onChange={() => setManualDeliveryOption('EM_ASSINATURA')}
                      className="mt-0.5 text-[#287DBB]"
                    />
                    <div>
                      <span className="text-xs font-bold text-[#253B53] block">
                        Entregar agora para assinatura
                      </span>
                      <span className="text-[11px] text-[#64788B] leading-tight block mt-0.5">
                        Estado "Em Assinatura", entrega a um responsável com contagem de prazos.
                      </span>
                    </div>
                  </div>
                </label>

                {/* Opção 2: Por Entregar */}
                <label
                  className={`border-2 rounded-xl p-3.5 cursor-pointer transition-all flex flex-col justify-between ${
                    manualDeliveryOption === 'POR_ENTREGAR'
                      ? 'border-[#287DBB] bg-[#DCEEFF]/50 shadow-xs'
                      : 'border-[#B8DBFA] bg-white hover:bg-[#F3F9FF]'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <input
                      type="radio"
                      name="manualDeliveryOption"
                      checked={manualDeliveryOption === 'POR_ENTREGAR'}
                      onChange={() => setManualDeliveryOption('POR_ENTREGAR')}
                      className="mt-0.5 text-[#287DBB]"
                    />
                    <div>
                      <span className="text-xs font-bold text-[#253B53] block">
                        Guardar como "Por entregar"
                      </span>
                      <span className="text-[11px] text-[#64788B] leading-tight block mt-0.5">
                        A fatura fica na contabilidade a aguardar entrega física posterior.
                      </span>
                    </div>
                  </div>
                </label>

                {/* Opção 3: Já Devolvida */}
                <label
                  className={`border-2 rounded-xl p-3.5 cursor-pointer transition-all flex flex-col justify-between ${
                    manualDeliveryOption === 'DEVOLVIDA'
                      ? 'border-[#287DBB] bg-[#DCEEFF]/50 shadow-xs'
                      : 'border-[#B8DBFA] bg-white hover:bg-[#F3F9FF]'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <input
                      type="radio"
                      name="manualDeliveryOption"
                      checked={manualDeliveryOption === 'DEVOLVIDA'}
                      onChange={() => setManualDeliveryOption('DEVOLVIDA')}
                      className="mt-0.5 text-[#287DBB]"
                    />
                    <div>
                      <span className="text-xs font-bold text-[#253B53] block">
                        Já se encontra devolvida
                      </span>
                      <span className="text-[11px] text-[#64788B] leading-tight block mt-0.5">
                        A fatura já foi assinada pelo responsável e regressou à contabilidade.
                      </span>
                    </div>
                  </div>
                </label>
              </div>

              {/* Campos dinâmicos consoante a opção selecionada */}
              {manualDeliveryOption !== 'POR_ENTREGAR' && (
                <div className="bg-[#F3F9FF] p-4 rounded-xl border border-[#B8DBFA] space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Responsável */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-semibold text-[#253B53]">
                          Responsável pela Assinatura <span className="text-rose-500">*</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => setShowAddSignerInline(!showAddSignerInline)}
                          className="text-[11px] text-[#287DBB] hover:underline font-semibold"
                        >
                          {showAddSignerInline ? 'Fechar' : '+ Novo responsável'}
                        </button>
                      </div>

                      <select
                        value={manualSigner}
                        onChange={(e) => setManualSigner(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-[#B8DBFA] focus:border-[#287DBB] rounded-lg text-xs text-[#253B53] font-medium outline-hidden"
                      >
                        <option value="">-- Selecione o responsável --</option>
                        {signers
                          .filter((s) => s.active)
                          .map((s) => (
                            <option key={s.id} value={s.name}>
                              {s.name} {s.department ? `(${s.department})` : ''}
                            </option>
                          ))}
                      </select>

                      {/* Criar novo responsável inline */}
                      {showAddSignerInline && (
                        <div className="mt-2 p-3 bg-white rounded-lg border border-[#B8DBFA] space-y-2">
                          <span className="text-[11px] font-bold text-[#253B53] block">
                            Adicionar Novo Responsável
                          </span>
                          <input
                            type="text"
                            placeholder="Nome completo..."
                            value={inlineSignerName}
                            onChange={(e) => setInlineSignerName(e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs border border-[#B8DBFA] rounded"
                          />
                          <input
                            type="text"
                            placeholder="Departamento (opcional)..."
                            value={inlineSignerDept}
                            onChange={(e) => setInlineSignerDept(e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs border border-[#B8DBFA] rounded"
                          />
                          <button
                            type="button"
                            onClick={handleCreateSignerInline}
                            className="px-3 py-1 bg-[#287DBB] hover:bg-[#1E679B] text-white text-xs font-semibold rounded"
                          >
                            Criar e Associar
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Data de Entrega */}
                    <div>
                      <label className="block text-xs font-semibold text-[#253B53] mb-1">
                        Data de Entrega ao Responsável
                      </label>
                      <input
                        type="date"
                        value={manualDeliveryDate}
                        onChange={(e) => setManualDeliveryDate(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-[#B8DBFA] focus:border-[#287DBB] rounded-lg text-xs text-[#253B53] font-medium outline-hidden"
                      />
                      <p className="text-[10px] text-[#64788B] mt-1">
                        Assume por defeito a data de hoje para controlo do prazo.
                      </p>
                    </div>

                    {/* Data de Devolução (se já devolvida) */}
                    {manualDeliveryOption === 'DEVOLVIDA' && (
                      <div>
                        <label className="block text-xs font-semibold text-[#253B53] mb-1">
                          Data de Devolução / Assinatura
                        </label>
                        <input
                          type="date"
                          value={manualReturnDate}
                          onChange={(e) => setManualReturnDate(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-[#B8DBFA] focus:border-[#287DBB] rounded-lg text-xs text-[#253B53] font-medium outline-hidden"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Informação sobre privacidade */}
            <div className="p-3.5 bg-[#DCEEFF]/40 border border-[#B8DBFA] rounded-xl flex items-center gap-3 text-xs text-[#253B53]">
              <Info className="w-5 h-5 text-[#287DBB] shrink-0" />
              <span>
                Esta fatura inclui os mesmos alertas, histórico, filtros e exportações das restantes. Não é necessário guardar uma cópia do documento.
              </span>
            </div>
          </div>

          {/* Rodapé de Ações */}
          <div className="bg-[#F3F9FF] px-6 py-4 border-t border-[#B8DBFA] flex items-center justify-between">
            <button
              type="button"
              onClick={() => setIsManualMode(false)}
              className="px-4 py-2 border border-[#B8DBFA] hover:bg-[#DCEEFF] text-[#253B53] rounded-xl text-xs font-semibold transition-colors"
            >
              Cancelar
            </button>

            <button
              type="button"
              onClick={handleSaveManualInvoice}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>Gravar Fatura Manual</span>
            </button>
          </div>
        </div>
      )}

      {/* ÁREA DE VALIDAÇÃO E EXTRAÇÃO QUANDO EXISTE FICHEIRO ATIVO */}
      {currentFileItem && (
        <div className="space-y-6">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* COLUNA ESQUERDA: Pré-visualizador do documento original (5 colunas) */}
            <div className="lg:col-span-5 bg-white rounded-xl border border-[#B8DBFA] shadow-xs overflow-hidden">
              <div className="bg-[#DCEEFF] px-4 py-3 border-b border-[#B8DBFA] text-[#253B53] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate max-w-[200px]">
                  <FileText className="w-4 h-4 text-[#287DBB] shrink-0" />
                  <span className="truncate font-semibold">{currentFileItem.file.name}</span>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => setPreviewZoom((z) => Math.max(0.5, z - 0.25))}
                    className="p-1 hover:bg-[#B8DBFA] rounded text-[#253B53]"
                    title="Diminuir Zoom"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="text-[10px] font-mono font-semibold px-1 text-[#287DBB]">{Math.round(previewZoom * 100)}%</span>
                  <button
                    type="button"
                    onClick={() => setPreviewZoom((z) => Math.min(3, z + 0.25))}
                    className="p-1 hover:bg-[#B8DBFA] rounded text-[#253B53]"
                    title="Aumentar Zoom"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewRotation((r) => (r + 90) % 360)}
                    className="p-1 hover:bg-[#B8DBFA] rounded text-[#253B53]"
                    title="Rodar 90º"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRemoveQueueItem(currentQueueIndex)}
                    className="p-1 hover:bg-rose-100 rounded text-rose-600 ml-1"
                    title="Remover / Cancelar Ficheiro"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Barra de Progresso OCR / Extração */}
              {currentFileItem.isProcessing && (
                <div className="p-3 bg-[#DCEEFF]/50 border-b border-[#B8DBFA] text-xs text-[#253B53]">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#287DBB]" />
                      <span>{currentFileItem.stage}</span>
                    </span>
                    <span className="font-mono font-bold text-[#287DBB]">{currentFileItem.progress}%</span>
                  </div>
                  <div className="w-full bg-[#B8DBFA] h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#287DBB] h-full transition-all duration-300"
                      style={{ width: `${currentFileItem.progress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Visualizador de Imagem / PDF */}
              <div className="min-h-[420px] max-h-[580px] overflow-auto bg-[#F3F9FF] p-3 flex items-center justify-center">
                {currentFileItem.file.type === 'application/pdf' || currentFileItem.file.name.toLowerCase().endsWith('.pdf') ? (
                  <PdfPagePreview
                    file={currentFileItem.file}
                    zoom={previewZoom}
                    rotation={previewRotation}
                  />
                ) : (
                  <div
                    className="transition-transform duration-150 origin-center"
                    style={{
                      transform: `scale(${previewZoom}) rotate(${previewRotation}deg)`,
                    }}
                  >
                    <img
                      src={currentFileItem.previewUrl}
                      alt="Pré-visualização da Fatura"
                      className="max-h-[520px] w-auto object-contain rounded-lg shadow-sm bg-white"
                    />
                  </div>
                )}
              </div>

              <div className="p-2.5 bg-white border-t border-[#B8DBFA] text-center">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs text-[#287DBB] hover:text-[#1E679B] font-semibold"
                >
                  Adicionar outro documento à fila
                </button>
              </div>
            </div>

            {/* COLUNA DIREITA: Formulário Contabilístico de Validação (7 colunas) */}
            <div className="lg:col-span-7 bg-white rounded-xl border border-[#B8DBFA] shadow-xs p-6 space-y-5">
              <div>
                <div className="flex items-center justify-between">
                  <h2 className="text-base font-bold text-[#253B53]">
                    Validação dos Dados da Fatura
                  </h2>
                  {diagnostic && (
                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                        diagnostic.situation === 'SUCESSO_TOTAL'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : diagnostic.situation === 'SITUACAO_C_LEITURA_PARCIAL'
                          ? 'bg-[#DCEEFF] text-[#287DBB] border-[#B8DBFA]'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}
                    >
                      {diagnostic.situation === 'SUCESSO_TOTAL'
                        ? 'Campos detetados · confirme'
                        : diagnostic.situation === 'SITUACAO_C_LEITURA_PARCIAL'
                        ? 'Leitura Parcial'
                        : 'Atenção Requerida'}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#64788B] mt-0.5">
                  Os campos identificados contextualmente foram pré-preenchidos. Confirme ou preencha os dados em falta.
                </p>
              </div>

              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Aviso de Ambiguidade de Intervenientes (Requisito Prioritário) */}
              {diagnostic?.isSupplierAmbiguous && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-lg text-xs text-amber-900 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold">Aviso de Ambiguidade de Fornecedor:</strong>
                    <p className="text-[11px] text-amber-800 mt-0.5">
                      Foram detetados múltiplos intervenientes no documento (cliente no cabeçalho ou dados divididos). Confirme se o emitente selecionado é o verdadeiro fornecedor e não o adquirente.
                    </p>
                  </div>
                </div>
              )}

              {/* Campo 1: Fornecedor e NIF do Emitente */}
              <div className="space-y-2">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Denominação Social */}
                  <div className="md:col-span-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-[#287DBB]" />
                        <span>Fornecedor (Denominação Social)</span>
                        {supplier ? (
                          confidence.supplier ? (
                            <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                              Identificado
                            </span>
                          ) : (
                            <span className="text-[10px] text-amber-800 font-semibold bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                              Confirmar
                            </span>
                          )
                        ) : (
                          <span className="text-[10px] text-rose-700 font-semibold bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                            Não identificado
                          </span>
                        )}
                      </label>
                      {diagnostic?.supplierIdentificationSource && (
                        <span className="text-[10px] font-bold text-[#287DBB] bg-[#DCEEFF] px-1.5 py-0.5 rounded">
                          {diagnostic.supplierIdentificationSource}
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      list="suppliers-list"
                      placeholder="Ex: Mundo Aquático, S.A., EDP Comercial..."
                      value={supplier}
                      onChange={(e) => setSupplier(e.target.value)}
                      className={`w-full text-sm px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53] font-medium ${
                        !supplier ? 'border-amber-300 bg-amber-50/20' : 'border-[#B8DBFA]'
                      }`}
                    />
                    <datalist id="suppliers-list">
                      {supplierSuggestions.map((s) => (
                        <option key={s} value={s} />
                      ))}
                    </datalist>

                    {/* Deteção de marca / nome comercial diferente da denominação legal */}
                    {tradeName && (
                      <div className="mt-1 text-[11px] text-[#64788B] flex items-center gap-1.5 flex-wrap">
                        <span>Marca / Nome comercial detetado: <strong className="text-[#253B53]">{tradeName}</strong></span>
                        {supplier && !supplier.includes(tradeName) && (
                          <button
                            type="button"
                            onClick={() => setSupplier(`${supplier} (${tradeName})`)}
                            className="text-[#287DBB] hover:underline font-semibold cursor-pointer"
                          >
                            (Adicionar à designação)
                          </button>
                        )}
                      </div>
                    )}

                    {/* Aviso informativo se o NIF foi detetado mas a denominação requer confirmação */}
                    {!supplier && supplierNif && (
                      <div className="mt-1.5 p-2 bg-[#DCEEFF]/70 border border-[#B8DBFA] rounded-lg text-xs text-[#253B53] flex items-center gap-2">
                        <Info className="w-4 h-4 text-[#287DBB] shrink-0" />
                        <span>
                          NIF do emitente identificado (<strong>{supplierNif}</strong>). Por favor introduza ou confirme a denominação social do fornecedor.
                        </span>
                      </div>
                    )}
                  </div>

                  {/* NIF do Fornecedor / Emitente */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-[#253B53] flex items-center gap-1">
                        <span>NIF do Emitente</span>
                        {supplierNif && isValidPortugueseNif(supplierNif) && (
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        )}
                      </label>
                      <span className="text-[10px] text-[#64788B]">9 dígitos</span>
                    </div>
                    <input
                      type="text"
                      maxLength={9}
                      placeholder="Ex: 503254174"
                      value={supplierNif}
                      onChange={(e) => setSupplierNif(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-sm px-3.5 py-2.5 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53] font-mono font-bold"
                    />
                  </div>
                </div>

                {/* Opção de aprendizagem no Catálogo Local */}
                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-[#253B53]">
                    <input
                      type="checkbox"
                      checked={saveToSupplierCatalog}
                      onChange={(e) => setSaveToSupplierCatalog(e.target.checked)}
                      className="w-3.5 h-3.5 text-[#287DBB] rounded border-[#B8DBFA] focus:ring-[#287DBB]"
                    />
                    <span className="flex items-center gap-1 text-[11px] text-[#64788B]">
                      <BookOpen className="w-3 h-3 text-[#287DBB]" />
                      <span>Memorizar e associar NIF à denominação social no Catálogo Local</span>
                    </span>
                  </label>
                  {diagnostic?.fields.supplier.reason && (
                    <p className="text-[10px] text-[#64788B] flex items-center gap-1">
                      <Info className="w-3 h-3 text-[#69B5ED] shrink-0" />
                      <span className="truncate max-w-[320px]">{diagnostic.fields.supplier.reason}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Linha Dupla: Número do Documento e Data do Documento */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Campo 2: Número do Documento */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5">
                      <span>Nº do Documento</span>
                      {documentNumber ? (
                        <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                          Identificado
                        </span>
                      ) : (
                        <span className="text-[10px] text-rose-700 font-semibold bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                          Não identificado
                        </span>
                      )}
                    </label>
                  </div>
                  <input
                    type="text"
                    placeholder="Ex: FT 2026/0491"
                    value={documentNumber}
                    onChange={(e) => setDocumentNumber(e.target.value)}
                    className={`w-full text-sm px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white font-mono text-[#253B53] font-bold ${
                      !documentNumber ? 'border-amber-300 bg-amber-50/20' : 'border-[#B8DBFA]'
                    }`}
                  />
                  <p className="text-[10px] text-[#64788B] mt-1">Preserve letras, números, barras e traços.</p>
                </div>

                {/* Campo 3: Data do Documento (Emissão) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5">
                      <span>Data de Emissão</span>
                      {documentDate ? (
                        confidence.date ? (
                          <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                            Identificado
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-800 font-semibold bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                            Confirmar
                          </span>
                        )
                      ) : (
                        <span className="text-[10px] text-rose-700 font-semibold bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                          Não identificado
                        </span>
                      )}
                    </label>
                  </div>
                  <input
                    type="date"
                    value={documentDate}
                    onChange={(e) => setDocumentDate(e.target.value)}
                    className={`w-full text-sm px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white font-mono text-[#253B53] ${
                      !documentDate ? 'border-amber-300 bg-amber-50/20' : 'border-[#B8DBFA]'
                    }`}
                  />
                  {diagnostic?.fields.date.reason ? (
                    <p className="text-[10px] text-[#64788B] mt-1 flex items-center gap-1">
                      <Info className="w-3 h-3 text-[#69B5ED]" />
                      <span>{diagnostic.fields.date.reason}</span>
                    </p>
                  ) : (
                    <p className="text-[10px] text-[#64788B] mt-1">Data de emissão (distinta do vencimento).</p>
                  )}
                </div>
              </div>

              {/* Campo 4: Valor Total em Euros */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5">
                    <span>Valor Total (com IVA)</span>
                    {amountStr ? (
                      <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                        Identificado
                      </span>
                    ) : (
                      <span className="text-[10px] text-rose-700 font-semibold bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                        Não identificado
                      </span>
                    )}
                  </label>
                  <span className="text-[12px] font-mono font-bold text-[#287DBB]">
                    {formatEuro(parseFloat(amountStr.replace(',', '.')) || 0)}
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="0,00"
                    value={amountStr}
                    onChange={(e) => setAmountStr(e.target.value)}
                    className={`w-full text-base px-3.5 py-2.5 border rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white font-mono font-bold text-[#253B53] pr-10 ${
                      !amountStr ? 'border-amber-300 bg-amber-50/20' : 'border-[#B8DBFA]'
                    }`}
                  />
                  <span className="absolute right-3.5 top-3 text-[#64788B] font-bold font-mono">€</span>
                </div>
                <p className="text-[10px] text-[#64788B] mt-1">Valores negativos permitidos para notas de crédito.</p>
              </div>

              {/* Campo 5: Observações Opcionais */}
              <div>
                <label className="text-xs font-semibold text-[#253B53] block mb-1">
                  Observações Iniciais (opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ex: Entregue juntamente com outras faturas, aguarda validação orçamental..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
              </div>

              {/* Botão de Ação Primária: Avançar para Entrega */}
              <div className="pt-2 border-t border-[#DCEEFF] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => handleRemoveQueueItem(currentQueueIndex)}
                  className="px-4 py-2.5 text-xs text-[#64788B] hover:text-[#253B53] font-medium"
                >
                  Cancelar
                </button>

                <button
                  type="button"
                  onClick={handleProceedToDelivery}
                  className="px-5 py-2.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-2"
                >
                  <span>Avançar para Entrega</span>
                  <Send className="w-4 h-4 text-white" />
                </button>
              </div>

            </div>

          </div>

          {/* PARTE 3 — ÁREA DEDICADA: DIAGNÓSTICO DE LEITURA (Requisito 12) */}
          {diagnostic && (
            <div className="bg-white rounded-xl border border-[#B8DBFA] shadow-xs overflow-hidden">
              <div
                onClick={() => setShowDiagnosticPanel((prev) => !prev)}
                className="bg-[#DCEEFF] px-5 py-3 border-b border-[#B8DBFA] flex items-center justify-between cursor-pointer select-none"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#287DBB]" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#253B53]">
                    Diagnóstico de Leitura e Auditoria de Extração
                  </h3>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      diagnostic.situation === 'SUCESSO_TOTAL'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : diagnostic.situation === 'SITUACAO_C_LEITURA_PARCIAL'
                        ? 'bg-amber-50 text-amber-800 border-amber-300'
                        : 'bg-rose-50 text-rose-800 border-rose-300'
                    }`}
                  >
                    {diagnostic.situation === 'SUCESSO_TOTAL'
                      ? 'Sucesso Total'
                      : diagnostic.situation === 'SITUACAO_C_LEITURA_PARCIAL'
                      ? 'Situação C · Leitura Parcial'
                      : 'Atenção Requerida'}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs text-[#287DBB] font-medium">
                  <span>{showDiagnosticPanel ? 'Ocultar detalhes' : 'Expandir diagnóstico'}</span>
                  {showDiagnosticPanel ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </div>

              {showDiagnosticPanel && (
                <div className="p-5 space-y-4 text-xs">
                  
                  {/* Resumo da Situação */}
                  <div
                    className={`p-3 rounded-lg border flex items-start gap-2.5 ${
                      diagnostic.situation === 'SUCESSO_TOTAL'
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                        : diagnostic.situation === 'SITUACAO_C_LEITURA_PARCIAL'
                        ? 'bg-[#F3F9FF] border-[#B8DBFA] text-[#253B53]'
                        : 'bg-amber-50/70 border-amber-200 text-amber-900'
                    }`}
                  >
                    <Info className="w-4 h-4 shrink-0 text-[#287DBB] mt-0.5" />
                    <div>
                      <span className="font-bold">{diagnostic.situationMessage}</span>
                      <p className="text-[11px] text-[#64788B] mt-0.5">
                        Processamento realizado 100% no navegador sem recurso a inteligência artificial externa ou envio de ficheiros.
                      </p>
                    </div>
                  </div>

                  {/* Grelha de Métricas Técnicas */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#F3F9FF] p-3.5 rounded-lg border border-[#B8DBFA] text-[11px]">
                    <div>
                      <span className="text-[#64788B] block">Tipo de Documento:</span>
                      <strong className="text-[#253B53] font-semibold">{diagnostic.documentType}</strong>
                    </div>
                    <div>
                      <span className="text-[#64788B] block">Método Utilizado:</span>
                      <strong className="text-[#253B53] font-semibold">{diagnostic.method}</strong>
                    </div>
                    <div>
                      <span className="text-[#64788B] block">Páginas / Camada Digital:</span>
                      <strong className="text-[#253B53] font-semibold">
                        {diagnostic.pagesAnalyzed} pág. · {diagnostic.hasDigitalText ? 'Texto digital ativo' : 'Digitalização'}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[#64788B] block">Carateres Extraídos:</span>
                      <strong className="text-[#253B53] font-mono font-bold">
                        {diagnostic.charactersExtracted} carateres
                      </strong>
                    </div>
                  </div>

                  {/* Intervenientes Fiscais e Origem (Requisitos Prioritários) */}
                  <div className="bg-[#F3F9FF] p-3.5 rounded-lg border border-[#B8DBFA] space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-[#253B53]">
                        <Building2 className="w-4 h-4 text-[#287DBB]" />
                        <span>Identificação de Intervenientes e Origem Fiscal</span>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA]">
                        Origem: {diagnostic.supplierIdentificationSource || 'Análise Textual Contextual'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                      {/* Emitente / Fornecedor */}
                      <div className="p-2.5 bg-white rounded border border-[#B8DBFA]">
                        <span className="text-[#64788B] block text-[10px] uppercase font-semibold">
                          Emitente (Verdadeiro Fornecedor):
                        </span>
                        <div className="font-bold text-[#253B53] text-xs mt-0.5">
                          {diagnostic.fields.supplier.value || 'Não identificado'}
                        </div>
                        <div className="text-[#287DBB] font-mono font-semibold mt-0.5">
                          NIF Emitente: {diagnostic.issuerNif || 'Não detetado'}
                        </div>
                      </div>

                      {/* Adquirente / Cliente */}
                      <div className="p-2.5 bg-white rounded border border-[#B8DBFA]">
                        <span className="text-[#64788B] block text-[10px] uppercase font-semibold">
                          Adquirente (Cliente / Destinatário):
                        </span>
                        <div className="font-bold text-[#64788B] text-xs mt-0.5">
                          {settings.companyName || 'Empresa Cliente'}
                        </div>
                        <div className="text-[#64788B] font-mono font-semibold mt-0.5">
                          NIF Adquirente: {diagnostic.buyerNif || 'Não detetado'}
                        </div>
                      </div>
                    </div>

                    {/* Detalhe do Código QR Fiscal AT (Portaria 195/2020) */}
                    <div className="p-2.5 bg-white rounded border border-[#B8DBFA]">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-[#253B53] flex items-center gap-1.5 text-[11px]">
                          <QrCode className="w-3.5 h-3.5 text-[#287DBB]" />
                          <span>Código QR Fiscal da Autoridade Tributária</span>
                        </span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                            diagnostic.qrFiscalData?.isValid
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-[#64788B]'
                          }`}
                        >
                          {diagnostic.qrFiscalData?.isValid ? 'Descodificado com Sucesso' : 'Não detetado / Ausente'}
                        </span>
                      </div>

                      {diagnostic.qrFiscalData?.isValid ? (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] bg-[#F3F9FF] p-2 rounded font-mono">
                          <div>
                            <span className="text-[#64788B] block">Campo A (NIF Emit.):</span>
                            <strong className="text-[#253B53]">{diagnostic.qrFiscalData.issuerNif || '—'}</strong>
                          </div>
                          <div>
                            <span className="text-[#64788B] block">Campo B (NIF Adq.):</span>
                            <strong className="text-[#253B53]">{diagnostic.qrFiscalData.buyerNif || '—'}</strong>
                          </div>
                          <div>
                            <span className="text-[#64788B] block">Campo F (Data):</span>
                            <strong className="text-[#253B53]">{diagnostic.qrFiscalData.docDate || '—'}</strong>
                          </div>
                          <div>
                            <span className="text-[#64788B] block">Campo G (Nº Doc):</span>
                            <strong className="text-[#253B53]">{diagnostic.qrFiscalData.docNumber || '—'}</strong>
                          </div>
                          <div className="col-span-2">
                            <span className="text-[#64788B] block">Campo O (Total com Impostos):</span>
                            <strong className="text-[#287DBB] font-bold">
                              {diagnostic.qrFiscalData.totalAmount !== undefined
                                ? formatEuro(diagnostic.qrFiscalData.totalAmount)
                                : '—'}
                            </strong>
                          </div>
                          <div className="col-span-2">
                            <span className="text-[#64788B] block">Campo H (ATCUD):</span>
                            <strong className="text-[#253B53] truncate block">{diagnostic.qrFiscalData.atcud || '0'}</strong>
                          </div>
                        </div>
                      ) : (
                        <p className="text-[10px] text-[#64788B]">
                          Documento sem código QR fiscal ou imagem ilegível. A identificação de emitente e adquirente baseou-se integralmente em análise contextual de NIFs, cabeçalho e rodapé.
                        </p>
                      )}
                    </div>

                    {/* Candidatos a Fornecedor e Motivos de Seleção/Rejeição */}
                    {diagnostic.supplierCandidates && diagnostic.supplierCandidates.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        <span className="font-bold text-[#253B53] text-[11px] block">
                          Candidatos Analisados e Motivo da Decisão:
                        </span>
                        <div className="space-y-1 max-h-36 overflow-y-auto">
                          {diagnostic.supplierCandidates.map((cand, idx) => (
                            <div
                              key={idx}
                              className={`p-1.5 rounded text-[10px] flex items-center justify-between border ${
                                cand.isClientRejected
                                  ? 'bg-rose-50/50 border-rose-200 text-rose-800 line-through'
                                  : cand.name === diagnostic.fields.supplier.value
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-semibold'
                                  : 'bg-white border-[#B8DBFA] text-[#253B53]'
                              }`}
                            >
                              <div className="truncate max-w-[80%] flex items-center gap-1.5">
                                {cand.isClientRejected ? (
                                  <UserX className="w-3 h-3 text-rose-500 shrink-0" />
                                ) : cand.name === diagnostic.fields.supplier.value ? (
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                ) : (
                                  <Info className="w-3 h-3 text-[#69B5ED] shrink-0" />
                                )}
                                <span>
                                  <strong>{cand.name}</strong> — {cand.reason}
                                </span>
                              </div>
                              <span className="font-mono text-[9px] shrink-0 font-bold">
                                {cand.isClientRejected ? 'CLIENTE' : `${cand.score} pts`}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Tabela de Evidência dos 4 Campos */}
                  <div>
                    <h4 className="font-bold text-[#253B53] mb-2 uppercase tracking-wider text-[11px]">
                      Evidência de Seleção dos Campos Contabilísticos
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Fornecedor */}
                      <div className="p-3 bg-white rounded-lg border border-[#B8DBFA] space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-[#253B53]">1. Fornecedor (Emitente)</span>
                          <span
                            className={`px-1.5 py-0.2 rounded font-semibold text-[10px] ${
                              diagnostic.fields.supplier.confidence
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {diagnostic.fields.supplier.confidence ? 'Forte Evidência' : 'Evidência Moderada'}
                          </span>
                        </div>
                        <p className="font-semibold text-[#287DBB] text-xs">
                          {diagnostic.fields.supplier.value || 'Não localizado'}
                        </p>
                        <p className="text-[10px] text-[#64788B] leading-tight">
                          {diagnostic.fields.supplier.reason}
                        </p>
                      </div>

                      {/* Data de Emissão */}
                      <div className="p-3 bg-white rounded-lg border border-[#B8DBFA] space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-[#253B53]">2. Data do Documento (Emissão)</span>
                          <span
                            className={`px-1.5 py-0.2 rounded font-semibold text-[10px] ${
                              diagnostic.fields.date.confidence
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {diagnostic.fields.date.confidence ? 'Forte Evidência' : 'Evidência Moderada'}
                          </span>
                        </div>
                        <p className="font-semibold text-[#287DBB] text-xs font-mono">
                          {formatPtDate(diagnostic.fields.date.value as string) || 'Não localizada'}
                        </p>
                        <p className="text-[10px] text-[#64788B] leading-tight">
                          {diagnostic.fields.date.reason}
                        </p>
                      </div>

                      {/* Número do Documento */}
                      <div className="p-3 bg-white rounded-lg border border-[#B8DBFA] space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-[#253B53]">3. Número da Fatura</span>
                          <span
                            className={`px-1.5 py-0.2 rounded font-semibold text-[10px] ${
                              diagnostic.fields.number.confidence
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {diagnostic.fields.number.confidence ? 'Série Válida' : 'Incerteza'}
                          </span>
                        </div>
                        <p className="font-semibold text-[#287DBB] text-xs font-mono">
                          {diagnostic.fields.number.value || 'Não localizado'}
                        </p>
                        <p className="text-[10px] text-[#64788B] leading-tight">
                          {diagnostic.fields.number.reason}
                        </p>
                      </div>

                      {/* Valor Total */}
                      <div className="p-3 bg-white rounded-lg border border-[#B8DBFA] space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-[#253B53]">4. Valor Total com IVA</span>
                          <span
                            className={`px-1.5 py-0.2 rounded font-semibold text-[10px] ${
                              diagnostic.fields.amount.confidence
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {diagnostic.fields.amount.confidence ? 'Total Isolado' : 'Averiguar'}
                          </span>
                        </div>
                        <p className="font-semibold text-[#287DBB] text-xs font-mono">
                          {formatEuro(diagnostic.fields.amount.value as number)}
                        </p>
                        <p className="text-[10px] text-[#64788B] leading-tight">
                          {diagnostic.fields.amount.reason}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Texto Estruturado Extraído com Botão de Cópia */}
                  <div className="space-y-2 pt-2 border-t border-[#DCEEFF]">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#253B53]">Texto Reconstruído Linha a Linha:</span>
                      <button
                        type="button"
                        onClick={handleCopyRawText}
                        className="px-2.5 py-1 bg-[#DCEEFF] hover:bg-[#B8DBFA] text-[#287DBB] rounded text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        {copiedRawText ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Copiado com sucesso</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-[#287DBB]" />
                            <span>Copiar texto extraído</span>
                          </>
                        )}
                      </button>
                    </div>

                    <pre className="p-3 bg-[#F3F9FF] text-[#253B53] font-mono text-[11px] rounded-lg border border-[#B8DBFA] max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                      {rawText || 'Sem texto extraído.'}
                    </pre>
                  </div>

                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* MODAL 1: "A quem será entregue esta fatura para assinatura?" */}
      <DeliveryModal
        isOpen={showDeliveryModal}
        invoice={{
          supplier,
          documentNumber,
          documentDate,
          amount: parsePtCurrency(amountStr),
        }}
        signers={signers}
        onConfirmDelivery={(signerName, delivDate) => {
          saveCompleteInvoice('EM_ASSINATURA', signerName, delivDate);
        }}
        onSaveWithoutDelivery={() => {
          saveCompleteInvoice('POR_ENTREGAR');
        }}
        onCancel={() => setShowDeliveryModal(false)}
        onAddNewSigner={onAddNewSigner}
      />

      {/* MODAL 2: Aviso de Fatura Duplicada */}
      <DuplicateWarningModal
        isOpen={showDuplicateModal}
        newInvoiceData={{
          supplier,
          documentNumber,
          documentDate,
          amount: parseFloat(amountStr.replace(',', '.')) || 0,
        }}
        matchedInvoices={duplicateMatches}
        onCancel={() => setShowDuplicateModal(false)}
        onViewExisting={(existing) => {
          setShowDuplicateModal(false);
          onViewInvoice(existing);
        }}
        onProceedAnyway={(justification) => {
          setIsOverrideDuplicate(true);
          setDuplicateJustification(justification);
          setShowDuplicateModal(false);
          if (isManualMode) {
            saveCompleteInvoice(
              manualDeliveryOption,
              manualSigner || undefined,
              manualDeliveryDate || undefined,
              manualReturnDate || undefined,
              true,
              justification
            );
          } else {
            setShowDeliveryModal(true);
          }
        }}
      />

    </div>
  );
};
