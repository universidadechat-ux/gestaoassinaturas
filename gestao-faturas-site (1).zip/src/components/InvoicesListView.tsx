import React, { useState, useMemo } from 'react';
import { AppSettings, InvoiceRecord, InvoiceStatus, Signer } from '../types';
import { formatEuro, formatPtDate } from '../services/extractor';
import { calculateDaysElapsed, getDelayAlertLevel } from '../services/businessRules';
import { exportInvoicesToExcel } from '../services/excel';
import {
  Search,
  Download,
  ArrowUpDown,
  ArrowDownLeft,
  Eye,
  Send,
  AlertTriangle,
  Calendar,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  RotateCcw,
} from 'lucide-react';

interface InvoicesListViewProps {
  invoices: InvoiceRecord[];
  signers: Signer[];
  settings: AppSettings;
  initialFilterDelay?: boolean;
  onSelectInvoice: (invoice: InvoiceRecord) => void;
  onRequestReturn: (invoice: InvoiceRecord) => void;
  onRequestDelivery: (invoice: InvoiceRecord) => void;
  onNavigateToNew: () => void;
}

type SortField = 'documentDate' | 'documentNumber' | 'supplier' | 'amount' | 'deliveryDate' | 'daysInSigning' | 'status';
type SortOrder = 'asc' | 'desc';

export const InvoicesListView: React.FC<InvoicesListViewProps> = ({
  invoices,
  signers,
  settings,
  initialFilterDelay = false,
  onSelectInvoice,
  onRequestReturn,
  onRequestDelivery,
}) => {
  // Filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | InvoiceStatus>('ALL');
  const [signerFilter, setSignerFilter] = useState<string>('ALL');
  const [onlyDelayed, setOnlyDelayed] = useState<boolean>(initialFilterDelay);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Ordenação
  const [sortField, setSortField] = useState<SortField>('daysInSigning');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  // Paginação
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;

  // Filtragem
  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      // Pesquisa por número ou fornecedor
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const matchesNum = inv.documentNumber.toLowerCase().includes(term);
        const matchesSup = inv.supplier.toLowerCase().includes(term);
        const matchesSigner = (inv.assignedTo || '').toLowerCase().includes(term);
        if (!matchesNum && !matchesSup && !matchesSigner) return false;
      }

      // Filtro por Estado
      if (statusFilter !== 'ALL' && inv.status !== statusFilter) {
        return false;
      }

      // Filtro por Responsável
      if (signerFilter !== 'ALL' && inv.assignedTo !== signerFilter) {
        return false;
      }

      // Filtro: apenas em atraso
      if (onlyDelayed) {
        if (inv.status !== 'EM_ASSINATURA') return false;
        const alert = getDelayAlertLevel(inv, settings);
        if (alert.level === 'normal') return false;
      }

      // Intervalo de Datas (emissão)
      if (startDate && inv.documentDate < startDate) return false;
      if (endDate && inv.documentDate > endDate) return false;

      return true;
    });
  }, [invoices, searchTerm, statusFilter, signerFilter, onlyDelayed, startDate, endDate, settings]);

  // Ordenação
  const sortedInvoices = useMemo(() => {
    return [...filteredInvoices].sort((a, b) => {
      let valA: any = a[sortField as keyof InvoiceRecord];
      let valB: any = b[sortField as keyof InvoiceRecord];

      if (sortField === 'daysInSigning') {
        valA = a.status === 'EM_ASSINATURA' ? calculateDaysElapsed(a.deliveryDate) : -1;
        valB = b.status === 'EM_ASSINATURA' ? calculateDaysElapsed(b.deliveryDate) : -1;
      }

      if (valA === undefined || valA === null) valA = '';
      if (valB === undefined || valB === null) valB = '';

      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortOrder === 'asc' ? valA - valB : valB - valA;
      }

      return sortOrder === 'asc'
        ? String(valA).localeCompare(String(valB))
        : String(valB).localeCompare(String(valA));
    });
  }, [filteredInvoices, sortField, sortOrder]);

  // Paginação
  const totalPages = Math.ceil(sortedInvoices.length / pageSize) || 1;
  const paginatedInvoices = sortedInvoices.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const handleExportFiltered = () => {
    exportInvoicesToExcel(sortedInvoices, 'Faturas_Controlo_Assinaturas');
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setStatusFilter('ALL');
    setSignerFilter('ALL');
    setOnlyDelayed(false);
    setStartDate('');
    setEndDate('');
    setCurrentPage(1);
  };

  const hasActiveFilters =
    searchTerm || statusFilter !== 'ALL' || signerFilter !== 'ALL' || onlyDelayed || startDate || endDate;

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      
      {/* Cabeçalho da Vista */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-[#253B53] tracking-tight flex items-center gap-2">
            <span>Gestão e Controlo de Faturas</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#DCEEFF] text-[#287DBB] font-mono font-semibold border border-[#B8DBFA]">
              {filteredInvoices.length} {filteredInvoices.length === 1 ? 'documento' : 'documentos'}
            </span>
          </h1>
          <p className="text-xs text-[#64788B] mt-0.5">
            Tabela administrativa para consulta, acompanhamento de circulação e registo de devoluções
          </p>
        </div>

        <div className="flex items-center gap-2">
          {hasActiveFilters && (
            <button
              onClick={handleClearFilters}
              className="px-2.5 py-1.5 text-xs text-[#64788B] hover:text-[#253B53] hover:bg-[#DCEEFF] rounded-lg flex items-center gap-1 transition-colors border border-transparent hover:border-[#B8DBFA]"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Limpar Filtros</span>
            </button>
          )}

          <button
            onClick={handleExportFiltered}
            className="px-3.5 py-1.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-white" />
            <span>Exportar Excel ({filteredInvoices.length})</span>
          </button>
        </div>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-3.5 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs">
          
          {/* Pesquisa por Número ou Fornecedor */}
          <div className="md:col-span-4 relative">
            <Search className="w-4 h-4 text-[#69B5ED] absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Pesquisar por nº fatura, fornecedor ou responsável..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] text-xs bg-[#F3F9FF] text-[#253B53]"
            />
          </div>

          {/* Filtro por Estado */}
          <div className="md:col-span-2">
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] text-xs bg-white text-[#253B53]"
            >
              <option value="ALL">Todos os Estados</option>
              <option value="POR_ENTREGAR">Por Entregar</option>
              <option value="EM_ASSINATURA">Em Assinatura</option>
              <option value="DEVOLVIDA">Devolvida</option>
            </select>
          </div>

          {/* Filtro por Responsável */}
          <div className="md:col-span-3">
            <select
              value={signerFilter}
              onChange={(e) => {
                setSignerFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] text-xs bg-white text-[#253B53]"
            >
              <option value="ALL">Todos os Responsáveis</option>
              {signers.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Botão de Filtro Rápido: Faturas com devolução em atraso */}
          <div className="md:col-span-3 flex items-center">
            <button
              type="button"
              onClick={() => {
                setOnlyDelayed((prev) => !prev);
                setCurrentPage(1);
              }}
              className={`w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border ${
                onlyDelayed
                  ? 'bg-rose-50 border-rose-300 text-rose-700 shadow-xs'
                  : 'bg-[#F3F9FF] hover:bg-[#DCEEFF] border-[#B8DBFA] text-[#253B53]'
              }`}
            >
              <AlertTriangle className={`w-3.5 h-3.5 ${onlyDelayed ? 'text-rose-600' : 'text-[#69B5ED]'}`} />
              <span>Devoluções em atraso</span>
            </button>
          </div>

        </div>

        {/* Linha Secundária de Filtro por Data */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#DCEEFF] text-[11px] text-[#64788B]">
          <span className="font-semibold text-[#253B53] flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-[#69B5ED]" />
            <span>Data de emissão:</span>
          </span>
          <span>De</span>
          <input
            type="date"
            value={startDate}
            onChange={(e) => {
              setStartDate(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2 py-1 border border-[#B8DBFA] rounded text-xs bg-white font-mono text-[#253B53]"
          />
          <span>Até</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => {
              setEndDate(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2 py-1 border border-[#B8DBFA] rounded text-xs bg-white font-mono text-[#253B53]"
          />

          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => {
                setSortField('daysInSigning');
                setSortOrder('desc');
              }}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors border ${
                sortField === 'daysInSigning'
                  ? 'bg-[#DCEEFF] text-[#287DBB] border-[#B8DBFA] font-bold'
                  : 'text-[#64788B] hover:bg-[#F3F9FF] border-transparent'
              }`}
            >
              Ordenar por mais tempo em assinatura
            </button>
          </div>
        </div>
      </div>

      {/* TABELA PRINCIPAL DE FATURAS COM CABEÇALHO AZUL CLARO E LINHAS ALTERNADAS */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#DCEEFF] text-[#253B53] font-bold border-b border-[#B8DBFA] select-none">
                <th
                  onClick={() => handleSort('documentDate')}
                  className="py-3 px-3.5 cursor-pointer hover:text-[#287DBB] whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Data Doc.</span>
                    <ArrowUpDown className="w-3 h-3 text-[#69B5ED]" />
                  </div>
                </th>

                <th
                  onClick={() => handleSort('documentNumber')}
                  className="py-3 px-3 cursor-pointer hover:text-[#287DBB] whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Nº Documento</span>
                    <ArrowUpDown className="w-3 h-3 text-[#69B5ED]" />
                  </div>
                </th>

                <th
                  onClick={() => handleSort('supplier')}
                  className="py-3 px-3 cursor-pointer hover:text-[#287DBB]"
                >
                  <div className="flex items-center gap-1">
                    <span>Fornecedor</span>
                    <ArrowUpDown className="w-3 h-3 text-[#69B5ED]" />
                  </div>
                </th>

                <th
                  onClick={() => handleSort('amount')}
                  className="py-3 px-3 cursor-pointer hover:text-[#287DBB] text-right whitespace-nowrap"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Valor (€)</span>
                    <ArrowUpDown className="w-3 h-3 text-[#69B5ED]" />
                  </div>
                </th>

                <th className="py-3 px-3 whitespace-nowrap">
                  <span>Entregue a</span>
                </th>

                <th
                  onClick={() => handleSort('deliveryDate')}
                  className="py-3 px-3 cursor-pointer hover:text-[#287DBB] whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Data Entrega</span>
                    <ArrowUpDown className="w-3 h-3 text-[#69B5ED]" />
                  </div>
                </th>

                <th className="py-3 px-3 whitespace-nowrap">
                  <span>Data Devolução</span>
                </th>

                <th
                  onClick={() => handleSort('status')}
                  className="py-3 px-3 cursor-pointer hover:text-[#287DBB] whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Estado / Situação</span>
                    <ArrowUpDown className="w-3 h-3 text-[#69B5ED]" />
                  </div>
                </th>

                <th className="py-3 px-3 hidden lg:table-cell">
                  <span>Observações</span>
                </th>

                <th className="py-3 px-3.5 text-right whitespace-nowrap">
                  <span>Ações</span>
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-[#EBF4FC]">
              {paginatedInvoices.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-[#64788B]">
                    <div className="max-w-xs mx-auto space-y-2">
                      <FileSpreadsheet className="w-8 h-8 text-[#B8DBFA] mx-auto" />
                      <p className="font-semibold text-[#253B53]">Nenhuma fatura encontrada com os filtros selecionados.</p>
                      {hasActiveFilters && (
                        <button
                          onClick={handleClearFilters}
                          className="text-xs text-[#287DBB] hover:underline font-semibold"
                        >
                          Limpar todos os filtros
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedInvoices.map((inv, rowIdx) => {
                  const alert = getDelayAlertLevel(inv, settings);
                  const daysInCirculation =
                    inv.status === 'EM_ASSINATURA'
                      ? calculateDaysElapsed(inv.deliveryDate)
                      : inv.status === 'DEVOLVIDA'
                      ? calculateDaysElapsed(inv.deliveryDate, inv.returnDate)
                      : 0;

                  // Linhas alternadas entre Branco (#FFFFFF) e Azul muito suave (#F3F9FF)
                  const isEvenRow = rowIdx % 2 === 0;

                  return (
                    <tr
                      key={inv.id}
                      className={`transition-colors text-[#253B53] ${
                        isEvenRow ? 'bg-white' : 'bg-[#F3F9FF]'
                      } hover:bg-[#DCEEFF]/50`}
                    >
                      {/* Data Documento */}
                      <td className="py-2.5 px-3.5 font-mono text-[#253B53] whitespace-nowrap">
                        {formatPtDate(inv.documentDate)}
                      </td>

                      {/* Nº Documento */}
                      <td className="py-2.5 px-3 font-mono font-bold text-[#253B53] whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{inv.documentNumber}</span>
                          {inv.isManual && (
                            <span className="text-[10px] bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA] px-1.5 py-0.5 rounded font-medium shrink-0" title="Fatura introduzida manualmente sem anexo obrigatório">
                              Registo manual
                            </span>
                          )}
                          {inv.isDemo && (
                            <span className="text-[9px] px-1 py-0.2 bg-[#DCEEFF] text-[#287DBB] rounded border border-[#B8DBFA]">
                              Demo
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Fornecedor */}
                      <td className="py-2.5 px-3 font-semibold text-[#253B53] max-w-[220px] truncate" title={inv.supplier}>
                        {inv.supplier}
                      </td>

                      {/* Valor */}
                      <td className="py-2.5 px-3 font-mono font-bold text-[#253B53] text-right tabular-nums whitespace-nowrap">
                        {formatEuro(inv.amount)}
                      </td>

                      {/* Entregue a */}
                      <td className="py-2.5 px-3 text-[#253B53] whitespace-nowrap">
                        {inv.assignedTo ? (
                          <span className="font-medium">{inv.assignedTo}</span>
                        ) : (
                          <span className="text-[#64788B] italic">Por entregar</span>
                        )}
                      </td>

                      {/* Data Entrega */}
                      <td className="py-2.5 px-3 font-mono text-[#64788B] whitespace-nowrap">
                        {formatPtDate(inv.deliveryDate)}
                      </td>

                      {/* Data Devolução */}
                      <td className="py-2.5 px-3 font-mono text-[#64788B] whitespace-nowrap">
                        {formatPtDate(inv.returnDate)}
                      </td>

                      {/* Estado Automático com Alertas Visuais Suaves */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        {inv.status === 'POR_ENTREGAR' && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold bg-[#E2EEF9] text-[#253B53] border border-[#B8DBFA]">
                            Por Entregar
                          </span>
                        )}

                        {inv.status === 'EM_ASSINATURA' && (
                          <div className="space-y-0.5">
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold border ${
                                alert.level === 'critical'
                                  ? 'bg-[#FEF2F2] text-rose-800 border-rose-300'
                                  : alert.level === 'warning'
                                  ? 'bg-[#FEF3C7] text-amber-900 border-amber-300'
                                  : 'bg-[#FEF3C7]/70 text-amber-900 border-amber-200'
                              }`}
                            >
                              <Clock className="w-3 h-3 text-amber-700" />
                              <span>Em Assinatura ({daysInCirculation}d)</span>
                            </span>
                            {alert.level !== 'normal' && (
                              <div className="text-[10px] text-rose-700 font-medium">
                                {alert.label}
                              </div>
                            )}
                          </div>
                        )}

                        {inv.status === 'DEVOLVIDA' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-[#ECFDF5] text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Devolvida</span>
                          </span>
                        )}
                      </td>

                      {/* Observações */}
                      <td className="py-2.5 px-3 hidden lg:table-cell text-[#64788B] max-w-[180px] truncate" title={inv.notes}>
                        {inv.notes || '—'}
                      </td>

                      {/* Ações */}
                      <td className="py-2.5 px-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Ação 1: Registar devolução (se estiver em assinatura) */}
                          {inv.status === 'EM_ASSINATURA' && (
                            <button
                              type="button"
                              onClick={() => onRequestReturn(inv)}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1 shadow-xs"
                              title="Registar data em que o documento regressou assinado"
                            >
                              <ArrowDownLeft className="w-3 h-3" />
                              <span>Devolver</span>
                            </button>
                          )}

                          {/* Ação 2: Entregar para assinatura (se estiver por entregar) */}
                          {inv.status === 'POR_ENTREGAR' && (
                            <button
                              type="button"
                              onClick={() => onRequestDelivery(inv)}
                              className="px-2.5 py-1 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1 shadow-xs"
                              title="Registar entrega física a um responsável"
                            >
                              <Send className="w-3 h-3" />
                              <span>Entregar</span>
                            </button>
                          )}

                          {/* Ação 3: Ver detalhes / documento */}
                          <button
                            type="button"
                            onClick={() => onSelectInvoice(inv)}
                            className="p-1 text-[#64788B] hover:text-[#253B53] hover:bg-[#DCEEFF] rounded transition-colors"
                            title="Consultar ficha completa da fatura e documento"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Rodapé de Paginação */}
        <div className="bg-[#F3F9FF] px-4 py-3 border-t border-[#B8DBFA] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#64788B]">
          <div>
            A apresentar <strong className="text-[#253B53]">{Math.min(filteredInvoices.length, (currentPage - 1) * pageSize + 1)}</strong> a{' '}
            <strong className="text-[#253B53]">{Math.min(filteredInvoices.length, currentPage * pageSize)}</strong> de{' '}
            <strong className="text-[#253B53]">{filteredInvoices.length}</strong> faturas
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="px-2.5 py-1 rounded border border-[#B8DBFA] bg-white hover:bg-[#DCEEFF] disabled:opacity-40 text-xs text-[#253B53]"
            >
              Anterior
            </button>
            <span className="px-2 font-mono text-[#253B53]">
              Página {currentPage} de {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="px-2.5 py-1 rounded border border-[#B8DBFA] bg-white hover:bg-[#DCEEFF] disabled:opacity-40 text-xs text-[#253B53]"
            >
              Seguinte
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
