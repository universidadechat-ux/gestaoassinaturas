import React, { useState } from 'react';
import { InvoiceRecord, Signer } from '../types';
import { formatEuro } from '../services/extractor';
import {
  Users,
  UserPlus,
  Edit2,
  Check,
  X,
  UserX,
  UserCheck,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

interface SignersViewProps {
  signers: Signer[];
  invoices: InvoiceRecord[];
  onSaveSigner: (signer: Signer) => Promise<void>;
  onFilterSignerInvoices: (signerName: string) => void;
}

export const SignersView: React.FC<SignersViewProps> = ({
  signers,
  invoices,
  onSaveSigner,
  onFilterSignerInvoices,
}) => {
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDepartment, setNewDepartment] = useState('');
  const [editingSignerId, setEditingSignerId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDepartment, setEditDepartment] = useState('');

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newSigner: Signer = {
      id: `sig-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: newName.trim(),
      department: newDepartment.trim() || undefined,
      active: true,
      createdAt: new Date().toISOString(),
    };

    await onSaveSigner(newSigner);
    setNewName('');
    setNewDepartment('');
    setIsAddingNew(false);
  };

  const handleStartEdit = (s: Signer) => {
    setEditingSignerId(s.id);
    setEditName(s.name);
    setEditDepartment(s.department || '');
  };

  const handleSaveEdit = async (s: Signer) => {
    if (!editName.trim()) return;
    const updated: Signer = {
      ...s,
      name: editName.trim(),
      department: editDepartment.trim() || undefined,
    };
    await onSaveSigner(updated);
    setEditingSignerId(null);
  };

  const handleToggleActive = async (s: Signer) => {
    const updated: Signer = {
      ...s,
      active: !s.active,
    };
    await onSaveSigner(updated);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Cabeçalho */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#253B53] tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-[#287DBB]" />
            <span>Gestão de Responsáveis pela Assinatura</span>
          </h1>
          <p className="text-xs text-[#64788B] mt-0.5">
            Decisores da empresa aos quais são entregues documentos físicos para aposição de assinatura
          </p>
        </div>

        {!isAddingNew && (
          <button
            onClick={() => setIsAddingNew(true)}
            className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <UserPlus className="w-4 h-4 text-white" />
            <span>Adicionar Responsável</span>
          </button>
        )}
      </div>

      {/* Formulário de Novo Responsável */}
      {isAddingNew && (
        <form
          onSubmit={handleCreate}
          className="bg-white rounded-xl border-2 border-[#69B5ED] p-5 shadow-sm space-y-4 animate-in fade-in"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#287DBB] flex items-center gap-1.5">
              <UserPlus className="w-4 h-4 text-[#287DBB]" />
              <span>Novo Responsável</span>
            </h2>
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="text-[#64788B] hover:text-[#253B53]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-[#253B53] block mb-1">
                Nome Completo do Responsável *
              </label>
              <input
                type="text"
                placeholder="Ex: Marco António, Dr. António Costa..."
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                autoFocus
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#253B53] block mb-1">
                Departamento ou Cargo (opcional)
              </label>
              <input
                type="text"
                placeholder="Ex: Direção de Operações, Recursos Humanos..."
                value={newDepartment}
                onChange={(e) => setNewDepartment(e.target.value)}
                className="w-full text-xs px-3.5 py-2 border border-[#B8DBFA] rounded-lg focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="px-3.5 py-1.5 text-xs text-[#64788B] hover:text-[#253B53]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold transition-colors"
            >
              Guardar Responsável
            </button>
          </div>
        </form>
      )}

      {/* Grelha de Responsáveis */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {signers.map((s) => {
          const pendingInvoices = invoices.filter(
            (inv) => inv.assignedTo === s.name && inv.status === 'EM_ASSINATURA'
          );
          const returnedInvoices = invoices.filter(
            (inv) => inv.assignedTo === s.name && inv.status === 'DEVOLVIDA'
          );
          const totalAssigned = invoices.filter((inv) => inv.assignedTo === s.name);
          const pendingAmount = pendingInvoices.reduce((acc, i) => acc + (i.amount || 0), 0);

          const isEditing = editingSignerId === s.id;

          return (
            <div
              key={s.id}
              className={`bg-white rounded-xl border p-5 shadow-xs transition-all flex flex-col justify-between ${
                s.active ? 'border-[#B8DBFA]' : 'border-[#DCEEFF] bg-[#F3F9FF]/60 opacity-80'
              }`}
            >
              <div>
                {/* Linha Superior */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  {isEditing ? (
                    <div className="space-y-2 w-full">
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full text-xs px-2 py-1 border border-[#B8DBFA] rounded font-semibold text-[#253B53]"
                      />
                      <input
                        type="text"
                        value={editDepartment}
                        onChange={(e) => setEditDepartment(e.target.value)}
                        placeholder="Departamento"
                        className="w-full text-xs px-2 py-1 border border-[#B8DBFA] rounded text-[#253B53]"
                      />
                      <div className="flex gap-1 justify-end pt-1">
                        <button
                          type="button"
                          onClick={() => setEditingSignerId(null)}
                          className="p-1 hover:bg-[#DCEEFF] rounded text-[#64788B]"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(s)}
                          className="p-1 bg-[#287DBB] text-white rounded hover:bg-[#1E679B]"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h3 className="text-sm font-bold text-[#253B53]">{s.name}</h3>
                      <p className="text-xs text-[#64788B]">{s.department || 'Departamento Geral'}</p>
                    </div>
                  )}

                  {!isEditing && (
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        s.active
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-[#DCEEFF] text-[#64788B] border-[#B8DBFA]'
                      }`}
                    >
                      {s.active ? 'Ativo' : 'Desativado'}
                    </span>
                  )}
                </div>

                {/* Métricas de Circulação */}
                <div className="mt-4 grid grid-cols-2 gap-2 bg-[#F3F9FF] p-3 rounded-lg border border-[#B8DBFA] text-xs">
                  <div>
                    <span className="text-[11px] text-[#64788B] block">Por Devolver</span>
                    <strong
                      className={`text-base font-mono font-bold ${
                        pendingInvoices.length > 0 ? 'text-amber-800' : 'text-[#253B53]'
                      }`}
                    >
                      {pendingInvoices.length}
                    </strong>
                    {pendingAmount > 0 && (
                      <span className="block text-[10px] font-mono font-bold text-[#287DBB] truncate" title={formatEuro(pendingAmount)}>
                        {formatEuro(pendingAmount)}
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-[11px] text-[#64788B] block">Total Histórico</span>
                    <strong className="text-base font-mono font-bold text-[#253B53]">
                      {totalAssigned.length}
                    </strong>
                    <span className="block text-[10px] text-emerald-700 font-semibold">
                      {returnedInvoices.length} devolvida{returnedInvoices.length === 1 ? '' : 's'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Ações */}
              <div className="mt-4 pt-3 border-t border-[#DCEEFF] flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => onFilterSignerInvoices(s.name)}
                  className="text-[#287DBB] hover:text-[#1E679B] font-bold flex items-center gap-1"
                >
                  <span>Ver faturas ({totalAssigned.length})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center gap-1">
                  {!isEditing && (
                    <button
                      type="button"
                      onClick={() => handleStartEdit(s)}
                      className="p-1.5 text-[#64788B] hover:text-[#253B53] hover:bg-[#DCEEFF] rounded"
                      title="Editar nome ou departamento"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleToggleActive(s)}
                    className="p-1.5 text-[#64788B] hover:text-[#253B53] hover:bg-[#DCEEFF] rounded"
                    title={s.active ? 'Desativar responsável (mantém histórico)' : 'Reativar responsável'}
                  >
                    {s.active ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="p-4 bg-white rounded-xl border border-[#B8DBFA] text-xs text-[#64788B] space-y-1">
        <div className="font-bold text-[#253B53] flex items-center gap-1.5">
          <ShieldAlert className="w-4 h-4 text-[#287DBB]" />
          <span>Regra de Preservação de Histórico</span>
        </div>
        <p>
          A desativação de um responsável não remove nem adultera o histórico de faturas e movimentos anteriores. Os responsáveis não necessitam de credenciais nem acedem à aplicação, sendo a gestão mantida em exclusividade pela contabilidade.
        </p>
      </div>

    </div>
  );
};
