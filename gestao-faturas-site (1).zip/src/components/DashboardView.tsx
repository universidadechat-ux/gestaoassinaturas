import React from 'react';
import { AppSettings, InvoiceRecord, Signer } from '../types';
import { formatEuro, formatPtDate } from '../services/extractor';
import { calculateDaysElapsed, getDelayAlertLevel } from '../services/businessRules';
import { exportInvoicesToExcel } from '../services/excel';
import {
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Coins,
  Send,
  PlusCircle,
  ArrowRight,
  ArrowDownLeft,
  Calendar,
  User,
  ExternalLink,
  Download,
} from 'lucide-react';

interface DashboardViewProps {
  invoices: InvoiceRecord[];
  signers: Signer[];
  settings: AppSettings;
  onNavigateTab: (tab: 'dashboard' | 'new-invoice' | 'invoices' | 'signers' | 'history' | 'settings') => void;
  onSelectInvoice: (invoice: InvoiceRecord) => void;
  onRequestReturn: (invoice: InvoiceRecord) => void;
  onRequestDelivery: (invoice: InvoiceRecord) => void;
  onFilterDelayInvoices: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  invoices,
  signers,
  settings,
  onNavigateTab,
  onSelectInvoice,
  onRequestReturn,
  onRequestDelivery,
  onFilterDelayInvoices,
}) => {
  // 1. Cálculos de Indicadores
  const totalInvoices = invoices.length;
  const porEntregar = invoices.filter((inv) => inv.status === 'POR_ENTREGAR');
  const emAssinatura = invoices.filter((inv) => inv.status === 'EM_ASSINATURA');
  const devolvidas = invoices.filter((inv) => inv.status === 'DEVOLVIDA');

  const faturasEmAtraso = emAssinatura.filter((inv) => {
    const info = getDelayAlertLevel(inv, settings);
    return info.level !== 'normal';
  });

  const totalValorEmAssinatura = emAssinatura.reduce((acc, inv) => acc + (inv.amount || 0), 0);

  // 2. Faturas que necessitam de atenção
  const attentionInvoices = [...emAssinatura].sort((a, b) => {
    const daysA = calculateDaysElapsed(a.deliveryDate);
    const daysB = calculateDaysElapsed(b.deliveryDate);
    return daysB - daysA;
  });

  // 3. Últimos movimentos
  const allEvents = invoices
    .flatMap((inv) =>
      inv.history.map((h) => ({
        ...h,
        invoiceSupplier: inv.supplier,
        invoiceDocNum: inv.documentNumber,
        invoiceId: inv.id,
        invoiceRecord: inv,
      }))
    )
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 8);

  const handleExportPending = () => {
    const pendentes = invoices.filter((i) => i.status !== 'DEVOLVIDA');
    exportInvoicesToExcel(pendentes, 'Faturas_Pendentes_Assinatura');
  };

  return (
    <div className="space-y-6">
      
      {/* Faixa Superior de Boas-vindas e Ações em Azul Suave */}
      <div className="bg-white rounded-xl border border-[#B8DBFA] p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#253B53] tracking-tight">
            Painel de Controlo · Circulação de Faturas
          </h1>
          <p className="text-xs text-[#64788B] mt-0.5">
            Monitorização da entrega física e recolha de assinaturas dos responsáveis
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportPending}
            className="px-3.5 py-2 text-xs font-semibold text-[#253B53] bg-[#DCEEFF] hover:bg-[#B8DBFA] rounded-lg transition-colors flex items-center gap-1.5 border border-[#B8DBFA]"
          >
            <Download className="w-3.5 h-3.5 text-[#287DBB]" />
            <span>Exportar Pendentes (Excel)</span>
          </button>

          <button
            onClick={() => onNavigateTab('new-invoice')}
            className="px-4 py-2 text-xs font-bold text-white bg-[#287DBB] hover:bg-[#1E679B] rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4 text-white" />
            <span>Registar Nova Fatura</span>
          </button>
        </div>
      </div>

      {/* Cartões de Indicadores (6 KPIs em fundo claro e azul) */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3.5">
        
        {/* KPI 1: Total Faturas */}
        <div
          onClick={() => onNavigateTab('invoices')}
          className="bg-white p-4 rounded-xl border border-[#B8DBFA] shadow-xs hover:border-[#69B5ED] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64788B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Registadas</span>
            <FileText className="w-4 h-4 text-[#287DBB]" />
          </div>
          <div className="text-2xl font-bold text-[#253B53] font-mono-numbers">
            {totalInvoices}
          </div>
          <div className="text-[11px] text-[#64788B] mt-1">Todas as faturas</div>
        </div>

        {/* KPI 2: Por Entregar */}
        <div
          onClick={() => onNavigateTab('invoices')}
          className="bg-white p-4 rounded-xl border border-[#B8DBFA] shadow-xs hover:border-[#69B5ED] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64788B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Por Entregar</span>
            <Send className="w-4 h-4 text-[#69B5ED]" />
          </div>
          <div className="text-2xl font-bold text-[#253B53] font-mono-numbers">
            {porEntregar.length}
          </div>
          <div className="text-[11px] text-[#64788B] mt-1">Aguardam entrega</div>
        </div>

        {/* KPI 3: Em Assinatura */}
        <div
          onClick={() => onNavigateTab('invoices')}
          className="bg-[#FFFBEB] p-4 rounded-xl border border-amber-200 shadow-xs hover:border-amber-300 cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-amber-800 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Em Assinatura</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-900 font-mono-numbers">
            {emAssinatura.length}
          </div>
          <div className="text-[11px] text-amber-700 mt-1">Com responsáveis</div>
        </div>

        {/* KPI 4: Devolvidas */}
        <div
          onClick={() => onNavigateTab('invoices')}
          className="bg-[#F0FDF4] p-4 rounded-xl border border-emerald-200 shadow-xs hover:border-emerald-300 cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-emerald-800 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Devolvidas</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-900 font-mono-numbers">
            {devolvidas.length}
          </div>
          <div className="text-[11px] text-emerald-700 mt-1">Assinadas e arquivadas</div>
        </div>

        {/* KPI 5: Devolução em Atraso */}
        <div
          onClick={onFilterDelayInvoices}
          className={`p-4 rounded-xl border shadow-xs cursor-pointer transition-all flex flex-col justify-between ${
            faturasEmAtraso.length > 0
              ? 'bg-[#FEF2F2] border-rose-300 hover:border-rose-400'
              : 'bg-white border-[#B8DBFA] hover:border-[#69B5ED]'
          }`}
        >
          <div className="flex items-center justify-between text-rose-800 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Com Atraso</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-rose-700 font-mono-numbers">
            {faturasEmAtraso.length}
          </div>
          <div className="text-[11px] text-rose-600 mt-1 font-medium">
            {faturasEmAtraso.length > 0 ? 'Ver lista em atraso' : 'Sem atrasos'}
          </div>
        </div>

        {/* KPI 6: Valor em Circulação (Substituído de preto escuro para azul suave luminoso) */}
        <div className="bg-[#DCEEFF] p-4 rounded-xl border border-[#B8DBFA] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#287DBB] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Valor em Assinatura</span>
            <Coins className="w-4 h-4 text-[#287DBB]" />
          </div>
          <div className="text-lg font-bold text-[#253B53] font-mono-numbers truncate" title={formatEuro(totalValorEmAssinatura)}>
            {formatEuro(totalValorEmAssinatura)}
          </div>
          <div className="text-[11px] text-[#64788B] mt-1">Total a aguardar assinatura</div>
        </div>

      </div>

      {/* Secção Dupla: Faturas que necessitam de atenção + Últimos movimentos */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Lado Esquerdo: Faturas que necessitam de atenção (8 colunas) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-[#B8DBFA] shadow-xs overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[#B8DBFA] bg-[#F3F9FF] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-[#253B53]">
                Faturas que necessitam de atenção (Mais tempo em assinatura)
              </h2>
            </div>
            <button
              onClick={() => onNavigateTab('invoices')}
              className="text-xs text-[#287DBB] hover:text-[#1E679B] font-semibold flex items-center gap-1"
            >
              <span>Ver todas na tabela</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-[#EBF4FC]">
            {attentionInvoices.length === 0 ? (
              <div className="p-8 text-center text-[#64788B] text-xs">
                Não existem faturas pendentes de assinatura no momento.
              </div>
            ) : (
              attentionInvoices.slice(0, 5).map((inv) => {
                const alert = getDelayAlertLevel(inv, settings);
                return (
                  <div
                    key={inv.id}
                    className="p-4 hover:bg-[#F3F9FF] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#253B53] text-sm">
                          {inv.documentNumber}
                        </span>
                        <span className="text-[#64788B]">·</span>
                        <span className="font-semibold text-[#253B53]">{inv.supplier}</span>
                        {inv.isDemo && (
                          <span className="px-1.5 py-0.2 text-[10px] bg-[#DCEEFF] text-[#287DBB] rounded border border-[#B8DBFA]">
                            Demo
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-[#64788B] text-[11px]">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3 text-[#69B5ED]" />
                          <span>Entregue a: <strong className="text-[#253B53]">{inv.assignedTo}</strong></span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-[#69B5ED]" />
                          <span>Em: <strong className="font-mono text-[#253B53]">{formatPtDate(inv.deliveryDate)}</strong></span>
                        </span>
                        <span className="font-mono font-bold text-[#287DBB]">
                          {formatEuro(inv.amount)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Badge de Alerta Visual */}
                      <span
                        className={`px-2.5 py-1 text-[11px] font-semibold rounded-md border ${
                          alert.level === 'critical'
                            ? 'bg-rose-50 text-rose-700 border-rose-300'
                            : alert.level === 'warning'
                            ? 'bg-amber-50 text-amber-800 border-amber-300'
                            : 'bg-[#DCEEFF] text-[#287DBB] border-[#B8DBFA]'
                        }`}
                      >
                        {alert.label}
                      </span>

                      <button
                        type="button"
                        onClick={() => onRequestReturn(inv)}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-semibold flex items-center gap-1 transition-colors"
                        title="Registar devolução da fatura"
                      >
                        <ArrowDownLeft className="w-3.5 h-3.5" />
                        <span>Devolução</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onSelectInvoice(inv)}
                        className="p-1 text-[#64788B] hover:text-[#253B53] hover:bg-[#DCEEFF] rounded"
                        title="Consultar fatura"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Lado Direito: Últimos Movimentos (4 colunas) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-[#B8DBFA] shadow-xs overflow-hidden flex flex-col">
          <div className="px-5 py-3.5 border-b border-[#B8DBFA] bg-[#F3F9FF] flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#253B53] flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#287DBB]" />
              <span>Últimos Movimentos</span>
            </h2>
            <button
              onClick={() => onNavigateTab('history')}
              className="text-xs text-[#287DBB] hover:text-[#1E679B] font-semibold"
            >
              Ver tudo
            </button>
          </div>

          <div className="divide-y divide-[#EBF4FC] flex-1 overflow-y-auto max-h-[380px] p-2">
            {allEvents.length === 0 ? (
              <div className="p-6 text-center text-[#64788B] text-xs">
                Ainda não foram efetuados movimentos no sistema.
              </div>
            ) : (
              allEvents.map((evt, idx) => (
                <div
                  key={`${evt.id}-${idx}`}
                  onClick={() => onSelectInvoice(evt.invoiceRecord)}
                  className="p-2.5 hover:bg-[#F3F9FF] rounded-lg cursor-pointer transition-colors text-xs space-y-1"
                >
                  <div className="flex items-center justify-between text-[11px] text-[#64788B]">
                    <span className="font-mono font-semibold text-[#253B53] truncate max-w-[160px]">
                      {evt.invoiceDocNum}
                    </span>
                    <span className="font-mono text-[10px]">
                      {new Date(evt.timestamp).toLocaleDateString('pt-PT')}
                    </span>
                  </div>
                  <p className="text-[#253B53] text-xs line-clamp-1">{evt.description}</p>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
