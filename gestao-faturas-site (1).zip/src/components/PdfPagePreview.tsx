import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';

interface PdfPagePreviewProps {
  file: File;
  zoom: number;
  rotation: number;
}

/**
 * Pré-visualização temporária em canvas, sem iframe, upload ou persistência.
 * Funciona também quando a política de segurança bloqueia PDFs incorporados.
 */
export const PdfPagePreview: React.FC<PdfPagePreviewProps> = ({ file, zoom, rotation }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    let pdfLoading: ReturnType<typeof pdfjsLib.getDocument> | undefined;

    const render = async () => {
      setLoading(true);
      setError('');
      try {
        pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('./pdf.worker.mjs', document.baseURI).href;
        const bytes = await file.arrayBuffer();
        if (cancelled) return;
        pdfLoading = pdfjsLib.getDocument({ data: bytes });
        const pdf = await pdfLoading.promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 1.5 });
        if (cancelled || !canvasRef.current) return;
        const canvas = canvasRef.current;
        canvas.width = Math.ceil(viewport.width);
        canvas.height = Math.ceil(viewport.height);
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Canvas indisponível');
        await page.render({ canvas, canvasContext: ctx, viewport }).promise;
        if (!cancelled) setLoading(false);
      } catch {
        if (!cancelled) {
          setError('Não foi possível pré-visualizar o PDF. Os campos podem ser preenchidos manualmente.');
          setLoading(false);
        }
      }
    };

    void render();
    return () => {
      cancelled = true;
      void pdfLoading?.destroy();
    };
  }, [file]);

  return (
    <div className="w-full flex flex-col items-center gap-3">
      {loading && <span className="text-xs text-[#64788B]">A preparar pré-visualização local...</span>}
      {error && <p className="text-xs text-amber-700 text-center">{error}</p>}
      <div
        style={{ transform: 'scale(' + zoom + ') rotate(' + rotation + 'deg)' }}
        className="origin-center transition-transform duration-150"
      >
        <canvas
          ref={canvasRef}
          className="max-w-full h-auto rounded-lg border border-[#B8DBFA] bg-white shadow-xs"
          aria-label="Primeira página do PDF"
        />
      </div>
    </div>
  );
};
