import React, { useState } from 'react';
import { AppSettings, InvoiceRecord, Signer } from '../types';
import { formatEuro, formatPtDate } from '../services/extractor';
import { getDelayAlertLevel } from '../services/businessRules';
import { DocumentViewer } from './DocumentViewer';
import {
  X,
  FileText,
  Copy,
  Check,
  Calendar,
  ArrowDownLeft,
  Send,
  Edit3,
  AlertTriangle,
} from 'lucide-react';

interface InvoiceDetailModalProps {
  isOpen: boolean;
  invoice: InvoiceRecord | null;
  settings: AppSettings;
  signers: Signer[];
  onClose: () => void;
  onRequestReturn: (invoice: InvoiceRecord) => void;
  onRequestDelivery: (invoice: InvoiceRecord) => void;
  onUpdateInvoice: (updated: InvoiceRecord) => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  isOpen,
  invoice,
  settings,
  onClose,
  onRequestReturn,
  onRequestDelivery,
  onUpdateInvoice,
}) => {
  const [activeTab, setActiveTab] = useState<'document' | 'history' | 'ocr'>('document');
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [notesValue, setNotesValue] = useState(invoice?.notes || '');
  const [copiedText, setCopiedText] = useState(false);
  if (!isOpen || !invoice) return null;
  const delayInfo = getDelayAlertLevel(invoice, settings);

  const handleSaveNotes = () => {
    const updated: InvoiceRecord = {
      ...invoice,
      notes: notesValue,
      updatedAt: new Date().toISOString(),
      history: [
        ...invoice.history,
        {
          id: `evt-note-${Date.now()}`,
          timestamp: new Date().toISOString(),
          effectiveDate: new Date().toISOString().slice(0, 10),
          type: 'NOTA',
          description: `Observações atualizadas: "${notesValue}"`,
          author: 'Departamento de Contabilidade',
        },
      ],
    };
    onUpdateInvoice(updated);
    setIsEditingNotes(false);
  };

  const handleCopyOcr = async () => {
    if (!invoice.ocrRawText) return;
    try {
      await navigator.clipboard.writeText(invoice.ocrRawText);
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2000);
    } catch {
      // fallback
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#253B53]/40 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full border border-[#B8DBFA] overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in duration-150">
        
        {/* Cabeçalho em Azul Principal */}
        <div className="bg-[#287DBB] px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white font-mono">
                  {invoice.documentNumber}
                </h3>
                {invoice.isManual && (
                <span className="text-xs bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA] px-2 py-0.5 rounded font-semibold badge-manual-detail">
                  Registo manual
                </span>
              )}
              {invoice.isDemo && (
                  <span className="px-2 py-0.5 text-[10px] bg-white/20 text-white rounded border border-white/30 font-semibold">
                    Demonstração
                  </span>
                )}
                {invoice.status === 'EM_ASSINATURA' && (
                  <span
                    className={`px-2 py-0.5 text-[11px] font-bold rounded-md border ${
                      delayInfo.level === 'critical'
                        ? 'bg-rose-500 text-white border-rose-600'
                        : delayInfo.level === 'warning'
                        ? 'bg-amber-400 text-amber-950 border-amber-500'
                        : 'bg-[#DCEEFF] text-[#287DBB] border-[#B8DBFA]'
                    }`}
                  >
                    Em Assinatura ({delayInfo.days} {delayInfo.days === 1 ? 'dia' : 'dias'})
                  </span>
                )}
                {invoice.status === 'POR_ENTREGAR' && (
                  <span className="px-2 py-0.5 text-[11px] font-semibold bg-white/20 text-white rounded border border-white/30">
                    Por Entregar
                  </span>
                )}
                {invoice.status === 'DEVOLVIDA' && (
                  <span className="px-2 py-0.5 text-[11px] font-semibold bg-emerald-500 text-white rounded border border-emerald-400">
                    Devolvida
                  </span>
                )}
              </div>
              <p className="text-xs text-[#DCEEFF] mt-0.5 flex items-center gap-2">
                <span>{invoice.supplier}</span>
                <span>·</span>
                <span className="font-mono font-bold text-white">{formatEuro(invoice.amount)}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {invoice.status === 'EM_ASSINATURA' && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onRequestReturn(invoice);
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <ArrowDownLeft className="w-4 h-4" />
                <span>Registar Devolução</span>
              </button>
            )}
            {invoice.status === 'POR_ENTREGAR' && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onRequestDelivery(invoice);
                }}
                className="bg-white hover:bg-[#DCEEFF] text-[#287DBB] px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Send className="w-4 h-4" />
                <span>Entregar para Assinatura</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white p-1 ml-2 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Barra de Navegação Interna do Modal em Azul Claro */}
        <div className="bg-[#DCEEFF] border-b border-[#B8DBFA] px-6 py-2 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4 text-xs font-medium">
            <button
              onClick={() => setActiveTab('document')}
              className={`pb-1 border-b-2 transition-colors font-bold ${
                activeTab === 'document'
                  ? 'border-[#287DBB] text-[#287DBB]'
                  : 'border-transparent text-[#64788B] hover:text-[#253B53]'
              }`}
            >
              Dados / Documento
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`pb-1 border-b-2 transition-colors flex items-center gap-1 font-bold ${
                activeTab === 'history'
                  ? 'border-[#287DBB] text-[#287DBB]'
                  : 'border-transparent text-[#64788B] hover:text-[#253B53]'
              }`}
            >
              <span>Histórico de Circulação</span>
              <span className="px-1.5 py-0.2 bg-white text-[#287DBB] rounded-full text-[10px] font-bold border border-[#B8DBFA]">
                {invoice.history?.length || 0}
              </span>
            </button>
            {invoice.ocrRawText && (
              <button
                onClick={() => setActiveTab('ocr')}
                className="pb-1 border-b-2 transition-colors font-bold text-[#64788B] hover:text-[#253B53]"
              >
                Texto OCR histórico
              </button>
            )}
          </div>

          <div className="text-[11px] text-[#64788B] font-mono">
            ID: {invoice.id.slice(0, 12)}
          </div>
        </div>

        {/* Conteúdo Dinâmico */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1 bg-white">
          
          {/* Faixa Resumo de Circulação Física */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#F3F9FF] p-3.5 rounded-lg border border-[#B8DBFA] text-xs">
            <div>
              <span className="text-[#64788B] block text-[11px]">Data de Emissão</span>
              <span className="font-mono font-bold text-[#253B53]">{formatPtDate(invoice.documentDate)}</span>
            </div>
            <div>
              <span className="text-[#64788B] block text-[11px]">Responsável</span>
              <span className="font-bold text-[#253B53]">{invoice.assignedTo || 'Não atribuído'}</span>
            </div>
            <div>
              <span className="text-[#64788B] block text-[11px]">Data de Entrega</span>
              <span className="font-mono font-bold text-[#253B53]">{formatPtDate(invoice.deliveryDate)}</span>
            </div>
            <div>
              <span className="text-[#64788B] block text-[11px]">Data de Devolução</span>
              <span className="font-mono font-bold text-[#253B53]">{formatPtDate(invoice.returnDate)}</span>
            </div>
          </div>

          {/* Alerta de Atraso */}
          {invoice.status === 'EM_ASSINATURA' && delayInfo.level !== 'normal' && (
            <div
              className={`p-3 rounded-lg border text-xs flex items-center gap-2 ${
                delayInfo.level === 'critical'
                  ? 'bg-rose-50 border-rose-200 text-rose-800'
                  : 'bg-amber-50 border-amber-200 text-amber-800'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
              <span className="font-bold">{delayInfo.label}</span>
              <span className="text-[11px] opacity-80 ml-auto">
                Limiar: {settings.warningDaysThreshold}d (aviso) · {settings.criticalDaysThreshold}d (crítico)
              </span>
            </div>
          )}

          {/* Separador 1: Documento Original */}
          {activeTab === 'document' && (
            <div className="space-y-4">
              {invoice.fileId ? (
                <DocumentViewer
                  fileId={invoice.fileId}
                  fileName={invoice.fileName}
                  fileType={invoice.fileType}
                />
              ) : (
                <div className="bg-[#F3F9FF] border-2 border-dashed border-[#B8DBFA] rounded-2xl p-8 text-center space-y-4">
                  <div className="w-14 h-14 bg-[#DCEEFF] text-[#287DBB] rounded-2xl flex items-center justify-center mx-auto shadow-xs">
                    <FileText className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-[#253B53]">
                      Apenas informação administrativa guardada
                    </h3>
                    <p className="text-xs text-[#64788B] max-w-md mx-auto mt-1.5 leading-relaxed">
                      Por confidencialidade, o PDF ou imagem é utilizado apenas durante a leitura e não fica guardado na aplicação. O histórico de entrega e devolução mantém-se disponível.
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Separador 2: Histórico e Rastreabilidade */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-[#253B53] uppercase tracking-wider">
                Linha Temporal de Circulação Administrativa
              </h4>
              <div className="relative pl-6 space-y-4 border-l-2 border-[#B8DBFA] ml-2">
                {invoice.history && invoice.history.length > 0 ? (
                  invoice.history.map((evt) => (
                    <div key={evt.id} className="relative group">
                      <div className="absolute -left-[31px] top-1 w-3.5 h-3.5 rounded-full bg-white border-2 border-[#287DBB]" />
                      
                      <div className="bg-[#F3F9FF] p-3 rounded-lg border border-[#B8DBFA] text-xs">
                        <div className="flex items-center justify-between text-[11px] text-[#64788B] mb-1">
                          <span className="font-bold text-[#253B53]">{evt.author}</span>
                          <span className="font-mono">
                            {new Date(evt.timestamp).toLocaleString('pt-PT')}
                          </span>
                        </div>
                        <p className="text-[#253B53] font-medium">{evt.description}</p>
                        {evt.effectiveDate && (
                          <div className="mt-1 text-[11px] text-[#64788B] flex items-center gap-1 font-mono">
                            <Calendar className="w-3 h-3 text-[#69B5ED]" />
                            <span>Data do movimento: {formatPtDate(evt.effectiveDate)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-[#64788B]">Sem eventos adicionais registados.</p>
                )}
              </div>
            </div>
          )}

          {/* Separador 3: Texto Bruto OCR */}
          {activeTab === 'ocr' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#64788B]">
                  Conteúdo extraído localmente por análise digital / OCR:
                </span>
                <button
                  type="button"
                  onClick={handleCopyOcr}
                  disabled={!invoice.ocrRawText}
                  className="px-2.5 py-1 bg-[#DCEEFF] hover:bg-[#B8DBFA] disabled:opacity-40 text-[#287DBB] rounded text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  {copiedText ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#287DBB]" />
                      <span>Copiar texto</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3 bg-[#F3F9FF] text-[#253B53] text-xs font-mono rounded-lg overflow-x-auto max-h-80 whitespace-pre-wrap leading-relaxed border border-[#B8DBFA]">
                {invoice.ocrRawText || 'Nenhum texto bruto foi armazenado para este documento.'}
              </pre>
            </div>
          )}

          {/* Campo de Observações Administrativas */}
          <div className="p-4 bg-[#F3F9FF] rounded-lg border border-[#B8DBFA] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#253B53]">Observações Contabilísticas</span>
              {!isEditingNotes && (
                <button
                  type="button"
                  onClick={() => {
                    setNotesValue(invoice.notes || '');
                    setIsEditingNotes(true);
                  }}
                  className="text-xs text-[#287DBB] hover:underline font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>Editar observações</span>
                </button>
              )}
            </div>

            {isEditingNotes ? (
              <div className="space-y-2">
                <textarea
                  rows={2}
                  value={notesValue}
                  onChange={(e) => setNotesValue(e.target.value)}
                  placeholder="Ex: Aguarda assinatura, responsável ausente, etc."
                  className="w-full text-xs p-2 border border-[#B8DBFA] rounded-md focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingNotes(false)}
                    className="px-2.5 py-1 text-xs text-[#64788B] hover:text-[#253B53]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveNotes}
                    className="px-3 py-1 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded text-xs font-bold"
                  >
                    Guardar Observações
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#253B53] italic">
                {invoice.notes || 'Sem observações registadas para este documento.'}
              </p>
            )}
          </div>

        </div>

        {/* Rodapé */}
        <div className="bg-[#F3F9FF] px-6 py-3 border-t border-[#B8DBFA] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Fechar
          </button>
        </div>

      </div>
    </div>
  );
};
