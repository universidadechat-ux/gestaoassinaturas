import React, { useState } from 'react';
import { InvoiceRecord } from '../types';
import { formatPtDate } from '../services/extractor';
import { validateReturnDate } from '../services/businessRules';
import { CheckCircle2, Calendar, AlertCircle, X, ArrowDownLeft } from 'lucide-react';

interface ReturnModalProps {
  isOpen: boolean;
  invoice: InvoiceRecord | null;
  onConfirmReturn: (invoiceId: string, returnDate: string, notes?: string) => void;
  onCancel: () => void;
}

export const ReturnModal: React.FC<ReturnModalProps> = ({
  isOpen,
  invoice,
  onConfirmReturn,
  onCancel,
}) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const [returnDate, setReturnDate] = useState<string>(todayStr);
  const [notes, setNotes] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen || !invoice) return null;

  const handleConfirm = () => {
    const val = validateReturnDate(invoice.deliveryDate, returnDate);
    if (!val.valid) {
      setErrorMsg(val.error || 'Data de devolução inválida.');
      return;
    }
    setErrorMsg('');
    onConfirmReturn(invoice.id, returnDate, notes.trim() || undefined);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#253B53]/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-[#B8DBFA] overflow-hidden animate-in fade-in duration-150">
        
        {/* Cabeçalho */}
        <div className="bg-emerald-600 px-6 py-4 text-white flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-white/20 rounded-lg">
              <ArrowDownLeft className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Registar devolução de fatura
              </h3>
              <p className="text-xs text-emerald-100">
                Receção física do documento assinado na contabilidade
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-white/80 hover:text-white transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dados de Identificação da Fatura */}
        <div className="p-6 space-y-4">
          <div className="bg-[#F3F9FF] p-3.5 rounded-lg border border-[#B8DBFA] text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-[#64788B]">Fornecedor:</span>
              <span className="font-bold text-[#253B53] text-right">{invoice.supplier}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64788B]">Nº Documento:</span>
              <span className="font-mono font-bold text-[#287DBB]">{invoice.documentNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64788B]">Responsável pela assinatura:</span>
              <span className="font-semibold text-[#253B53]">{invoice.assignedTo || '—'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64788B]">Data de entrega física:</span>
              <span className="font-mono text-[#253B53] font-bold">{formatPtDate(invoice.deliveryDate)}</span>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Campo Data de Devolução */}
          <div>
            <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5 mb-1.5">
              <Calendar className="w-4 h-4 text-emerald-600" />
              <span>Data de devolução física à contabilidade</span>
            </label>
            <input
              type="date"
              value={returnDate}
              onChange={(e) => {
                setReturnDate(e.target.value);
                setErrorMsg('');
              }}
              className="w-full text-sm px-3 py-2 border border-[#B8DBFA] rounded-lg bg-white focus:ring-2 focus:ring-emerald-500 font-mono text-[#253B53]"
            />
            <p className="text-[11px] text-[#64788B] mt-1">
              Data em que o papel assinado regressou ao departamento (preenchido com a data atual).
            </p>
          </div>

          {/* Observações Opcionais de Devolução */}
          <div>
            <label className="text-xs font-semibold text-[#253B53] mb-1 block">
              Observações de receção (opcional)
            </label>
            <input
              type="text"
              placeholder="Ex: Assinado com carimbo, devolvido em mão, etc."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs px-3 py-2 border border-[#B8DBFA] rounded-lg bg-white focus:ring-2 focus:ring-emerald-500 text-[#253B53]"
            />
          </div>
        </div>

        {/* Rodapé de Ações */}
        <div className="bg-[#F3F9FF] px-6 py-3.5 border-t border-[#B8DBFA] flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-3.5 py-2 text-xs text-[#64788B] hover:text-[#253B53] font-medium"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Confirmar devolução</span>
          </button>
        </div>

      </div>
    </div>
  );
};
