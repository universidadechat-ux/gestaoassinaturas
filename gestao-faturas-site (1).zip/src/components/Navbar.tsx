import React from 'react';
import {
  FileText,
  PlusCircle,
  TableProperties,
  Users,
  History,
  Settings,
  Building2,
  Monitor,
} from 'lucide-react';

export type NavTab = 'dashboard' | 'new-invoice' | 'invoices' | 'signers' | 'history' | 'settings';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  pendingCount: number;
  criticalDelayCount: number;
  onInstallClick?: () => void;
  isAppInstalled?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  pendingCount,
  criticalDelayCount,
  onInstallClick,
  isAppInstalled,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-[#B8DBFA] text-[#253B53] shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zona 1: Marca Corporativa e Departamento */}
          <div
            onClick={() => onSelectTab('dashboard')}
            className="flex items-center gap-3 cursor-pointer shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-[#287DBB] flex items-center justify-center text-white font-bold shadow-xs">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-base font-bold tracking-tight text-[#253B53] flex items-center gap-2 whitespace-nowrap">
                <span>Gestão de Faturas</span>
                <span className="text-[#69B5ED] font-normal">|</span>
                <span className="text-[#287DBB] font-semibold text-sm">Controlo de Assinaturas</span>
              </div>
              <div className="text-[11px] text-[#64788B] flex items-center gap-1.5 whitespace-nowrap">
                <Building2 className="w-3 h-3 text-[#69B5ED]" />
                <span>Departamento de Contabilidade</span>
              </div>
            </div>
          </div>

          {/* Zona 2: Navegação com Separadores em Azul Suave */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-1.5">
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                currentTab === 'dashboard'
                  ? 'bg-[#287DBB] text-white shadow-xs'
                  : 'text-[#253B53] hover:text-[#287DBB] hover:bg-[#DCEEFF]'
              }`}
            >
              Dashboard
            </button>

            <button
              onClick={() => onSelectTab('new-invoice')}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                currentTab === 'new-invoice'
                  ? 'bg-[#287DBB] text-white shadow-xs'
                  : 'text-[#253B53] hover:text-[#287DBB] hover:bg-[#DCEEFF]'
              }`}
            >
              <PlusCircle className={`w-3.5 h-3.5 ${currentTab === 'new-invoice' ? 'text-white' : 'text-[#287DBB]'}`} />
              <span>Nova Fatura</span>
            </button>

            <button
              onClick={() => onSelectTab('invoices')}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                currentTab === 'invoices'
                  ? 'bg-[#287DBB] text-white shadow-xs'
                  : 'text-[#253B53] hover:text-[#287DBB] hover:bg-[#DCEEFF]'
              }`}
            >
              <TableProperties className="w-3.5 h-3.5" />
              <span>Gestão de Faturas</span>
              {pendingCount > 0 && (
                <span
                  className={`ml-1 px-1.5 py-0.2 text-[10px] font-bold rounded-full ${
                    currentTab === 'invoices'
                      ? 'bg-white/20 text-white'
                      : 'bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA]'
                  }`}
                >
                  {pendingCount}
                </span>
              )}
              {criticalDelayCount > 0 && (
                <span
                  className={`px-1.5 py-0.2 text-[10px] font-bold rounded-full ${
                    currentTab === 'invoices'
                      ? 'bg-rose-500 text-white'
                      : 'bg-rose-100 text-rose-700 border border-rose-200'
                  }`}
                >
                  {criticalDelayCount} atraso{criticalDelayCount > 1 ? 's' : ''}
                </span>
              )}
            </button>

            <button
              onClick={() => onSelectTab('signers')}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                currentTab === 'signers'
                  ? 'bg-[#287DBB] text-white shadow-xs'
                  : 'text-[#253B53] hover:text-[#287DBB] hover:bg-[#DCEEFF]'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Responsáveis</span>
            </button>

            <button
              onClick={() => onSelectTab('history')}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                currentTab === 'history'
                  ? 'bg-[#287DBB] text-white shadow-xs'
                  : 'text-[#253B53] hover:text-[#287DBB] hover:bg-[#DCEEFF]'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Histórico</span>
            </button>

            <button
              onClick={() => onSelectTab('settings')}
              className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                currentTab === 'settings'
                  ? 'bg-[#287DBB] text-white shadow-xs'
                  : 'text-[#253B53] hover:text-[#287DBB] hover:bg-[#DCEEFF]'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Definições</span>
            </button>
          </nav>

          {/* Zona 3: Ação Primária Rápida */}
          <div className="flex items-center gap-2">
            {!isAppInstalled && onInstallClick && (
              <button
                onClick={onInstallClick}
                className="bg-white hover:bg-[#DCEEFF] text-[#287DBB] border border-[#B8DBFA] font-semibold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-xs whitespace-nowrap cursor-pointer"
                title="Instalar no PC como aplicação independente (Chrome/Edge)"
              >
                <Monitor className="w-3.5 h-3.5 text-[#287DBB]" />
                <span className="hidden sm:inline">Instalar no PC</span>
                <span className="sm:hidden">Instalar</span>
              </button>
            )}

            {isAppInstalled && (
              <div
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-semibold select-none"
                title="Aplicação a funcionar em janela independente"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                <span>Instalada no PC</span>
              </div>
            )}

            <button
              onClick={() => onSelectTab('new-invoice')}
              className="bg-[#287DBB] hover:bg-[#1E679B] text-white font-semibold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-xs whitespace-nowrap"
            >
              <PlusCircle className="w-4 h-4 text-[#DCEEFF]" />
              <span className="hidden sm:inline">Adicionar Fatura</span>
              <span className="sm:hidden">Adicionar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navegação Mobile em Azul Suave */}
      <div className="md:hidden border-t border-[#B8DBFA] bg-[#F3F9FF] overflow-x-auto px-4 py-2 flex items-center gap-1.5 text-xs">
        <button
          onClick={() => onSelectTab('dashboard')}
          className={`px-2.5 py-1.5 rounded-md whitespace-nowrap font-medium ${
            currentTab === 'dashboard' ? 'bg-[#287DBB] text-white' : 'text-[#64788B]'
          }`}
        >
          Dashboard
        </button>
        <button
          onClick={() => onSelectTab('new-invoice')}
          className={`px-2.5 py-1.5 rounded-md whitespace-nowrap font-medium ${
            currentTab === 'new-invoice' ? 'bg-[#287DBB] text-white' : 'text-[#64788B]'
          }`}
        >
          Nova Fatura
        </button>
        <button
          onClick={() => onSelectTab('invoices')}
          className={`px-2.5 py-1.5 rounded-md whitespace-nowrap font-medium ${
            currentTab === 'invoices' ? 'bg-[#287DBB] text-white' : 'text-[#64788B]'
          }`}
        >
          Gestão Faturas ({pendingCount})
        </button>
        <button
          onClick={() => onSelectTab('signers')}
          className={`px-2.5 py-1.5 rounded-md whitespace-nowrap font-medium ${
            currentTab === 'signers' ? 'bg-[#287DBB] text-white' : 'text-[#64788B]'
          }`}
        >
          Responsáveis
        </button>
        <button
          onClick={() => onSelectTab('history')}
          className={`px-2.5 py-1.5 rounded-md whitespace-nowrap font-medium ${
            currentTab === 'history' ? 'bg-[#287DBB] text-white' : 'text-[#64788B]'
          }`}
        >
          Histórico
        </button>
        <button
          onClick={() => onSelectTab('settings')}
          className={`px-2.5 py-1.5 rounded-md whitespace-nowrap font-medium ${
            currentTab === 'settings' ? 'bg-[#287DBB] text-white' : 'text-[#64788B]'
          }`}
        >
          Definições
        </button>
        {!isAppInstalled && onInstallClick && (
          <button
            onClick={onInstallClick}
            className="px-2.5 py-1.5 rounded-md whitespace-nowrap font-semibold text-[#287DBB] bg-white border border-[#B8DBFA] flex items-center gap-1"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Instalar no PC</span>
          </button>
        )}
      </div>
    </header>
  );
};
