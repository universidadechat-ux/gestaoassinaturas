import React, { useState } from 'react';
import { Signer, InvoiceRecord } from '../types';
import { formatEuro } from '../services/extractor';
import { UserCheck, Calendar, X, Plus, AlertCircle, Clock } from 'lucide-react';

interface DeliveryModalProps {
  isOpen: boolean;
  invoice: Partial<InvoiceRecord>;
  signers: Signer[];
  onConfirmDelivery: (signerName: string, deliveryDate: string) => void;
  onSaveWithoutDelivery: () => void;
  onCancel: () => void;
  onAddNewSigner: (name: string, department?: string) => Promise<Signer>;
}

export const DeliveryModal: React.FC<DeliveryModalProps> = ({
  isOpen,
  invoice,
  signers,
  onConfirmDelivery,
  onSaveWithoutDelivery,
  onCancel,
  onAddNewSigner,
}) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const [selectedSigner, setSelectedSigner] = useState<string>(invoice.assignedTo || '');
  const [deliveryDate, setDeliveryDate] = useState<string>(invoice.deliveryDate || todayStr);
  const [isAddingNewSigner, setIsAddingNewSigner] = useState(false);
  const [newSignerName, setNewSignerName] = useState('');
  const [newSignerDept, setNewSignerDept] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const activeSigners = signers.filter((s) => s.active);

  const handleConfirm = () => {
    if (!selectedSigner || selectedSigner.trim().length === 0) {
      setErrorMsg('Por favor selecione o responsável a quem foi ou será entregue a fatura.');
      return;
    }
    if (!deliveryDate || deliveryDate.trim().length === 0) {
      setErrorMsg('Por favor indique a data da entrega física do documento.');
      return;
    }
    setErrorMsg('');
    onConfirmDelivery(selectedSigner, deliveryDate);
  };

  const handleCreateSignerInline = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSignerName.trim()) return;
    try {
      const created = await onAddNewSigner(newSignerName.trim(), newSignerDept.trim() || undefined);
      setSelectedSigner(created.name);
      setIsAddingNewSigner(false);
      setNewSignerName('');
      setNewSignerDept('');
      setErrorMsg('');
    } catch {
      setErrorMsg('Não foi possível adicionar o responsável.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#253B53]/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-[#B8DBFA] overflow-hidden animate-in fade-in duration-150">
        
        {/* Cabeçalho em Azul Principal */}
        <div className="bg-[#287DBB] px-6 py-4 text-white flex items-start justify-between">
          <div>
            <h3 className="text-base font-bold leading-6 text-white">
              A quem será entregue esta fatura para assinatura?
            </h3>
            <p className="text-xs text-[#DCEEFF] mt-0.5">
              Controlo administrativo da entrega física do documento em papel
            </p>
          </div>
          <button
            onClick={onCancel}
            className="text-white/80 hover:text-white transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Resumo da Fatura em Validação */}
        <div className="bg-[#F3F9FF] px-6 py-3 border-b border-[#B8DBFA] text-xs text-[#253B53] flex items-center justify-between">
          <div>
            <span className="font-bold text-[#253B53]">{invoice.supplier || 'Fornecedor não indicado'}</span>
            <span className="mx-1.5 text-[#69B5ED]">·</span>
            <span className="font-mono text-[#64788B]">{invoice.documentNumber || 'S/N'}</span>
          </div>
          <div className="text-right">
            <span className="font-mono font-bold text-[#287DBB] text-sm">
              {formatEuro(invoice.amount)}
            </span>
          </div>
        </div>

        {/* Formulário de Entrega */}
        <div className="p-6 space-y-5">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Seleção do Responsável */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-[#287DBB]" />
                <span>Responsável pela assinatura</span>
              </label>
              {!isAddingNewSigner && (
                <button
                  type="button"
                  onClick={() => setIsAddingNewSigner(true)}
                  className="text-xs text-[#287DBB] hover:text-[#1E679B] font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Novo responsável</span>
                </button>
              )}
            </div>

            {isAddingNewSigner ? (
              <form onSubmit={handleCreateSignerInline} className="p-3 bg-[#F3F9FF] rounded-lg border border-[#B8DBFA] space-y-2">
                <div className="text-xs font-semibold text-[#253B53]">Adicionar novo responsável:</div>
                <input
                  type="text"
                  placeholder="Nome do responsável (ex: Pedro Ferreira)"
                  value={newSignerName}
                  onChange={(e) => setNewSignerName(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-[#B8DBFA] rounded-md focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                  autoFocus
                />
                <input
                  type="text"
                  placeholder="Departamento / Cargo (opcional)"
                  value={newSignerDept}
                  onChange={(e) => setNewSignerDept(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-[#B8DBFA] rounded-md focus:ring-2 focus:ring-[#287DBB] bg-white text-[#253B53]"
                />
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddingNewSigner(false)}
                    className="px-2.5 py-1 text-xs text-[#64788B] hover:text-[#253B53]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded text-xs font-bold"
                  >
                    Guardar e Selecionar
                  </button>
                </div>
              </form>
            ) : (
              <select
                value={selectedSigner}
                onChange={(e) => setSelectedSigner(e.target.value)}
                className="w-full text-sm px-3 py-2 border border-[#B8DBFA] rounded-lg bg-white focus:ring-2 focus:ring-[#287DBB] text-[#253B53] font-medium"
              >
                <option value="">-- Selecione o responsável --</option>
                {activeSigners.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name} {s.department ? `(${s.department})` : ''}
                  </option>
                ))}
              </select>
            )}
            <p className="text-[11px] text-[#64788B] mt-1">
              A aplicação considerará o documento na posse física deste responsável até ser registada a devolução.
            </p>
          </div>

          {/* Data de Entrega */}
          <div>
            <label className="text-xs font-bold text-[#253B53] flex items-center gap-1.5 mb-1.5">
              <Calendar className="w-4 h-4 text-[#287DBB]" />
              <span>Data de entrega física</span>
            </label>
            <input
              type="date"
              value={deliveryDate}
              onChange={(e) => setDeliveryDate(e.target.value)}
              className="w-full text-sm px-3 py-2 border border-[#B8DBFA] rounded-lg bg-white focus:ring-2 focus:ring-[#287DBB] font-mono text-[#253B53]"
            />
            <p className="text-[11px] text-[#64788B] mt-1">
              Data em que o papel foi efetivamente entregue ao responsável (preenchido por omissão com a data atual).
            </p>
          </div>

          <div className="p-3 bg-[#FEF3C7]/60 rounded-lg border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Nota:</span> Se o documento ainda não saiu do departamento de contabilidade, escolha <strong>"Guardar sem entregar"</strong> para manter o registo no estado <em>Por Entregar</em>.
            </div>
          </div>
        </div>

        {/* Rodapé com os dois botões principais */}
        <div className="bg-[#F3F9FF] px-6 py-4 border-t border-[#B8DBFA] flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onSaveWithoutDelivery}
            className="w-full sm:w-auto px-4 py-2 border border-[#B8DBFA] bg-white hover:bg-[#DCEEFF] text-[#253B53] rounded-lg text-xs font-semibold transition-colors text-center order-2 sm:order-1"
          >
            Guardar sem entregar
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto order-1 sm:order-2 justify-end">
            <button
              type="button"
              onClick={onCancel}
              className="px-3 py-2 text-xs text-[#64788B] hover:text-[#253B53]"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              className="px-4 py-2 bg-[#287DBB] hover:bg-[#1E679B] text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
            >
              Confirmar entrega
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
