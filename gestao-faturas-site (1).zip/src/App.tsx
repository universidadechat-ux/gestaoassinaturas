/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AppSettings, InvoiceRecord, Signer } from './types';
import { storage } from './services/storage';
import { seedInitialDemoData, getDelayAlertLevel } from './services/businessRules';
import { formatPtDate } from './services/extractor';
import { Navbar, NavTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { NewInvoiceView } from './components/NewInvoiceView';
import { InvoicesListView } from './components/InvoicesListView';
import { SignersView } from './components/SignersView';
import { HistoryView } from './components/HistoryView';
import { SettingsView } from './components/SettingsView';
import { InvoiceDetailModal } from './components/InvoiceDetailModal';
import { ReturnModal } from './components/ReturnModal';
import { DeliveryModal } from './components/DeliveryModal';
import { PWAInstallSuccessModal } from './components/PWAInstallSuccessModal';
import { PWAInstallGuideModal } from './components/PWAInstallGuideModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import { CheckCircle2, X } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
  const [signers, setSigners] = useState<Signer[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    warningDaysThreshold: 7,
    criticalDaysThreshold: 14,
    companyName: 'Empresa Modelo, Lda.',
    departmentName: 'Departamento de Contabilidade',
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Modais globais
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceRecord | null>(null);
  const [invoiceToReturn, setInvoiceToReturn] = useState<InvoiceRecord | null>(null);
  const [invoiceToDeliver, setInvoiceToDeliver] = useState<InvoiceRecord | null>(null);

  // Controlo de Instalação PWA no PC
  const {
    isInstalled: isAppInstalled,
    showInstalledSuccessModal,
    setShowInstalledSuccessModal,
    showInstallGuideModal,
    setShowInstallGuideModal,
    install: handlePwaInstall,
  } = usePWAInstall();

  // Filtro inicial para a lista (ex: ao clicar no KPI de atraso)
  const [initialFilterDelay, setInitialFilterDelay] = useState<boolean>(false);

  // Mensagens de confirmação temporárias (Toast)
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Carregar dados na inicialização
  const loadData = async () => {
    try {
      await seedInitialDemoData();
      const [allInvoices, allSigners, appSettings] = await Promise.all([
        storage.getInvoices(),
        storage.getSigners(),
        storage.getSettings(),
      ]);
      setInvoices(allInvoices);
      setSigners(allSigners);
      setSettings(appSettings);
    } catch (err) {
      console.error('Erro ao carregar dados do IndexedDB:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Handlers de Ações Contabilísticas
  const handleAddNewSigner = async (name: string, department?: string): Promise<Signer> => {
    const newSigner: Signer = {
      id: `sig-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name,
      department,
      active: true,
      createdAt: new Date().toISOString(),
    };
    await storage.saveSigner(newSigner);
    setSigners((prev) => [...prev, newSigner]);
    return newSigner;
  };

  const handleSaveSigner = async (signer: Signer) => {
    await storage.saveSigner(signer);
    const updated = await storage.getSigners();
    setSigners(updated);
  };

  const handleSaveSettings = async (newSettings: AppSettings) => {
    await storage.saveSettings(newSettings);
    setSettings(newSettings);
  };

  const handleInvoiceCreated = (newInv: InvoiceRecord) => {
    setInvoices((prev) => [newInv, ...prev]);
    if (newInv.status === 'EM_ASSINATURA' && newInv.assignedTo && newInv.deliveryDate) {
      showToast(
        `Fatura entregue a ${newInv.assignedTo} em ${formatPtDate(newInv.deliveryDate)}.`
      );
    } else {
      showToast(`Fatura ${newInv.documentNumber} registada como Por Entregar.`);
    }
    setCurrentTab('invoices');
  };

  const handleUpdateInvoice = async (updated: InvoiceRecord) => {
    await storage.saveInvoice(updated);
    setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
    if (selectedInvoice && selectedInvoice.id === updated.id) {
      setSelectedInvoice(updated);
    }
  };

  // Registo de Devolução
  const handleConfirmReturn = async (invoiceId: string, returnDate: string, notes?: string) => {
    const target = invoices.find((inv) => inv.id === invoiceId);
    if (!target) return;

    const nowIso = new Date().toISOString();
    const returnEvent = {
      id: `evt-ret-${Date.now()}`,
      timestamp: nowIso,
      effectiveDate: returnDate,
      type: 'DEVOLUCAO' as const,
      description: `Fatura devolvida e rececionada pela contabilidade em ${formatPtDate(returnDate)}.${
        notes ? ` Obs: ${notes}` : ''
      }`,
      author: 'Departamento de Contabilidade',
    };

    const updated: InvoiceRecord = {
      ...target,
      returnDate,
      status: 'DEVOLVIDA',
      notes: notes ? (target.notes ? `${target.notes} | ${notes}` : notes) : target.notes,
      updatedAt: nowIso,
      history: [...target.history, returnEvent],
    };

    await storage.saveInvoice(updated);
    setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
    setInvoiceToReturn(null);

    showToast(`Fatura devolvida em ${formatPtDate(returnDate)}.`);
  };

  // Registo de Entrega para fatura que estava "Por Entregar"
  const handleConfirmDeliveryFromList = async (signerName: string, delivDate: string) => {
    if (!invoiceToDeliver) return;

    const nowIso = new Date().toISOString();
    const deliveryEvent = {
      id: `evt-deliv-${Date.now()}`,
      timestamp: nowIso,
      effectiveDate: delivDate,
      type: 'ENTREGA' as const,
      description: `Fatura entregue fisicamente a ${signerName} em ${formatPtDate(delivDate)}.`,
      author: 'Departamento de Contabilidade',
    };

    const updated: InvoiceRecord = {
      ...invoiceToDeliver,
      assignedTo: signerName,
      deliveryDate: delivDate,
      status: 'EM_ASSINATURA',
      updatedAt: nowIso,
      history: [...invoiceToDeliver.history, deliveryEvent],
    };

    await storage.saveInvoice(updated);
    setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
    setInvoiceToDeliver(null);

    showToast(`Fatura entregue a ${signerName} em ${formatPtDate(delivDate)}.`);
  };

  // Eliminação de dados de demonstração
  const handleDeleteDemoData = async () => {
    const deletedCount = await storage.deleteDemoData();
    const remaining = await storage.getInvoices();
    setInvoices(remaining);
    showToast(`${deletedCount} faturas de demonstração eliminadas com sucesso.`, 'info');
  };

  // Contadores para o Navbar
  const pendingInvoicesCount = invoices.filter((inv) => inv.status === 'EM_ASSINATURA').length;
  const criticalDelayCount = invoices.filter((inv) => {
    if (inv.status !== 'EM_ASSINATURA') return false;
    const alert = getDelayAlertLevel(inv, settings);
    return alert.level === 'critical';
  }).length;
  const demoCount = invoices.filter((i) => i.isDemo === true).length;

  return (
    <div className="min-h-screen bg-[#F3F9FF] flex flex-col text-[#253B53] font-sans">
      
      {/* Barra de Navegação Corporativa Clara */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setInitialFilterDelay(false);
          setCurrentTab(tab);
        }}
        pendingCount={pendingInvoicesCount}
        criticalDelayCount={criticalDelayCount}
        onInstallClick={handlePwaInstall}
        isAppInstalled={isAppInstalled}
      />

      {/* Notificação Toast Flutuante em Azul Principal */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom duration-200">
          <div className="bg-[#287DBB] text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-3 border border-[#69B5ED] text-xs">
            <CheckCircle2 className="w-4 h-4 text-[#DCEEFF] shrink-0" />
            <span className="font-bold">{toastMessage.text}</span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-white/80 hover:text-white p-0.5 ml-2"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Conteúdo Principal com Container Amplo */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {isLoading ? (
          <div className="h-64 flex flex-col items-center justify-center text-[#64788B] text-xs gap-2">
            <div className="w-8 h-8 border-2 border-[#287DBB] border-t-transparent rounded-full animate-spin" />
            <span className="font-semibold">A carregar repositório de faturas da contabilidade...</span>
          </div>
        ) : (
          <>
            {currentTab === 'dashboard' && (
              <DashboardView
                invoices={invoices}
                signers={signers}
                settings={settings}
                onNavigateTab={(tab) => {
                  setInitialFilterDelay(false);
                  setCurrentTab(tab);
                }}
                onSelectInvoice={(inv) => setSelectedInvoice(inv)}
                onRequestReturn={(inv) => setInvoiceToReturn(inv)}
                onRequestDelivery={(inv) => setInvoiceToDeliver(inv)}
                onFilterDelayInvoices={() => {
                  setInitialFilterDelay(true);
                  setCurrentTab('invoices');
                }}
              />
            )}

            {currentTab === 'new-invoice' && (
              <NewInvoiceView
                existingInvoices={invoices}
                signers={signers}
                settings={settings}
                onInvoiceCreated={handleInvoiceCreated}
                onAddNewSigner={handleAddNewSigner}
                onViewInvoice={(inv) => setSelectedInvoice(inv)}
              />
            )}

            {currentTab === 'invoices' && (
              <InvoicesListView
                invoices={invoices}
                signers={signers}
                settings={settings}
                initialFilterDelay={initialFilterDelay}
                onSelectInvoice={(inv) => setSelectedInvoice(inv)}
                onRequestReturn={(inv) => setInvoiceToReturn(inv)}
                onRequestDelivery={(inv) => setInvoiceToDeliver(inv)}
                onNavigateToNew={() => setCurrentTab('new-invoice')}
              />
            )}

            {currentTab === 'signers' && (
              <SignersView
                signers={signers}
                invoices={invoices}
                onSaveSigner={handleSaveSigner}
                onFilterSignerInvoices={() => {
                  setInitialFilterDelay(false);
                  setCurrentTab('invoices');
                }}
              />
            )}

            {currentTab === 'history' && (
              <HistoryView
                invoices={invoices}
                onSelectInvoice={(inv) => setSelectedInvoice(inv)}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsView
                settings={settings}
                demoCount={demoCount}
                onSaveSettings={handleSaveSettings}
                onDeleteDemoData={handleDeleteDemoData}
                onBackupRestored={loadData}
                onInstallClick={handlePwaInstall}
                isAppInstalled={isAppInstalled}
              />
            )}
          </>
        )}
      </main>

      {/* Rodapé Corporativo Claro */}
      <footer className="border-t border-[#B8DBFA] bg-white py-4 text-center text-[11px] text-[#64788B]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="font-semibold text-[#253B53]">{settings.companyName} · {settings.departmentName}</span>
          <span>Gestão de Faturas | Controlo de Assinaturas · Sistema Local Offline</span>
        </div>
      </footer>

      {/* MODAL GLOBAL 1: Detalhes da Fatura & Documento */}
      <InvoiceDetailModal
        isOpen={Boolean(selectedInvoice)}
        invoice={selectedInvoice}
        settings={settings}
        signers={signers}
        onClose={() => setSelectedInvoice(null)}
        onRequestReturn={(inv) => setInvoiceToReturn(inv)}
        onRequestDelivery={(inv) => setInvoiceToDeliver(inv)}
        onUpdateInvoice={handleUpdateInvoice}
      />

      {/* MODAL GLOBAL 2: Registar Devolução */}
      <ReturnModal
        isOpen={Boolean(invoiceToReturn)}
        invoice={invoiceToReturn}
        onConfirmReturn={handleConfirmReturn}
        onCancel={() => setInvoiceToReturn(null)}
      />

      {/* MODAL GLOBAL 3: Entregar para Assinatura (para faturas "Por Entregar") */}
      {invoiceToDeliver && (
        <DeliveryModal
          isOpen={Boolean(invoiceToDeliver)}
          invoice={invoiceToDeliver}
          signers={signers}
          onConfirmDelivery={handleConfirmDeliveryFromList}
          onSaveWithoutDelivery={() => setInvoiceToDeliver(null)}
          onCancel={() => setInvoiceToDeliver(null)}
          onAddNewSigner={handleAddNewSigner}
        />
      )}

      {/* MODAL GLOBAL 4: Confirmação de Aplicação Instalada no PC */}
      <PWAInstallSuccessModal
        isOpen={showInstalledSuccessModal}
        onClose={() => setShowInstalledSuccessModal(false)}
      />

      {/* MODAL GLOBAL 5: Instruções de Instalação Chrome / Edge */}
      <PWAInstallGuideModal
        isOpen={showInstallGuideModal}
        onClose={() => setShowInstallGuideModal(false)}
      />

    </div>
  );
}
